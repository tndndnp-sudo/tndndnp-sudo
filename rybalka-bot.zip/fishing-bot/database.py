# -*- coding: utf-8 -*-
import sqlite3
import json
import os
import time
from config import START_BALANCE

# путь к БД выносим в переменную окружения: на хостинге с эфемерной ФС
# (Railway, Render) файл нужно класть на постоянный диск, иначе прогресс сотрётся
DB_PATH = os.getenv("DB_PATH", "fishing.db")
DATABASE_URL = os.getenv("DATABASE_URL", "").strip()

def get_conn():
    if DATABASE_URL:
        from pg_compat import Connection
        return Connection(DATABASE_URL)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_conn()
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        username TEXT,
        balance INTEGER DEFAULT 1000,
        location INTEGER DEFAULT 1,
        unlocked_locations TEXT DEFAULT '[1]',
        created_at INTEGER
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS rods (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        rod_id INTEGER,
        charms TEXT DEFAULT '[]',
        FOREIGN KEY(user_id) REFERENCES users(user_id)
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS fish_inventory (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        fish_id INTEGER,
        weight REAL,
        price INTEGER,
        caught_at INTEGER
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS baits (
        user_id INTEGER,
        bait_id INTEGER,
        count INTEGER DEFAULT 0,
        PRIMARY KEY(user_id, bait_id)
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS promo_codes (
        code TEXT PRIMARY KEY,
        reward_type TEXT,
        reward_amount INTEGER,
        reward_id INTEGER,
        expires_at INTEGER,
        max_activations INTEGER,
        activations INTEGER DEFAULT 0
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS stats (
        user_id INTEGER PRIMARY KEY,
        total_catches INTEGER DEFAULT 0,
        total_earned INTEGER DEFAULT 0,
        best_fish_id INTEGER DEFAULT 0,
        best_price INTEGER DEFAULT 0,
        upgrade_spins INTEGER DEFAULT 0,
        upgrade_wins INTEGER DEFAULT 0,
        streak INTEGER DEFAULT 0,
        best_streak INTEGER DEFAULT 0,
        last_catch_at INTEGER DEFAULT 0,
        runs INTEGER DEFAULT 0
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS rebirth (
        user_id INTEGER PRIMARY KEY,
        level INTEGER DEFAULT 0,
        best_time INTEGER DEFAULT 0,
        done_at INTEGER DEFAULT 0
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS achievements (
        user_id INTEGER,
        key TEXT,
        unlocked_at INTEGER,
        PRIMARY KEY(user_id, key)
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS daily (
        user_id INTEGER PRIMARY KEY,
        day TEXT,
        streak INTEGER DEFAULT 0,
        claimed_at INTEGER
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS promo_redemptions (
        user_id INTEGER,
        code TEXT,
        redeemed_at INTEGER,
        PRIMARY KEY(user_id, code)
    )""")

    # ---------- v1.2: крафт, сачок, аквариум, трейды ----------
    c.execute("""CREATE TABLE IF NOT EXISTS materials (
        user_id INTEGER,
        mat TEXT,
        count INTEGER DEFAULT 0,
        PRIMARY KEY(user_id, mat)
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS crafts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        recipe TEXT,
        finish_at INTEGER
    )""")
    # сачок: рыба лежит тут, пока её не переложили в инвентарь или не украл шторм
    c.execute("""CREATE TABLE IF NOT EXISTS net_fish (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        fish_id INTEGER,
        weight REAL,
        price INTEGER,
        caught_at INTEGER
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS aquarium (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        fish_id INTEGER,
        weight REAL,
        price INTEGER,
        placed_at INTEGER,
        last_tick INTEGER
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS aquarium_state (
        user_id INTEGER PRIMARY KEY,
        level INTEGER DEFAULT 1,
        stored INTEGER DEFAULT 0
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS trades (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        from_id INTEGER,
        to_id INTEGER,
        from_rod INTEGER DEFAULT 0,
        to_rod INTEGER DEFAULT 0,
        from_balance INTEGER DEFAULT 0,
        to_balance INTEGER DEFAULT 0,
        status TEXT DEFAULT 'pending',
        created_at INTEGER
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS admin_settings (
        user_id INTEGER PRIMARY KEY, luck REAL DEFAULT 0, speed REAL DEFAULT 1,
        price_bonus REAL DEFAULT 0, forced_fish INTEGER DEFAULT 0
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS upgrade_bonus (
        user_id INTEGER PRIMARY KEY, armed INTEGER NOT NULL DEFAULT 0
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS charm_choices (
        user_id INTEGER PRIMARY KEY, rod_id INTEGER NOT NULL, options TEXT NOT NULL
    )""")
    # Existing pending rolls were already paid for under the old rules.
    if DATABASE_URL:
        c.execute("ALTER TABLE charm_choices ADD COLUMN IF NOT EXISTS prepaid INTEGER NOT NULL DEFAULT 1")
    elif "prepaid" not in [row[1] for row in c.execute("PRAGMA table_info(charm_choices)").fetchall()]:
        c.execute("ALTER TABLE charm_choices ADD COLUMN prepaid INTEGER NOT NULL DEFAULT 1")
    c.execute("""CREATE TABLE IF NOT EXISTS admin_grants (user_id INTEGER PRIMARY KEY, granted_at INTEGER NOT NULL)""")
    # One-shot grants from the old public button must not survive for ordinary users.
    c.execute("UPDATE upgrade_bonus SET armed=0 WHERE user_id NOT IN (SELECT user_id FROM admin_grants)")
    c.execute("""CREATE TABLE IF NOT EXISTS promo_attempts (user_id INTEGER PRIMARY KEY, failures INTEGER NOT NULL, locked_until INTEGER NOT NULL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS boat_upgrades (user_id INTEGER PRIMARY KEY, level INTEGER NOT NULL DEFAULT 0)""")
    c.execute("""CREATE TABLE IF NOT EXISTS fish_records (user_id INTEGER, fish_id INTEGER, weight REAL, PRIMARY KEY(user_id,fish_id))""")
    c.execute("""CREATE TABLE IF NOT EXISTS fishing_encounters (user_id INTEGER PRIMARY KEY, payload TEXT NOT NULL, expires INTEGER NOT NULL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS fishing_events (user_id INTEGER PRIMARY KEY, payload TEXT NOT NULL, expires INTEGER NOT NULL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS fishing_contracts (
        user_id INTEGER, day TEXT, catches INTEGER DEFAULT 0, claimed INTEGER DEFAULT 0,
        PRIMARY KEY(user_id,day)
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS workshop_state (
        user_id INTEGER PRIMARY KEY, bench INTEGER DEFAULT 0, book INTEGER DEFAULT 0,
        lifetime_catches INTEGER DEFAULT 0
    )""")
    from tackle import init as init_tackle
    init_tackle(c)
    conn.commit()
    conn.close()

def is_admin(user_id):
    with get_conn() as c:
        return bool(c.execute("SELECT 1 FROM admin_grants WHERE user_id=?",(user_id,)).fetchone())

def get_boat(user_id):
    with get_conn() as c:
        row=c.execute("SELECT level FROM boat_upgrades WHERE user_id=?",(user_id,)).fetchone()
        return row["level"] if row else 0

def get_fish_records(user_id):
    with get_conn() as c:
        return [dict(r) for r in c.execute("SELECT fish_id,weight FROM fish_records WHERE user_id=? ORDER BY weight DESC LIMIT 10",(user_id,)).fetchall()]

def get_workshop(user_id):
    with get_conn() as c:
        c.execute("INSERT OR IGNORE INTO workshop_state(user_id,lifetime_catches,book) SELECT ?,COALESCE(total_catches,0),CASE WHEN COALESCE(total_catches,0)>=100 THEN 1 ELSE 0 END FROM stats WHERE user_id=?",(user_id,user_id))
        c.execute("INSERT OR IGNORE INTO workshop_state(user_id) VALUES (?)",(user_id,))
        return dict(c.execute("SELECT * FROM workshop_state WHERE user_id=?",(user_id,)).fetchone())

def get_contract(user_id):
    day=time.strftime("%Y-%m-%d",time.gmtime())
    with get_conn() as c:
        row=c.execute("SELECT catches,claimed FROM fishing_contracts WHERE user_id=? AND day=?",(user_id,day)).fetchone()
        return {"day":day,"catches":row["catches"] if row else 0,"claimed":bool(row["claimed"]) if row else False,"goal":5,"reward":1500}

def get_pending_charm(user_id):
    with get_conn() as c:
        row=c.execute("SELECT rod_id,options,prepaid FROM charm_choices WHERE user_id=?",(user_id,)).fetchone()
        return {"rod_id":row["rod_id"],"options":json.loads(row["options"]),"prepaid":bool(row["prepaid"])} if row else None

def get_admin_settings(user_id):
    with get_conn() as conn:
        row = conn.execute("SELECT luck,speed,price_bonus,forced_fish FROM admin_settings WHERE user_id=?", (user_id,)).fetchone()
        return dict(row) if row else {"luck": 0, "speed": 1, "price_bonus": 0, "forced_fish": 0}

def get_or_create_user(user_id, username=None):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE user_id=?", (user_id,))
    row = c.fetchone()
    if row is None:
        c.execute("INSERT INTO users (user_id, username, balance, location, unlocked_locations, created_at) VALUES (?,?,?,?,?,?)",
                  (user_id, username, START_BALANCE, 1, json.dumps([1]), int(time.time())))
        conn.commit()
        c.execute("SELECT * FROM users WHERE user_id=?", (user_id,))
        row = c.fetchone()
    elif username and row["username"] != username:
        c.execute("UPDATE users SET username=? WHERE user_id=?", (username, user_id))
        conn.commit()
    conn.close()
    return dict(row)

def get_user(user_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE user_id=?", (user_id,))
    row = c.fetchone()
    conn.close()
    return dict(row) if row else None

def update_balance(user_id, delta):
    conn = get_conn()
    c = conn.cursor()
    c.execute("UPDATE users SET balance = balance + ? WHERE user_id=?", (delta, user_id))
    c.execute("SELECT balance FROM users WHERE user_id=?", (user_id,))
    bal = c.fetchone()["balance"]
    conn.commit()
    conn.close()
    return bal

def set_balance(user_id, amount):
    conn = get_conn()
    c = conn.cursor()
    c.execute("UPDATE users SET balance=? WHERE user_id=?", (amount, user_id))
    conn.commit()
    conn.close()

def set_location(user_id, loc):
    conn = get_conn()
    c = conn.cursor()
    c.execute("UPDATE users SET location=? WHERE user_id=?", (loc, user_id))
    conn.commit()
    conn.close()

def unlock_location(user_id, loc):
    u = get_user(user_id)
    unlocked = json.loads(u["unlocked_locations"] or "[1]")
    if loc not in unlocked:
        unlocked.append(loc)
        conn = get_conn()
        c = conn.cursor()
        c.execute("UPDATE users SET unlocked_locations=? WHERE user_id=?", (json.dumps(unlocked), user_id))
        conn.commit()
        conn.close()

def get_rods(user_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM rods WHERE user_id=?", (user_id,))
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    for r in rows:
        r["charms"] = json.loads(r["charms"] or "[]")
    return rows

def add_rod(user_id, rod_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("INSERT INTO rods (user_id, rod_id, charms) VALUES (?,?,?)", (user_id, rod_id, "[]"))
    conn.commit()
    conn.close()

def remove_rod(user_id, rod_db_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("DELETE FROM rods WHERE id=? AND user_id=?", (rod_db_id, user_id))
    conn.commit()
    conn.close()

def update_rod_charms(rod_db_id, charms):
    conn = get_conn()
    c = conn.cursor()
    c.execute("UPDATE rods SET charms=? WHERE id=?", (json.dumps(charms), rod_db_id))
    conn.commit()
    conn.close()

def get_fish(user_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM fish_inventory WHERE user_id=? ORDER BY id DESC", (user_id,))
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows

def add_fish(user_id, fish_id, weight, price):
    conn = get_conn()
    c = conn.cursor()
    c.execute("INSERT INTO fish_inventory (user_id, fish_id, weight, price, caught_at) VALUES (?,?,?,?,?)",
              (user_id, fish_id, weight, price, int(time.time())))
    conn.commit()
    fid = c.lastrowid
    conn.close()
    return fid

def remove_fish(user_id, inv_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM fish_inventory WHERE id=? AND user_id=?", (inv_id, user_id))
    row = c.fetchone()
    if row:
        c.execute("DELETE FROM fish_inventory WHERE id=?", (inv_id,))
        conn.commit()
    conn.close()
    return dict(row) if row else None

def get_baits(user_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM baits WHERE user_id=?", (user_id,))
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows

def add_bait(user_id, bait_id, count=1):
    conn = get_conn()
    c = conn.cursor()
    c.execute("INSERT INTO baits (user_id, bait_id, count) VALUES (?,?,?) ON CONFLICT(user_id, bait_id) DO UPDATE SET count=count+excluded.count",
              (user_id, bait_id, count))
    conn.commit()
    conn.close()

def use_bait(user_id, bait_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT count FROM baits WHERE user_id=? AND bait_id=?", (user_id, bait_id))
    row = c.fetchone()
    if row and row["count"] > 0:
        c.execute("UPDATE baits SET count=count-1 WHERE user_id=? AND bait_id=?", (user_id, bait_id))
        conn.commit()
        conn.close()
        return True
    conn.close()
    return False

# Статистика и достижения
def get_rebirth(user_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM rebirth WHERE user_id=?", (user_id,))
    row = c.fetchone()
    if row is None:
        c.execute("INSERT INTO rebirth (user_id) VALUES (?)", (user_id,))
        conn.commit()
        c.execute("SELECT * FROM rebirth WHERE user_id=?", (user_id,))
        row = c.fetchone()
    conn.close()
    return dict(row)

def add_rebirth(user_id):
    """Повышает уровень перерождения и возвращает новый уровень."""
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT level FROM rebirth WHERE user_id=?", (user_id,))
    row = c.fetchone()
    if row is None:
        c.execute("INSERT INTO rebirth (user_id, level, done_at) VALUES (?, 1, ?)",
                  (user_id, int(time.time())))
    else:
        c.execute("UPDATE rebirth SET level=level+1, done_at=? WHERE user_id=?",
                  (int(time.time()), user_id))
    conn.commit()
    c.execute("SELECT * FROM rebirth WHERE user_id=?", (user_id,))
    out = dict(c.fetchone())
    conn.close()
    return out

def reset_progress(user_id, start_balance=1000):
    """Сброс прогресса для перерождения: удочки, рыба, наживка, локации, серия."""
    conn = get_conn()
    c = conn.cursor()
    c.execute("DELETE FROM rods WHERE user_id=?", (user_id,))
    c.execute("DELETE FROM fish_inventory WHERE user_id=?", (user_id,))
    c.execute("DELETE FROM baits WHERE user_id=?", (user_id,))
    c.execute("UPDATE users SET balance=?, location=1, unlocked_locations='[1]' WHERE user_id=?",
              (start_balance, user_id))
    c.execute("INSERT INTO rods (user_id, rod_id) VALUES (?,?)", (user_id, 1))
    c.execute("UPDATE stats SET streak=0, last_catch_at=0 WHERE user_id=?", (user_id,))
    conn.commit()
    conn.close()

def get_stats(user_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM stats WHERE user_id=?", (user_id,))
    row = c.fetchone()
    if row is None:
        c.execute("INSERT INTO stats (user_id) VALUES (?)", (user_id,))
        conn.commit()
        c.execute("SELECT * FROM stats WHERE user_id=?", (user_id,))
        row = c.fetchone()
    conn.close()
    return dict(row)

def bump_stats(user_id, **kw):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT user_id FROM stats WHERE user_id=?", (user_id,))
    if c.fetchone() is None:
        c.execute("INSERT INTO stats (user_id) VALUES (?)", (user_id,))
    fields = ", ".join(f"{k}={k}+?" if k not in ("best_fish_id","best_price","best_streak","upgrade_wins","last_catch_at","streak") else f"{k}=?" for k in kw)
    # проще: обрабатываем по одному
    for k, v in kw.items():
        if k in ("best_price","best_streak","upgrade_wins","best_fish_id","last_catch_at","streak"):
            c.execute(f"UPDATE stats SET {k}=? WHERE user_id=?", (v, user_id))
        else:
            c.execute(f"UPDATE stats SET {k}={k}+? WHERE user_id=?", (v, user_id))
    conn.commit()
    conn.close()

def get_achievements(user_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT key, unlocked_at FROM achievements WHERE user_id=?", (user_id,))
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows

def unlock_achievement(user_id, key):
    conn = get_conn()
    c = conn.cursor()
    c.execute("INSERT OR IGNORE INTO achievements (user_id, key, unlocked_at) VALUES (?,?,?)", (user_id, key, int(time.time())))
    added = c.rowcount > 0
    conn.commit()
    conn.close()
    return added

def get_daily(user_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM daily WHERE user_id=?", (user_id,))
    row = c.fetchone()
    conn.close()
    return dict(row) if row else None

def set_daily(user_id, day, streak, claimed_at):
    conn = get_conn()
    c = conn.cursor()
    c.execute("INSERT INTO daily (user_id, day, streak, claimed_at) VALUES (?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET day=excluded.day, streak=excluded.streak, claimed_at=excluded.claimed_at",
              (user_id, day, streak, claimed_at))
    conn.commit()
    conn.close()

# Промокоды
def create_promo(code, reward_type, reward_amount, reward_id, expires_at, max_activations):
    conn = get_conn()
    c = conn.cursor()
    c.execute("INSERT OR REPLACE INTO promo_codes (code, reward_type, reward_amount, reward_id, expires_at, max_activations, activations) VALUES (?,?,?,?,?,?,0)",
              (code.lower(), reward_type, reward_amount, reward_id, expires_at, max_activations))
    conn.commit()
    conn.close()

def get_promo(code):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM promo_codes WHERE code=?", (code.lower(),))
    row = c.fetchone()
    conn.close()
    return dict(row) if row else None

def list_promos():
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM promo_codes ORDER BY code")
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows

def delete_promo(code):
    conn = get_conn()
    c = conn.cursor()
    c.execute("DELETE FROM promo_codes WHERE code=?", (code.lower(),))
    conn.commit()
    conn.close()

def redeem_promo(user_id, code):
    code = code.lower()
    promo = get_promo(code)
    if not promo:
        return False, "Промокод не найден"
    if promo["expires_at"] and int(time.time()) > promo["expires_at"]:
        return False, "Промокод истёк"
    if promo["activations"] >= promo["max_activations"]:
        return False, "Промокод исчерпан"
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM promo_redemptions WHERE user_id=? AND code=?", (user_id, code))
    if c.fetchone():
        conn.close()
        return False, "Вы уже активировали этот промокод"
    c.execute("INSERT INTO promo_redemptions (user_id, code, redeemed_at) VALUES (?,?,?)", (user_id, code, int(time.time())))
    c.execute("UPDATE promo_codes SET activations=activations+1 WHERE code=?", (code,))
    conn.commit()
    conn.close()
    return True, promo

def stats():
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT COUNT(*) as n FROM users")
    users = c.fetchone()["n"]
    c.execute("SELECT COALESCE(SUM(balance),0) as s FROM users")
    total_bal = c.fetchone()["s"]
    c.execute("SELECT COUNT(*) as n FROM fish_inventory")
    fish_n = c.fetchone()["n"]
    c.execute("SELECT COUNT(*) as n FROM rods")
    rods_n = c.fetchone()["n"]
    conn.close()
    return {"users": users, "total_balance": total_bal, "fish": fish_n, "rods": rods_n}

def find_user_by_username(username):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username=?", (username.lstrip("@"),))
    row = c.fetchone()
    conn.close()
    return dict(row) if row else None

# ============================================================
#  v1.2: материалы, крафт, сачок, аквариум, трейды
# ============================================================

def get_materials(user_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT mat, count FROM materials WHERE user_id=?", (user_id,))
    rows = {r["mat"]: r["count"] for r in c.fetchall()}
    conn.close()
    return rows

def add_material(user_id, mat, delta):
    conn = get_conn()
    c = conn.cursor()
    c.execute("""INSERT INTO materials (user_id, mat, count) VALUES (?,?,?)
                 ON CONFLICT(user_id, mat) DO UPDATE SET count = count + ?""",
              (user_id, mat, max(0, delta), delta))
    c.execute("DELETE FROM materials WHERE user_id=? AND mat=? AND count<=0", (user_id, mat))
    conn.commit()
    conn.close()

def start_craft(user_id, recipe, finish_at):
    conn = get_conn()
    c = conn.cursor()
    c.execute("INSERT INTO crafts (user_id, recipe, finish_at) VALUES (?,?,?)",
              (user_id, recipe, finish_at))
    cid = c.lastrowid
    conn.commit()
    conn.close()
    return cid

def get_crafts(user_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM crafts WHERE user_id=? ORDER BY finish_at", (user_id,))
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows

def finish_craft(craft_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM crafts WHERE id=?", (craft_id,))
    row = c.fetchone()
    if row:
        c.execute("DELETE FROM crafts WHERE id=?", (craft_id,))
        conn.commit()
    conn.close()
    return dict(row) if row else None

# ---------- сачок ----------
def net_add(user_id, fish_id, weight, price):
    conn = get_conn()
    c = conn.cursor()
    c.execute("INSERT INTO net_fish (user_id, fish_id, weight, price, caught_at) VALUES (?,?,?,?,?)",
              (user_id, fish_id, weight, price, int(time.time())))
    nid = c.lastrowid
    conn.commit()
    conn.close()
    return nid

def net_list(user_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM net_fish WHERE user_id=? ORDER BY id", (user_id,))
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows

def net_take(user_id, net_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM net_fish WHERE id=? AND user_id=?", (net_id, user_id))
    row = c.fetchone()
    if row:
        c.execute("DELETE FROM net_fish WHERE id=?", (net_id,))
        conn.commit()
    conn.close()
    return dict(row) if row else None

def net_lose_random(user_id, count=1):
    """Шторм уносит рыбу из сачка. Возвращает то, что потеряли."""
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM net_fish WHERE user_id=? ORDER BY RANDOM() LIMIT ?", (user_id, count))
    rows = [dict(r) for r in c.fetchall()]
    for r in rows:
        c.execute("DELETE FROM net_fish WHERE id=?", (r["id"],))
    conn.commit()
    conn.close()
    return rows

def net_clear(user_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("DELETE FROM net_fish WHERE user_id=?", (user_id,))
    conn.commit()
    conn.close()

# ---------- аквариум ----------
def aquarium_state(user_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM aquarium_state WHERE user_id=?", (user_id,))
    row = c.fetchone()
    if row is None:
        c.execute("INSERT INTO aquarium_state (user_id, level, stored) VALUES (?,1,0)", (user_id,))
        conn.commit()
        c.execute("SELECT * FROM aquarium_state WHERE user_id=?", (user_id,))
        row = c.fetchone()
    conn.close()
    return dict(row)

def aquarium_set_level(user_id, level):
    conn = get_conn()
    c = conn.cursor()
    c.execute("""INSERT INTO aquarium_state (user_id, level) VALUES (?,?)
                 ON CONFLICT(user_id) DO UPDATE SET level=?""", (user_id, level, level))
    conn.commit()
    conn.close()

def aquarium_add_stored(user_id, amount):
    conn = get_conn()
    c = conn.cursor()
    c.execute("""INSERT INTO aquarium_state (user_id, stored) VALUES (?,?)
                 ON CONFLICT(user_id) DO UPDATE SET stored = stored + ?""", (user_id, amount, amount))
    conn.commit()
    conn.close()

def aquarium_claim_stored(user_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT stored FROM aquarium_state WHERE user_id=?", (user_id,))
    row = c.fetchone()
    amount = row["stored"] if row else 0
    if amount:
        c.execute("UPDATE aquarium_state SET stored=0 WHERE user_id=?", (user_id,))
        conn.commit()
    conn.close()
    return amount

def aquarium_list(user_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM aquarium WHERE user_id=? ORDER BY id", (user_id,))
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows

def aquarium_put(user_id, fish_id, weight, price):
    conn = get_conn()
    c = conn.cursor()
    c.execute("INSERT INTO aquarium (user_id, fish_id, weight, price, placed_at, last_tick) VALUES (?,?,?,?,?,?)",
              (user_id, fish_id, weight, price, int(time.time()), int(time.time())))
    aid = c.lastrowid
    conn.commit()
    conn.close()
    return aid

def aquarium_remove(user_id, aq_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM aquarium WHERE id=? AND user_id=?", (aq_id, user_id))
    row = c.fetchone()
    if row:
        c.execute("DELETE FROM aquarium WHERE id=?", (aq_id,))
        conn.commit()
    conn.close()
    return dict(row) if row else None

def aquarium_clear(user_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("DELETE FROM aquarium WHERE user_id=?", (user_id,))
    c.execute("DELETE FROM aquarium_state WHERE user_id=?", (user_id,))
    c.execute("DELETE FROM net_fish WHERE user_id=?", (user_id,))
    c.execute("DELETE FROM materials WHERE user_id=?", (user_id,))
    c.execute("DELETE FROM crafts WHERE user_id=?", (user_id,))
    conn.commit()
    conn.close()

# ---------- трейды ----------
def trade_create(from_id, to_id, from_rod, to_rod, from_balance, to_balance):
    conn = get_conn()
    c = conn.cursor()
    c.execute("""INSERT INTO trades (from_id, to_id, from_rod, to_rod, from_balance, to_balance,
                 status, created_at) VALUES (?,?,?,?,?,?,'pending',?)""",
              (from_id, to_id, from_rod, to_rod, from_balance, to_balance, int(time.time())))
    tid = c.lastrowid
    conn.commit()
    conn.close()
    return tid

def trades_incoming(user_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM trades WHERE to_id=? AND status='pending' ORDER BY id DESC", (user_id,))
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows

def trades_outgoing(user_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM trades WHERE from_id=? AND status='pending' ORDER BY id DESC", (user_id,))
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows

def trade_get(tid):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM trades WHERE id=?", (tid,))
    row = c.fetchone()
    conn.close()
    return dict(row) if row else None

def trade_set_status(tid, status):
    conn = get_conn()
    c = conn.cursor()
    c.execute("UPDATE trades SET status=? WHERE id=?", (status, tid))
    conn.commit()
    conn.close()

def trade_pending_count(user_id):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT COUNT(*) as n FROM trades WHERE to_id=? AND status='pending'", (user_id,))
    n = c.fetchone()["n"]
    conn.close()
    return n

def set_charms(user_id, rod_db_id, charms):
    """Полная замена чар на удочке (снятие)."""
    conn = get_conn()
    c = conn.cursor()
    c.execute("UPDATE rods SET charms=? WHERE id=? AND user_id=?",
              (json.dumps(charms or []), rod_db_id, user_id))
    conn.commit()
    conn.close()
