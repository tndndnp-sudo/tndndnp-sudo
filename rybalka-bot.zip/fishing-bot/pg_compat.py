"""PostgreSQL adapter for the project's existing SQLite-shaped queries.
Uses a transaction-scoped advisory lock for BEGIN IMMEDIATE sections.
DATABASE_URL is never logged. SQLite remains available for local development.
"""
import re
import psycopg
from psycopg import rows

_IDS={'rods','fish_inventory','crafts','net_fish','aquarium','trades'}
_KEYS={'fishing_events':['user_id'],'fishing_encounters':['user_id'],
       'promo_attempts':['user_id'],'promo_codes':['code']}

class Row(dict):
    def __getitem__(self,key):
        if isinstance(key,int): return list(self.values())[key]
        return super().__getitem__(key)

def _row_factory(cursor):
    names=[c.name for c in cursor.description] if cursor.description else []
    return lambda values: Row(zip(names,values))

def _sql(sql):
    sql=sql.strip()
    if sql.upper()=='BEGIN IMMEDIATE': return 'SELECT pg_advisory_xact_lock(734982713)'
    sql=re.sub(r'\bid\s+INTEGER\s+PRIMARY\s+KEY\s+AUTOINCREMENT\b','id BIGSERIAL PRIMARY KEY',sql,flags=re.I)
    sql=re.sub(r'\bINTEGER\b','BIGINT',sql,flags=re.I)
    sql=sql.replace('?', '%s')
    if re.match(r'INSERT\s+OR\s+IGNORE\s+INTO',sql,re.I):
        sql=re.sub(r'INSERT\s+OR\s+IGNORE\s+INTO','INSERT INTO',sql,count=1,flags=re.I)+' ON CONFLICT DO NOTHING'
    elif re.match(r'INSERT\s+OR\s+REPLACE\s+INTO',sql,re.I):
        sql=re.sub(r'INSERT\s+OR\s+REPLACE\s+INTO','INSERT INTO',sql,count=1,flags=re.I)
        m=re.match(r'INSERT\s+INTO\s+(\w+)\s*\(([^)]+)\)',sql,re.I)
        if not m or m.group(1).lower() not in _KEYS: raise RuntimeError('Unsupported replace operation')
        table=m.group(1).lower(); cols=[x.strip() for x in m.group(2).split(',')]; keys=_KEYS[table]
        sql+=' ON CONFLICT ('+','.join(keys)+') DO UPDATE SET '+','.join(f'{c}=EXCLUDED.{c}' for c in cols if c not in keys)
    # PostgreSQL requires target qualification when the EXCLUDED row is visible.
    m=re.match(r'INSERT\s+INTO\s+(\w+)',sql,re.I)
    if m and 'ON CONFLICT' in sql.upper():
        table=m.group(1)
        sql=re.sub(r'(?i)(SET\s+)(count|level|stored|catches)(\s*=\s*)\2\s*\+',lambda x:x.group(1)+x.group(2)+x.group(3)+table+'.'+x.group(2)+'+',sql)
    return sql

class Cursor:
    def __init__(self,c): self.c=c; self.lastrowid=None
    def execute(self,sql,params=()):
        q=_sql(sql); m=re.match(r'INSERT\s+INTO\s+(\w+)',q,re.I)
        wants_id=bool(m and m.group(1).lower() in _IDS and not re.search(r'\bRETURNING\b',q,re.I))
        if wants_id: q+=' RETURNING id'
        self.c.execute(q,params)
        self.lastrowid=self.c.fetchone()['id'] if wants_id and self.c.rowcount else None
        return self
    def executemany(self,sql,values): self.c.executemany(_sql(sql),values); return self
    def fetchone(self): return self.c.fetchone()
    def fetchall(self): return self.c.fetchall()
    @property
    def rowcount(self): return self.c.rowcount
    def __iter__(self): return iter(self.c)

class Connection:
    def __init__(self,url): self.c=psycopg.connect(url,row_factory=_row_factory,connect_timeout=15)
    def cursor(self): return Cursor(self.c.cursor())
    def execute(self,sql,params=()): return self.cursor().execute(sql,params)
    def executemany(self,sql,params): return self.cursor().executemany(sql,params)
    def commit(self): self.c.commit()
    def rollback(self): self.c.rollback()
    def close(self): self.c.close()
    def __enter__(self): return self
    def __exit__(self,typ,val,tb):
        try:
            if typ: self.rollback()
            else: self.commit()
        finally: self.close()
