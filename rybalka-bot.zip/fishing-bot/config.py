# -*- coding: utf-8 -*-
"""
Конфиг игры «Рыбалка» Автор: @pspwlk Версия 1.1
Все данные: локации, удочки, рыбы (240 шт), чары (50 шт), наживки
"""

# ========== РЕДКОСТИ ==========
RARITIES = {
    "common":     {"name": "Обычный",       "color": "#9e9e9e", "emoji": "⚪", "weight": 1},
    "uncommon":   {"name": "Необычный",     "color": "#4caf50", "emoji": "🟢", "weight": 2},
    "rare":       {"name": "Редкий",        "color": "#2196f3", "emoji": "🔵", "weight": 3},
    "super_rare": {"name": "Сверхредкий",   "color": "#9c27b0", "emoji": "🟣", "weight": 4},
    "epic":       {"name": "Эпический",     "color": "#ff9800", "emoji": "🟠", "weight": 5},
    "legendary":  {"name": "Легендарный",   "color": "#ff5722", "emoji": "🔴", "weight": 6},
    "mythical":   {"name": "Мифический",    "color": "#e91e63", "emoji": "💠", "weight": 7},
    "golden":     {"name": "Золотой",       "color": "#ffd700", "emoji": "👑", "weight": 8},
}

# Шансы чар по локациям (в процентах, сумма 100)
CHARM_CHANCES = {
    1: {"common": 60.0, "uncommon": 25.0, "rare": 10.0, "super_rare": 3.0, "epic": 1.2, "legendary": 0.5, "mythical": 0.2, "golden": 0.1},
    2: {"common": 40.0, "uncommon": 25.0, "rare": 18.0, "super_rare": 9.0, "epic": 5.0, "legendary": 2.0, "mythical": 0.8, "golden": 0.2},
    3: {"common": 25.0, "uncommon": 20.0, "rare": 20.0, "super_rare": 15.0, "epic": 10.0, "legendary": 6.0, "mythical": 3.0, "golden": 1.0},
}
# цена прокрута чар ≈ 2-6 минут обычной игры в локации
CHARM_SPIN_COST = {1: 1200, 2: 9000, 3: 60000}

# ========== ЛОКАЦИИ ==========
LOCATIONS = {
    1: {"id": 1, "name": "Река «Тихая заводь»", "desc": "Пресноводная рыбалка. Идеально для новичков.", "unlock_cost": 0, "emoji": "🏞️"},
    2: {"id": 2, "name": "Морской берег «Штормовая бухта»", "desc": "Морская рыба, крупнее и дороже.", "unlock_cost": 13000, "emoji": "🌊", "requires_rod": 10},
    3: {"id": 3, "name": "Океан «Глубина»", "desc": "Океаническая рыба-гигант. Максимальные награды.", "unlock_cost": 81000, "emoji": "🐙", "requires_rod": 17},
}

# ========== УДОЧКИ (24 шт) ==========
# luck: 0-100 бонус к лёгкости мини-игры, price_bonus: % к цене рыбы, rarity_bonus: % к шансу редкой рыбы
RODS = [
    {"id":  1, "loc": 1, "name": "Бамбуковый прут", "price": 500, "luck": 4, "price_bonus": 0, "rarity_bonus": 0, "emoji": ""},
    {"id":  2, "loc": 1, "name": "Удочка «Новичок»", "price": 950, "luck": 10, "price_bonus": 12, "rarity_bonus": 0, "emoji": ""},
    {"id":  3, "loc": 1, "name": "Спиннинг «Речной»", "price": 1400, "luck": 16, "price_bonus": 25, "rarity_bonus": 0, "emoji": ""},
    {"id":  4, "loc": 1, "name": "Фидер «Тихоня»", "price": 1800, "luck": 23, "price_bonus": 40, "rarity_bonus": 0, "emoji": ""},
    {"id":  5, "loc": 1, "name": "Карповая «Монстр»", "price": 2500, "luck": 31, "price_bonus": 57, "rarity_bonus": 0, "emoji": ""},
    {"id":  6, "loc": 1, "name": "Спиннинг «Хищник»", "price": 3300, "luck": 40, "price_bonus": 76, "rarity_bonus": 0, "emoji": ""},
    {"id":  7, "loc": 1, "name": "Удочка «Золотой Ус»", "price": 4400, "luck": 50, "price_bonus": 97, "rarity_bonus": 0, "emoji": ""},
    {"id":  8, "loc": 1, "name": "Профи «Атлант»", "price": 5800, "luck": 61, "price_bonus": 121, "rarity_bonus": 0, "emoji": ""},
    {"id":  9, "loc": 1, "name": "Элит «Север»", "price": 7700, "luck": 73, "price_bonus": 148, "rarity_bonus": 0, "emoji": ""},
    {"id": 10, "loc": 1, "name": "Легенда «Царь Рыбалки»", "price": 10000, "luck": 87, "price_bonus": 177, "rarity_bonus": 0, "emoji": ""},
    {"id": 11, "loc": 2, "name": "Морской «Шторм»", "price": 13000, "luck": 101, "price_bonus": 211, "rarity_bonus": 2, "emoji": ""},
    {"id": 12, "loc": 2, "name": "«Глубина»", "price": 25000, "luck": 116, "price_bonus": 248, "rarity_bonus": 3, "emoji": ""},
    {"id": 13, "loc": 2, "name": "«Тайфун»", "price": 33000, "luck": 132, "price_bonus": 290, "rarity_bonus": 4, "emoji": ""},
    {"id": 14, "loc": 2, "name": "«Коралл»", "price": 44000, "luck": 149, "price_bonus": 336, "rarity_bonus": 5, "emoji": ""},
    {"id": 15, "loc": 2, "name": "«Акулья Пасть»", "price": 58000, "luck": 167, "price_bonus": 389, "rarity_bonus": 6, "emoji": ""},
    {"id": 16, "loc": 2, "name": "«Океан»", "price": 77000, "luck": 186, "price_bonus": 447, "rarity_bonus": 7, "emoji": ""},
    {"id": 17, "loc": 2, "name": "«Посейдон»", "price": 100000, "luck": 206, "price_bonus": 513, "rarity_bonus": 9, "emoji": ""},
    {"id": 18, "loc": 3, "name": "«Абсолют»", "price": 130000, "luck": 227, "price_bonus": 587, "rarity_bonus": 11, "emoji": ""},
    {"id": 19, "loc": 3, "name": "«Кракен»", "price": 180000, "luck": 249, "price_bonus": 669, "rarity_bonus": 13, "emoji": ""},
    {"id": 20, "loc": 3, "name": "«Тритон»", "price": 240000, "luck": 272, "price_bonus": 761, "rarity_bonus": 15, "emoji": ""},
    {"id": 21, "loc": 3, "name": "«Атлантида»", "price": 320000, "luck": 296, "price_bonus": 865, "rarity_bonus": 17, "emoji": ""},
    {"id": 22, "loc": 3, "name": "«Нептун»", "price": 420000, "luck": 321, "price_bonus": 980, "rarity_bonus": 19, "emoji": ""},
    {"id": 23, "loc": 3, "name": "«Океанский Титан»", "price": 550000, "luck": 347, "price_bonus": 1110, "rarity_bonus": 21, "emoji": ""},
    {"id": 24, "loc": 3, "name": "«Бог Морей»", "price": 910000, "luck": 374, "price_bonus": 1255, "rarity_bonus": 31, "emoji": ""},
]
RODS_BY_ID = {r["id"]: r for r in RODS}

# ========== ЧАРЫ (50 шт) ==========
# effect_type: luck / price / rarity / weight / speed ; effect_value: %
CHARMS = [
    # Обычные (8)
    {"id": 1,  "name": "Чара Удачи I",        "rarity": "common",     "effect_type": "luck",   "effect_value": 3,  "emoji": "🍀"},
    {"id": 2,  "name": "Чара Клёва I",        "rarity": "common",     "effect_type": "luck",   "effect_value": 2,  "emoji": "🐟"},
    {"id": 3,  "name": "Чара Веса I",         "rarity": "common",     "effect_type": "weight", "effect_value": 5,  "emoji": "⚖️"},
    {"id": 4,  "name": "Чара Цены I",         "rarity": "common",     "effect_type": "price",  "effect_value": 3,  "emoji": "💰"},
    {"id": 5,  "name": "Чара Скорости I",     "rarity": "common",     "effect_type": "speed",  "effect_value": 3,  "emoji": "💨"},
    {"id": 6,  "name": "Чара Редкости I",     "rarity": "common",     "effect_type": "rarity", "effect_value": 2,  "emoji": "✨"},
    {"id": 7,  "name": "Чара Точности I",     "rarity": "common",     "effect_type": "luck",   "effect_value": 2,  "emoji": "🎯"},
    {"id": 8,  "name": "Чара Сети I",         "rarity": "common",     "effect_type": "price",  "effect_value": 2,  "emoji": "🕸️"},
    # Необычные (8)
    {"id": 9,  "name": "Чара Удачи II",       "rarity": "uncommon",   "effect_type": "luck",   "effect_value": 6,  "emoji": "🍀"},
    {"id": 10, "name": "Чара Клёва II",       "rarity": "uncommon",   "effect_type": "luck",   "effect_value": 5,  "emoji": "🐟"},
    {"id": 11, "name": "Чара Веса II",        "rarity": "uncommon",   "effect_type": "weight", "effect_value": 10, "emoji": "⚖️"},
    {"id": 12, "name": "Чара Цены II",        "rarity": "uncommon",   "effect_type": "price",  "effect_value": 6,  "emoji": "💰"},
    {"id": 13, "name": "Чара Скорости II",    "rarity": "uncommon",   "effect_type": "speed",  "effect_value": 6,  "emoji": "💨"},
    {"id": 14, "name": "Чара Редкости II",    "rarity": "uncommon",   "effect_type": "rarity", "effect_value": 5,  "emoji": "✨"},
    {"id": 15, "name": "Чара Точности II",    "rarity": "uncommon",   "effect_type": "luck",   "effect_value": 5,  "emoji": "🎯"},
    {"id": 16, "name": "Чара Сети II",        "rarity": "uncommon",   "effect_type": "weight", "effect_value": 8,  "emoji": "🕸️"},
    # Редкие (8)
    {"id": 17, "name": "Чара Удачи III",      "rarity": "rare",       "effect_type": "luck",   "effect_value": 10, "emoji": "🍀"},
    {"id": 18, "name": "Чара Клёва III",      "rarity": "rare",       "effect_type": "luck",   "effect_value": 9,  "emoji": "🐟"},
    {"id": 19, "name": "Чара Веса III",       "rarity": "rare",       "effect_type": "weight", "effect_value": 15, "emoji": "⚖️"},
    {"id": 20, "name": "Чара Цены III",       "rarity": "rare",       "effect_type": "price",  "effect_value": 10, "emoji": "💰"},
    {"id": 21, "name": "Чара Скорости III",   "rarity": "rare",       "effect_type": "speed",  "effect_value": 10, "emoji": "💨"},
    {"id": 22, "name": "Чара Редкости III",   "rarity": "rare",       "effect_type": "rarity", "effect_value": 9,  "emoji": "✨"},
    {"id": 23, "name": "Чара Точности III",   "rarity": "rare",       "effect_type": "luck",   "effect_value": 9,  "emoji": "🎯"},
    {"id": 24, "name": "Чара Сети III",       "rarity": "rare",       "effect_type": "price",  "effect_value": 9,  "emoji": "🕸️"},
    # Сверхредкие (7)
    {"id": 25, "name": "Чара Удачи IV",       "rarity": "super_rare", "effect_type": "luck",   "effect_value": 15, "emoji": "🍀"},
    {"id": 26, "name": "Чара Клёва IV",       "rarity": "super_rare", "effect_type": "luck",   "effect_value": 14, "emoji": "🐟"},
    {"id": 27, "name": "Чара Веса IV",        "rarity": "super_rare", "effect_type": "weight", "effect_value": 22, "emoji": "⚖️"},
    {"id": 28, "name": "Чара Цены IV",        "rarity": "super_rare", "effect_type": "price",  "effect_value": 15, "emoji": "💰"},
    {"id": 29, "name": "Чара Скорости IV",    "rarity": "super_rare", "effect_type": "speed",  "effect_value": 15, "emoji": "💨"},
    {"id": 30, "name": "Чара Редкости IV",    "rarity": "super_rare", "effect_type": "rarity", "effect_value": 14, "emoji": "✨"},
    {"id": 31, "name": "Чара Точности IV",    "rarity": "super_rare", "effect_type": "luck",   "effect_value": 14, "emoji": "🎯"},
    # Эпические (6)
    {"id": 32, "name": "Чара Удачи V",        "rarity": "epic",       "effect_type": "luck",   "effect_value": 22, "emoji": "🍀"},
    {"id": 33, "name": "Чара Клёва V",        "rarity": "epic",       "effect_type": "luck",   "effect_value": 20, "emoji": "🐟"},
    {"id": 34, "name": "Чара Веса V",         "rarity": "epic",       "effect_type": "weight", "effect_value": 30, "emoji": "⚖️"},
    {"id": 35, "name": "Чара Цены V",         "rarity": "epic",       "effect_type": "price",  "effect_value": 22, "emoji": "💰"},
    {"id": 36, "name": "Чара Редкости V",     "rarity": "epic",       "effect_type": "rarity", "effect_value": 20, "emoji": "✨"},
    {"id": 37, "name": "Чара Скорости V",     "rarity": "epic",       "effect_type": "speed",  "effect_value": 22, "emoji": "💨"},
    # Легендарные (5)
    {"id": 38, "name": "Чара Удачи VI",       "rarity": "legendary",  "effect_type": "luck",   "effect_value": 30, "emoji": "🍀"},
    {"id": 39, "name": "Чара Цены VI",        "rarity": "legendary",  "effect_type": "price",  "effect_value": 30, "emoji": "💰"},
    {"id": 40, "name": "Чара Редкости VI",    "rarity": "legendary",  "effect_type": "rarity", "effect_value": 28, "emoji": "✨"},
    {"id": 41, "name": "Чара Веса VI",        "rarity": "legendary",  "effect_type": "weight", "effect_value": 40, "emoji": "⚖️"},
    {"id": 42, "name": "Чара Скорости VI",    "rarity": "legendary",  "effect_type": "speed",  "effect_value": 30, "emoji": "💨"},
    # Мифические (4)
    {"id": 43, "name": "Чара Удачи VII",      "rarity": "mythical",   "effect_type": "luck",   "effect_value": 40, "emoji": "🍀"},
    {"id": 44, "name": "Чара Цены VII",       "rarity": "mythical",   "effect_type": "price",  "effect_value": 40, "emoji": "💰"},
    {"id": 45, "name": "Чара Редкости VII",   "rarity": "mythical",   "effect_type": "rarity", "effect_value": 38, "emoji": "✨"},
    {"id": 46, "name": "Чара Веса VII",       "rarity": "mythical",   "effect_type": "weight", "effect_value": 55, "emoji": "⚖️"},
    # Золотые (4)
    {"id": 47, "name": "Золотая Чара Удачи",   "rarity": "golden",     "effect_type": "luck",   "effect_value": 55, "emoji": "👑"},
    {"id": 48, "name": "Золотая Чара Цены",    "rarity": "golden",     "effect_type": "price",  "effect_value": 55, "emoji": "👑"},
    {"id": 49, "name": "Золотая Чара Редкости","rarity": "golden",     "effect_type": "rarity", "effect_value": 50, "emoji": "👑"},
    {"id": 50, "name": "Золотая Чара Веса",    "rarity": "golden",     "effect_type": "weight", "effect_value": 75, "emoji": "👑"},
]
CHARMS_BY_ID = {c["id"]: c for c in CHARMS}
CHARMS_BY_RARITY = {}
for c in CHARMS:
    CHARMS_BY_RARITY.setdefault(c["rarity"], []).append(c)

# ========== НАЖИВКА / ВОБЛЕРЫ ==========
# luck_bonus: + к лёгкости, rarity_bonus: + к шансу редкой рыбы, price_bonus: + к цене, uses: сколько забросов держит (0 = бесконечно)
BAITS = [
    {"id":  1, "loc": 1, "name": "Хлеб", "price": 2, "luck_bonus": 1, "rarity_bonus": 0, "price_bonus": 0, "uses": 40, "emoji": ""},
    {"id":  2, "loc": 1, "name": "Мотыль", "price": 6, "luck_bonus": 3, "rarity_bonus": 1, "price_bonus": 2, "uses": 25, "emoji": ""},
    {"id":  3, "loc": 1, "name": "Опарыш", "price": 12, "luck_bonus": 4, "rarity_bonus": 2, "price_bonus": 3, "uses": 25, "emoji": ""},
    {"id":  4, "loc": 1, "name": "Кукуруза", "price": 18, "luck_bonus": 5, "rarity_bonus": 2, "price_bonus": 4, "uses": 20, "emoji": ""},
    {"id":  5, "loc": 1, "name": "Воблер «Minnow»", "price": 60, "luck_bonus": 8, "rarity_bonus": 4, "price_bonus": 6, "uses": 12, "emoji": ""},
    {"id":  6, "loc": 1, "name": "Воблер «Crank»", "price": 130, "luck_bonus": 10, "rarity_bonus": 6, "price_bonus": 9, "uses": 12, "emoji": ""},
    {"id":  7, "loc": 1, "name": "Блесна «Вертушка»", "price": 90, "luck_bonus": 9, "rarity_bonus": 5, "price_bonus": 8, "uses": 12, "emoji": ""},
    {"id":  8, "loc": 1, "name": "Мормышка «Капля»", "price": 30, "luck_bonus": 4, "rarity_bonus": 2, "price_bonus": 3, "uses": 18, "emoji": ""},
    {"id":  9, "loc": 2, "name": "Креветка", "price": 2420, "luck_bonus": 8, "rarity_bonus": 5, "price_bonus": 8, "uses": 20, "emoji": ""},
    {"id": 10, "loc": 2, "name": "Кальмар", "price": 3300, "luck_bonus": 10, "rarity_bonus": 7, "price_bonus": 10, "uses": 18, "emoji": ""},
    {"id": 11, "loc": 2, "name": "Песчаный червь", "price": 4620, "luck_bonus": 12, "rarity_bonus": 8, "price_bonus": 12, "uses": 16, "emoji": ""},
    {"id": 12, "loc": 2, "name": "Воблер «Sardine»", "price": 7040, "luck_bonus": 15, "rarity_bonus": 10, "price_bonus": 15, "uses": 12, "emoji": ""},
    {"id": 13, "loc": 2, "name": "Джиг «Pilker»", "price": 9680, "luck_bonus": 18, "rarity_bonus": 13, "price_bonus": 18, "uses": 12, "emoji": ""},
    {"id": 14, "loc": 2, "name": "Блесна морская", "price": 5720, "luck_bonus": 13, "rarity_bonus": 9, "price_bonus": 13, "uses": 14, "emoji": ""},
    {"id": 15, "loc": 3, "name": "Живая сардина", "price": 11200, "luck_bonus": 12, "rarity_bonus": 8, "price_bonus": 12, "uses": 16, "emoji": ""},
    {"id": 16, "loc": 3, "name": "Кальмар гигантский", "price": 19200, "luck_bonus": 15, "rarity_bonus": 11, "price_bonus": 15, "uses": 14, "emoji": ""},
    {"id": 17, "loc": 3, "name": "Воблер «Tuna»", "price": 36800, "luck_bonus": 20, "rarity_bonus": 15, "price_bonus": 20, "uses": 12, "emoji": ""},
    {"id": 18, "loc": 3, "name": "Троллинговая приманка", "price": 59200, "luck_bonus": 24, "rarity_bonus": 18, "price_bonus": 24, "uses": 10, "emoji": ""},
    {"id": 19, "loc": 3, "name": "Живой осьминог", "price": 28800, "luck_bonus": 18, "rarity_bonus": 13, "price_bonus": 18, "uses": 12, "emoji": ""},
    {"id": 20, "loc": 3, "name": "Воблер «Marlin» золотой", "price": 83200, "luck_bonus": 30, "rarity_bonus": 22, "price_bonus": 30, "uses": 10, "emoji": ""},
]
BAITS_BY_ID = {b["id"]: b for b in BAITS}

# ========== РЫБЫ (200 шт) ==========
# price — базовая цена продажи, wmin/wmax — вес кг, difficulty — сложность мини-игры 1..20 (сколько попаданий нужно)
FISH = [
    # ---- ЛОКАЦИЯ 1: Пресноводные (70 шт) ----
    {"id": 1,   "loc": 1, "name": "Плотва",                    "rarity": "common",     "price": 25,    "wmin": 0.1, "wmax": 0.5,  "difficulty": 1,  "emoji": "🐟"},
    {"id": 2,   "loc": 1, "name": "Уклейка",                   "rarity": "common",     "price": 20,    "wmin": 0.05,"wmax": 0.3,  "difficulty": 1,  "emoji": "🐟"},
    {"id": 3,   "loc": 1, "name": "Карась серебряный",         "rarity": "common",     "price": 35,    "wmin": 0.2, "wmax": 1.0,  "difficulty": 1,  "emoji": "🐠"},
    {"id": 4,   "loc": 1, "name": "Карась красный",            "rarity": "common",     "price": 40,    "wmin": 0.2, "wmax": 1.2,  "difficulty": 1,  "emoji": "🐠"},
    {"id": 5,   "loc": 1, "name": "Ерш",                       "rarity": "common",     "price": 30,    "wmin": 0.05,"wmax": 0.3,  "difficulty": 1,  "emoji": "🐡"},
    {"id": 6,   "loc": 1, "name": "Ротан",                     "rarity": "common",     "price": 30,    "wmin": 0.1, "wmax": 0.4,  "difficulty": 1,  "emoji": "🐟"},
    {"id": 7,   "loc": 1, "name": "Верховка",                  "rarity": "common",     "price": 20,    "wmin": 0.03,"wmax": 0.15, "difficulty": 1,  "emoji": "🐟"},
    {"id": 8,   "loc": 1, "name": "Гольян",                    "rarity": "common",     "price": 25,    "wmin": 0.05,"wmax": 0.25, "difficulty": 1,  "emoji": "🐟"},
    {"id": 9,   "loc": 1, "name": "Пескарь",                   "rarity": "common",     "price": 25,    "wmin": 0.05,"wmax": 0.3,  "difficulty": 1,  "emoji": "🐟"},
    {"id": 10,  "loc": 1, "name": "Краснопёрка",              "rarity": "common",     "price": 30,    "wmin": 0.1, "wmax": 0.6,  "difficulty": 2,  "emoji": "🐠"},
    {"id": 11,  "loc": 1, "name": "Окунь речной",              "rarity": "uncommon",   "price": 60,    "wmin": 0.1, "wmax": 0.8,  "difficulty": 2,  "emoji": "🐠"},
    {"id": 12,  "loc": 1, "name": "Лещ",                       "rarity": "uncommon",   "price": 80,    "wmin": 0.3, "wmax": 2.0,  "difficulty": 2,  "emoji": "🐟"},
    {"id": 13,  "loc": 1, "name": "Густера",                   "rarity": "uncommon",   "price": 55,    "wmin": 0.1, "wmax": 0.5,  "difficulty": 2,  "emoji": "🐟"},
    {"id": 14,  "loc": 1, "name": "Подлещик",                  "rarity": "uncommon",   "price": 65,    "wmin": 0.2, "wmax": 1.0,  "difficulty": 2,  "emoji": "🐟"},
    {"id": 15,  "loc": 1, "name": "Чехонь",                    "rarity": "uncommon",   "price": 70,    "wmin": 0.2, "wmax": 0.8,  "difficulty": 2,  "emoji": "🐟"},
    {"id": 16,  "loc": 1, "name": "Язь",                       "rarity": "uncommon",   "price": 85,    "wmin": 0.3, "wmax": 1.5,  "difficulty": 3,  "emoji": "🐟"},
    {"id": 17,  "loc": 1, "name": "Голавль",                   "rarity": "uncommon",   "price": 90,    "wmin": 0.3, "wmax": 1.8,  "difficulty": 3,  "emoji": "🐟"},
    {"id": 18,  "loc": 1, "name": "Елец",                      "rarity": "uncommon",   "price": 60,    "wmin": 0.1, "wmax": 0.5,  "difficulty": 2,  "emoji": "🐟"},
    {"id": 19,  "loc": 1, "name": "Жерех",                     "rarity": "uncommon",   "price": 110,   "wmin": 0.5, "wmax": 2.5,  "difficulty": 3,  "emoji": "🐟"},
    {"id": 20,  "loc": 1, "name": "Линь",                      "rarity": "uncommon",   "price": 95,    "wmin": 0.3, "wmax": 2.0,  "difficulty": 3,  "emoji": "🐠"},
    {"id": 21,  "loc": 1, "name": "Щука",                      "rarity": "rare",       "price": 180,   "wmin": 0.5, "wmax": 5.0,  "difficulty": 4,  "emoji": "🐊"},
    {"id": 22,  "loc": 1, "name": "Судак",                     "rarity": "rare",       "price": 220,   "wmin": 0.5, "wmax": 4.0,  "difficulty": 4,  "emoji": "🐟"},
    {"id": 23,  "loc": 1, "name": "Сом",                       "rarity": "rare",       "price": 260,   "wmin": 1.0, "wmax": 10.0, "difficulty": 5,  "emoji": "🐈"},
    {"id": 24,  "loc": 1, "name": "Карп",                      "rarity": "rare",       "price": 200,   "wmin": 0.5, "wmax": 8.0,  "difficulty": 4,  "emoji": "🐠"},
    {"id": 25,  "loc": 1, "name": "Сазан",                     "rarity": "rare",       "price": 240,   "wmin": 0.8, "wmax": 12.0, "difficulty": 5,  "emoji": "🐠"},
    {"id": 26,  "loc": 1, "name": "Налим",                     "rarity": "rare",       "price": 190,   "wmin": 0.3, "wmax": 3.0,  "difficulty": 4,  "emoji": "🐟"},
    {"id": 27,  "loc": 1, "name": "Форель речная",             "rarity": "rare",       "price": 300,   "wmin": 0.2, "wmax": 1.5,  "difficulty": 5,  "emoji": "🐟"},
    {"id": 28,  "loc": 1, "name": "Хариус",                    "rarity": "rare",       "price": 280,   "wmin": 0.2, "wmax": 1.2,  "difficulty": 5,  "emoji": "🐟"},
    {"id": 29,  "loc": 1, "name": "Усач",                      "rarity": "rare",       "price": 210,   "wmin": 0.5, "wmax": 4.0,  "difficulty": 4,  "emoji": "🐟"},
    {"id": 30,  "loc": 1, "name": "Толстолобик",              "rarity": "rare",       "price": 230,   "wmin": 1.0, "wmax": 15.0, "difficulty": 5,  "emoji": "🐠"},
    {"id": 31,  "loc": 1, "name": "Осётр",                     "rarity": "super_rare", "price": 600,   "wmin": 2.0, "wmax": 20.0, "difficulty": 7,  "emoji": "🦕"},
    {"id": 32,  "loc": 1, "name": "Севрюга",                   "rarity": "super_rare", "price": 700,   "wmin": 2.0, "wmax": 25.0, "difficulty": 7,  "emoji": "🦕"},
    {"id": 33,  "loc": 1, "name": "Таймень",                   "rarity": "super_rare", "price": 650,   "wmin": 1.0, "wmax": 15.0, "difficulty": 7,  "emoji": "🐟"},
    {"id": 34,  "loc": 1, "name": "Ленок",                     "rarity": "super_rare", "price": 550,   "wmin": 0.5, "wmax": 5.0,  "difficulty": 6,  "emoji": "🐟"},
    {"id": 35,  "loc": 1, "name": "Амур белый",               "rarity": "super_rare", "price": 500,   "wmin": 1.0, "wmax": 20.0, "difficulty": 6,  "emoji": "🐠"},
    {"id": 36,  "loc": 1, "name": "Амур чёрный",              "rarity": "super_rare", "price": 520,   "wmin": 1.0, "wmax": 18.0, "difficulty": 6,  "emoji": "🐠"},
    {"id": 37,  "loc": 1, "name": "Буффало",                   "rarity": "super_rare", "price": 580,   "wmin": 2.0, "wmax": 25.0, "difficulty": 7,  "emoji": "🐠"},
    {"id": 38,  "loc": 1, "name": "Канальный сом",            "rarity": "super_rare", "price": 620,   "wmin": 1.0, "wmax": 15.0, "difficulty": 7,  "emoji": "🐈"},
    {"id": 39,  "loc": 1, "name": "Белуга (молодь)",          "rarity": "super_rare", "price": 800,   "wmin": 3.0, "wmax": 30.0, "difficulty": 8,  "emoji": "🦕"},
    {"id": 40,  "loc": 1, "name": "Стерлядь",                  "rarity": "super_rare", "price": 480,   "wmin": 0.5, "wmax": 5.0,  "difficulty": 6,  "emoji": "🦕"},
    {"id": 41,  "loc": 1, "name": "Арапаима",                  "rarity": "epic",       "price": 1495,  "wmin": 5.0, "wmax": 50.0, "difficulty": 10, "emoji": "🐲"},
    {"id": 42,  "loc": 1, "name": "Пиранья речная",           "rarity": "epic",       "price": 1200,  "wmin": 0.3, "wmax": 2.0,  "difficulty": 9,  "emoji": "🐡"},
    {"id": 43,  "loc": 1, "name": "Пиранья чёрная",           "rarity": "epic",       "price": 1395,  "wmin": 0.5, "wmax": 3.0,  "difficulty": 10, "emoji": "🐡"},
    {"id": 44,  "loc": 1, "name": "Электрический сом",        "rarity": "epic",       "price": 1595,  "wmin": 1.0, "wmax": 8.0,  "difficulty": 10, "emoji": "⚡"},
    {"id": 45,  "loc": 1, "name": "Рыба-нож",                  "rarity": "epic",       "price": 1100,  "wmin": 0.2, "wmax": 1.0,  "difficulty": 9,  "emoji": "🔪"},
    {"id": 46,  "loc": 1, "name": "Азиатский арована",        "rarity": "epic",       "price": 1795,  "wmin": 0.5, "wmax": 3.0,  "difficulty": 10, "emoji": "🐉"},
    {"id": 47,  "loc": 1, "name": "Карп кои гигантский",      "rarity": "epic",       "price": 1995,  "wmin": 2.0, "wmax": 15.0, "difficulty": 11, "emoji": "🐠"},
    {"id": 48,  "loc": 1, "name": "Сом Меконга",               "rarity": "epic",       "price": 2195,  "wmin": 5.0, "wmax": 80.0, "difficulty": 12, "emoji": "🐈"},
    {"id": 49,  "loc": 1, "name": "Пиранья гигантская",       "rarity": "epic",       "price": 1695,  "wmin": 1.0, "wmax": 5.0,  "difficulty": 11, "emoji": "🐡"},
    {"id": 50,  "loc": 1, "name": "Арапаима гигантская",      "rarity": "epic",       "price": 2495,  "wmin": 10.0,"wmax": 100.0,"difficulty": 12, "emoji": "🐲"},
    {"id": 51,  "loc": 1, "name": "Белуга гигантская",        "rarity": "legendary",  "price": 4990,  "wmin": 20.0,"wmax": 200.0,"difficulty": 14, "emoji": "🦕"},
    {"id": 52,  "loc": 1, "name": "Осётр гигантский",         "rarity": "legendary",  "price": 4490,  "wmin": 15.0,"wmax": 150.0,"difficulty": 14, "emoji": "🦕"},
    {"id": 53,  "loc": 1, "name": "Сом Меконга гигантский",   "rarity": "legendary",  "price": 4790,  "wmin": 20.0,"wmax": 300.0,"difficulty": 15, "emoji": "🐈"},
    {"id": 54,  "loc": 1, "name": "Таймень гигантский",       "rarity": "legendary",  "price": 4190,  "wmin": 10.0,"wmax": 80.0, "difficulty": 14, "emoji": "🐟"},
    {"id": 55,  "loc": 1, "name": "Арапаима мега",            "rarity": "legendary",  "price": 5490,  "wmin": 30.0,"wmax": 200.0,"difficulty": 15, "emoji": "🐲"},
    {"id": 56,  "loc": 1, "name": "Золотая щука",             "rarity": "mythical",   "price": 9980, "wmin": 2.0, "wmax": 15.0, "difficulty": 16, "emoji": "👑"},
    {"id": 57,  "loc": 1, "name": "Золотой карп",             "rarity": "mythical",   "price": 10975, "wmin": 2.0, "wmax": 20.0, "difficulty": 16, "emoji": "👑"},
    {"id": 58,  "loc": 1, "name": "Алмазный осётр",           "rarity": "mythical",   "price": 11975, "wmin": 5.0, "wmax": 50.0, "difficulty": 17, "emoji": "💎"},
    {"id": 59,  "loc": 1, "name": "Золотой сом",              "rarity": "mythical",   "price": 10480, "wmin": 5.0, "wmax": 60.0, "difficulty": 16, "emoji": "👑"},
    {"id": 60,  "loc": 1, "name": "Золотая арапаима",         "rarity": "mythical",   "price": 12975, "wmin": 10.0,"wmax": 80.0, "difficulty": 17, "emoji": "👑"},
    {"id": 61,  "loc": 1, "name": "Золотая белуга",           "rarity": "golden",     "price": 19960, "wmin": 30.0,"wmax": 300.0,"difficulty": 18, "emoji": "👑"},
    {"id": 62,  "loc": 1, "name": "Золотой осётр",            "rarity": "golden",     "price": 18960, "wmin": 20.0,"wmax": 200.0,"difficulty": 18, "emoji": "👑"},
    {"id": 63,  "loc": 1, "name": "Золотой сом Меконга",      "rarity": "golden",     "price": 20955, "wmin": 30.0,"wmax": 300.0,"difficulty": 19, "emoji": "👑"},
    {"id": 64,  "loc": 1, "name": "Золотая пиранья",          "rarity": "golden",     "price": 17965, "wmin": 2.0, "wmax": 8.0,  "difficulty": 18, "emoji": "👑"},
    {"id": 65,  "loc": 1, "name": "Золотой таймень",          "rarity": "golden",     "price": 17465, "wmin": 15.0,"wmax": 100.0,"difficulty": 18, "emoji": "👑"},
    {"id": 66,  "loc": 1, "name": "Сом-альбинос",             "rarity": "super_rare", "price": 900,   "wmin": 2.0, "wmax": 20.0, "difficulty": 8,  "emoji": "🐈"},
    {"id": 67,  "loc": 1, "name": "Щука-альбинос",            "rarity": "super_rare", "price": 850,   "wmin": 1.0, "wmax": 8.0,  "difficulty": 8,  "emoji": "🐊"},
    {"id": 68, "name": "Карп-зеркальный", "loc": 1, "rarity": "rare", "price": 260, "wmin": 1.0, "wmax": 10.0, "difficulty": 5, "emoji": "🐠"},
    {"id": 69, "name": "Судак гигантский", "loc": 1, "rarity": "super_rare", "price": 750, "wmin": 2.0, "wmax": 12.0, "difficulty": 8, "emoji": "🐟"},
    {"id": 70, "name": "Щука гигантская", "loc": 1, "rarity": "super_rare", "price": 780, "wmin": 3.0, "wmax": 15.0, "difficulty": 8, "emoji": "🐊"},

    # ---- ЛОКАЦИЯ 2: Морские (65 шт, id 71-135) ----
    {"id": 71,  "loc": 2, "name": "Бычок",                    "rarity": "common",     "price": 50,   "wmin": 0.05,"wmax": 0.3,  "difficulty": 2,  "emoji": "🐟"},
    {"id": 72,  "loc": 2, "name": "Сардина",                  "rarity": "common",     "price": 45,   "wmin": 0.05,"wmax": 0.25, "difficulty": 2,  "emoji": "🐟"},
    {"id": 73,  "loc": 2, "name": "Анчоус",                   "rarity": "common",     "price": 50,   "wmin": 0.03,"wmax": 0.2,  "difficulty": 2,  "emoji": "🐟"},
    {"id": 74,  "loc": 2, "name": "Ставрида",                 "rarity": "common",     "price": 60,   "wmin": 0.1, "wmax": 0.6,  "difficulty": 2,  "emoji": "🐟"},
    {"id": 75,  "loc": 2, "name": "Скумбрия",                 "rarity": "common",     "price": 65,  "wmin": 0.2, "wmax": 0.8,  "difficulty": 2,  "emoji": "🐟"},
    {"id": 76,  "loc": 2, "name": "Кефаль",                   "rarity": "common",     "price": 70,  "wmin": 0.3, "wmax": 1.5,  "difficulty": 3,  "emoji": "🐟"},
    {"id": 77,  "loc": 2, "name": "Пикша",                    "rarity": "common",     "price": 75,  "wmin": 0.3, "wmax": 2.0,  "difficulty": 3,  "emoji": "🐟"},
    {"id": 78,  "loc": 2, "name": "Треска",                   "rarity": "common",     "price": 90,  "wmin": 0.5, "wmax": 4.0,  "difficulty": 3,  "emoji": "🐟"},
    {"id": 79,  "loc": 2, "name": "Хек",                      "rarity": "common",     "price": 80,  "wmin": 0.3, "wmax": 2.5,  "difficulty": 3,  "emoji": "🐟"},
    {"id": 80,  "loc": 2, "name": "Камбала",                  "rarity": "common",     "price": 95,  "wmin": 0.3, "wmax": 3.0,  "difficulty": 3,  "emoji": "🐠"},
    {"id": 81,  "loc": 2, "name": "Морской окунь",            "rarity": "uncommon",   "price": 160,  "wmin": 0.3, "wmax": 2.0,  "difficulty": 4,  "emoji": "🐠"},
    {"id": 82,  "loc": 2, "name": "Палтус",                   "rarity": "uncommon",   "price": 205,  "wmin": 0.5, "wmax": 5.0,  "difficulty": 4,  "emoji": "🐟"},
    {"id": 83,  "loc": 2, "name": "Зубатка",                  "rarity": "uncommon",   "price": 180,  "wmin": 0.5, "wmax": 4.0,  "difficulty": 4,  "emoji": "🐟"},
    {"id": 84,  "loc": 2, "name": "Морской чёрт",             "rarity": "uncommon",   "price": 190,  "wmin": 0.5, "wmax": 3.0,  "difficulty": 4,  "emoji": "👹"},
    {"id": 85,  "loc": 2, "name": "Дорада",                   "rarity": "uncommon",   "price": 225,  "wmin": 0.3, "wmax": 2.0,  "difficulty": 4,  "emoji": "🐟"},
    {"id": 86,  "loc": 2, "name": "Сибас",                    "rarity": "uncommon",   "price": 215,  "wmin": 0.3, "wmax": 2.5,  "difficulty": 4,  "emoji": "🐟"},
    {"id": 87,  "loc": 2, "name": "Морской язык",             "rarity": "uncommon",   "price": 165,  "wmin": 0.2, "wmax": 1.5,  "difficulty": 4,  "emoji": "🐠"},
    {"id": 88,  "loc": 2, "name": "Морской налим",            "rarity": "uncommon",   "price": 150,  "wmin": 0.3, "wmax": 2.0,  "difficulty": 4,  "emoji": "🐟"},
    {"id": 89,  "loc": 2, "name": "Морской сом",              "rarity": "uncommon",   "price": 170,  "wmin": 0.5, "wmax": 3.0,  "difficulty": 4,  "emoji": "🐈"},
    {"id": 90,  "loc": 2, "name": "Морской ангел",            "rarity": "uncommon",   "price": 240,  "wmin": 0.2, "wmax": 1.0,  "difficulty": 5,  "emoji": "👼"},
    {"id": 91,  "loc": 2, "name": "Рыба-попугай",             "rarity": "rare",       "price": 380,  "wmin": 0.3, "wmax": 2.0,  "difficulty": 6,  "emoji": "🦜"},
    {"id": 92,  "loc": 2, "name": "Рыба-клоун гигантская",    "rarity": "rare",       "price": 350,  "wmin": 0.1, "wmax": 0.5,  "difficulty": 6,  "emoji": "🤡"},
    {"id": 93,  "loc": 2, "name": "Наполеон",                 "rarity": "rare",       "price": 445,  "wmin": 1.0, "wmax": 8.0,  "difficulty": 6,  "emoji": "🐠"},
    {"id": 94,  "loc": 2, "name": "Групер",                   "rarity": "rare",       "price": 510,  "wmin": 1.0, "wmax": 15.0, "difficulty": 7,  "emoji": "🐠"},
    {"id": 95,  "loc": 2, "name": "Морской окунь гигантский", "rarity": "rare",       "price": 415,  "wmin": 1.0, "wmax": 10.0, "difficulty": 6,  "emoji": "🐠"},
    {"id": 96,  "loc": 2, "name": "Палтус гигантский",        "rarity": "rare",       "price": 480,  "wmin": 2.0, "wmax": 20.0, "difficulty": 7,  "emoji": "🐟"},
    {"id": 97,  "loc": 2, "name": "Треска гигантская",        "rarity": "rare",       "price": 435,  "wmin": 2.0, "wmax": 15.0, "difficulty": 6,  "emoji": "🐟"},
    {"id": 98,  "loc": 2, "name": "Морской чёрт гигантский",  "rarity": "rare",       "price": 460,  "wmin": 1.0, "wmax": 10.0, "difficulty": 7,  "emoji": "👹"},
    {"id": 99,  "loc": 2, "name": "Рыба-хирург",              "rarity": "rare",       "price": 370,  "wmin": 0.2, "wmax": 1.0,  "difficulty": 6,  "emoji": "🔪"},
    {"id": 100, "loc": 2, "name": "Рыба-зебра",               "rarity": "rare",       "price": 360,  "wmin": 0.1, "wmax": 0.6,  "difficulty": 6,  "emoji": "🦓"},
    {"id": 101, "loc": 2, "name": "Морской конёк гигантский", "rarity": "super_rare", "price": 955, "wmin": 0.1, "wmax": 0.4,  "difficulty": 8,  "emoji": "🐴"},
    {"id": 102, "loc": 2, "name": "Рыба-меч морская",         "rarity": "super_rare", "price": 1150, "wmin": 5.0, "wmax": 50.0, "difficulty": 9,  "emoji": "⚔️"},
    {"id": 103, "loc": 2, "name": "Групер гигантский",        "rarity": "super_rare", "price": 1020, "wmin": 5.0, "wmax": 80.0, "difficulty": 9,  "emoji": "🐠"},
    {"id": 104, "loc": 2, "name": "Морской окунь «Каменный»", "rarity": "super_rare", "price": 890, "wmin": 1.0, "wmax": 12.0, "difficulty": 8,  "emoji": "🪨"},
    {"id": 105, "loc": 2, "name": "Рыба-скорпион",            "rarity": "super_rare", "price": 860, "wmin": 0.3, "wmax": 2.0,  "difficulty": 8,  "emoji": "🦂"},
    {"id": 106, "loc": 2, "name": "Рыба-камень",              "rarity": "super_rare", "price": 925, "wmin": 0.5, "wmax": 3.0,  "difficulty": 8,  "emoji": "🪨"},
    {"id": 107, "loc": 2, "name": "Морской ангел гигантский", "rarity": "super_rare", "price": 990, "wmin": 0.5, "wmax": 3.0,  "difficulty": 8,  "emoji": "👼"},
    {"id": 108, "loc": 2, "name": "Рыба-пила морская",        "rarity": "super_rare", "price": 1085, "wmin": 2.0, "wmax": 20.0, "difficulty": 9,  "emoji": "🪚"},
    {"id": 109, "loc": 2, "name": "Морской дракон",          "rarity": "super_rare", "price": 1210, "wmin": 0.2, "wmax": 0.8,  "difficulty": 9,  "emoji": "🐉"},
    {"id": 110, "loc": 2, "name": "Рыба-лев",                 "rarity": "super_rare", "price": 880, "wmin": 0.2, "wmax": 1.0,  "difficulty": 8,  "emoji": "🦁"},
    {"id": 111, "loc": 2, "name": "Гигантский групер",        "rarity": "epic",       "price": 2230, "wmin": 10.0,"wmax": 150.0,"difficulty": 11, "emoji": "🐠"},
    {"id": 112, "loc": 2, "name": "Рыба-меч гигантская",      "rarity": "epic",       "price": 2425, "wmin": 10.0,"wmax": 100.0,"difficulty": 11, "emoji": "⚔️"},
    {"id": 113, "loc": 2, "name": "Морской окунь мега",       "rarity": "epic",       "price": 2040, "wmin": 5.0, "wmax": 50.0, "difficulty": 10, "emoji": "🐠"},
    {"id": 114, "loc": 2, "name": "Палтус мега",              "rarity": "epic",       "price": 2170, "wmin": 10.0,"wmax": 100.0,"difficulty": 11, "emoji": "🐟"},
    {"id": 115, "loc": 2, "name": "Наполеон гигантский",      "rarity": "epic",       "price": 2295, "wmin": 5.0, "wmax": 40.0, "difficulty": 11, "emoji": "🐠"},
    {"id": 116, "loc": 2, "name": "Рыба-попугай гигантская",  "rarity": "epic",       "price": 2105, "wmin": 2.0, "wmax": 15.0, "difficulty": 10, "emoji": "🦜"},
    {"id": 117, "loc": 2, "name": "Морской чёрт мега",        "rarity": "epic",       "price": 2360, "wmin": 5.0, "wmax": 60.0, "difficulty": 11, "emoji": "👹"},
    {"id": 118, "loc": 2, "name": "Рыба-хирург гигантская",   "rarity": "epic",       "price": 1975, "wmin": 1.0, "wmax": 8.0,  "difficulty": 10, "emoji": "🔪"},
    {"id": 119, "loc": 2, "name": "Морской дракон гигантский","rarity": "epic",       "price": 2550, "wmin": 0.5, "wmax": 2.0,  "difficulty": 12, "emoji": "🐉"},
    {"id": 120, "loc": 2, "name": "Рыба-пила гигантская",     "rarity": "epic",       "price": 2490, "wmin": 5.0, "wmax": 50.0, "difficulty": 12, "emoji": "🪚"},
    {"id": 121, "loc": 2, "name": "Гигантский палтус",        "rarity": "legendary",  "price": 5100, "wmin": 20.0,"wmax": 200.0,"difficulty": 14, "emoji": "🐟"},
    {"id": 122, "loc": 2, "name": "Гигантский групер мега",   "rarity": "legendary",  "price": 5420, "wmin": 30.0,"wmax": 300.0,"difficulty": 15, "emoji": "🐠"},
    {"id": 123, "loc": 2, "name": "Гигантская рыба-меч",      "rarity": "legendary",  "price": 5740, "wmin": 20.0,"wmax": 200.0,"difficulty": 15, "emoji": "⚔️"},
    {"id": 124, "loc": 2, "name": "Гигантский наполеон",      "rarity": "legendary",  "price": 5230, "wmin": 15.0,"wmax": 100.0,"difficulty": 14, "emoji": "🐠"},
    {"id": 125, "loc": 2, "name": "Гигантский морской чёрт",  "rarity": "legendary",  "price": 5610, "wmin": 15.0,"wmax": 120.0,"difficulty": 15, "emoji": "👹"},
    {"id": 126, "loc": 2, "name": "Золотой групер",           "rarity": "mythical",   "price": 9565,"wmin": 10.0,"wmax": 100.0,"difficulty": 16, "emoji": "👑"},
    {"id": 127, "loc": 2, "name": "Золотой палтус",           "rarity": "mythical",   "price": 9245,"wmin": 10.0,"wmax": 120.0,"difficulty": 16, "emoji": "👑"},
    {"id": 128, "loc": 2, "name": "Золотая рыба-меч",         "rarity": "mythical",   "price": 10200,"wmin": 10.0,"wmax": 100.0,"difficulty": 17, "emoji": "👑"},
    {"id": 129, "loc": 2, "name": "Золотой наполеон",         "rarity": "mythical",   "price": 9885,"wmin": 8.0, "wmax": 60.0, "difficulty": 16, "emoji": "👑"},
    {"id": 130, "loc": 2, "name": "Золотой морской чёрт",     "rarity": "mythical",   "price": 10075,"wmin": 8.0, "wmax": 80.0, "difficulty": 17, "emoji": "👑"},
    {"id": 131, "loc": 2, "name": "Золотой групер мега",      "rarity": "golden",     "price": 15940,"wmin": 30.0,"wmax": 300.0,"difficulty": 18, "emoji": "👑"},
    {"id": 132, "loc": 2, "name": "Золотой палтус мега",      "rarity": "golden",     "price": 15305,"wmin": 30.0,"wmax": 250.0,"difficulty": 18, "emoji": "👑"},
    {"id": 133, "loc": 2, "name": "Золотая рыба-меч мега",    "rarity": "golden",     "price": 16580,"wmin": 30.0,"wmax": 250.0,"difficulty": 19, "emoji": "👑"},
    {"id": 134, "loc": 2, "name": "Золотой дракон",          "rarity": "golden",     "price": 17220,"wmin": 1.0, "wmax": 3.0,  "difficulty": 19, "emoji": "👑"},
    {"id": 135, "loc": 2, "name": "Золотой наполеон мега",    "rarity": "golden",     "price": 15625,"wmin": 20.0,"wmax": 120.0,"difficulty": 18, "emoji": "👑"},

    # ---- ЛОКАЦИЯ 3: Океан (65 шт, id 136-200) ----
    {"id": 136, "loc": 3, "name": "Сардина океаническая",     "rarity": "common",     "price": 80, "wmin": 0.05,"wmax": 0.3,  "difficulty": 3,  "emoji": "🐟"},
    {"id": 137, "loc": 3, "name": "Скумбрия океаническая",    "rarity": "common",     "price": 95, "wmin": 0.2, "wmax": 1.0,  "difficulty": 3,  "emoji": "🐟"},
    {"id": 138, "loc": 3, "name": "Ставрида океаническая",    "rarity": "common",     "price": 90, "wmin": 0.1, "wmax": 0.8,  "difficulty": 3,  "emoji": "🐟"},
    {"id": 139, "loc": 3, "name": "Кефаль океаническая",      "rarity": "common",     "price": 105, "wmin": 0.3, "wmax": 2.0,  "difficulty": 3,  "emoji": "🐟"},
    {"id": 140, "loc": 3, "name": "Треска океаническая",      "rarity": "common",     "price": 135, "wmin": 0.5, "wmax": 5.0,  "difficulty": 4,  "emoji": "🐟"},
    {"id": 141, "loc": 3, "name": "Палтус океанический",      "rarity": "common",     "price": 150, "wmin": 0.5, "wmax": 6.0,  "difficulty": 4,  "emoji": "🐟"},
    {"id": 142, "loc": 3, "name": "Морской окунь океанический","rarity": "common",     "price": 140, "wmin": 0.3, "wmax": 3.0,  "difficulty": 4,  "emoji": "🐠"},
    {"id": 143, "loc": 3, "name": "Камбала океаническая",     "rarity": "common",     "price": 130, "wmin": 0.3, "wmax": 4.0,  "difficulty": 4,  "emoji": "🐠"},
    {"id": 144, "loc": 3, "name": "Хек океанический",         "rarity": "common",     "price": 125, "wmin": 0.3, "wmax": 3.0,  "difficulty": 4,  "emoji": "🐟"},
    {"id": 145, "loc": 3, "name": "Зубатка океаническая",     "rarity": "common",     "price": 145, "wmin": 0.5, "wmax": 5.0,  "difficulty": 4,  "emoji": "🐟"},
    {"id": 146, "loc": 3, "name": "Тунец полосатый",          "rarity": "uncommon",   "price": 240, "wmin": 1.0, "wmax": 8.0,  "difficulty": 5,  "emoji": "🐟"},
    {"id": 147, "loc": 3, "name": "Тунец желтопёрый",         "rarity": "uncommon",   "price": 295, "wmin": 2.0, "wmax": 20.0, "difficulty": 5,  "emoji": "🐟"},
    {"id": 148, "loc": 3, "name": "Марлин полосатый",         "rarity": "uncommon",   "price": 320, "wmin": 5.0, "wmax": 40.0, "difficulty": 6,  "emoji": "🐟"},
    {"id": 149, "loc": 3, "name": "Парусник",                 "rarity": "uncommon",   "price": 345, "wmin": 5.0, "wmax": 50.0, "difficulty": 6,  "emoji": "⛵"},
    {"id": 150, "loc": 3, "name": "Рыба-меч океаническая",    "rarity": "uncommon",   "price": 375, "wmin": 10.0,"wmax": 80.0, "difficulty": 6,  "emoji": "⚔️"},
    {"id": 151, "loc": 3, "name": "Дорада океаническая",      "rarity": "uncommon",   "price": 255, "wmin": 0.5, "wmax": 3.0,  "difficulty": 5,  "emoji": "🐟"},
    {"id": 152, "loc": 3, "name": "Сибас океанический",       "rarity": "uncommon",   "price": 265, "wmin": 0.5, "wmax": 4.0,  "difficulty": 5,  "emoji": "🐟"},
    {"id": 153, "loc": 3, "name": "Морской ангел океанический","rarity": "uncommon",   "price": 280, "wmin": 0.3, "wmax": 2.0,  "difficulty": 5,  "emoji": "👼"},
    {"id": 154, "loc": 3, "name": "Рыба-попугай океаническая","rarity": "uncommon",   "price": 290, "wmin": 0.5, "wmax": 3.0,  "difficulty": 5,  "emoji": "🦜"},
    {"id": 155, "loc": 3, "name": "Наполеон океанический",     "rarity": "uncommon",   "price": 310, "wmin": 2.0, "wmax": 15.0, "difficulty": 6,  "emoji": "🐠"},
    {"id": 156, "loc": 3, "name": "Тунец голубой",            "rarity": "rare",       "price": 640,"wmin": 5.0, "wmax": 100.0,"difficulty": 8,  "emoji": "🐟"},
    {"id": 157, "loc": 3, "name": "Марлин голубой",            "rarity": "rare",       "price": 745,"wmin": 10.0,"wmax": 150.0,"difficulty": 8,  "emoji": "🐟"},
    {"id": 158, "loc": 3, "name": "Парусник гигантский",      "rarity": "rare",       "price": 695,"wmin": 10.0,"wmax": 100.0,"difficulty": 8,  "emoji": "⛵"},
    {"id": 159, "loc": 3, "name": "Рыба-меч гигантская",      "rarity": "rare",       "price": 720,"wmin": 15.0,"wmax": 150.0,"difficulty": 8,  "emoji": "⚔️"},
    {"id": 160, "loc": 3, "name": "Акула белая",              "rarity": "rare",       "price": 960,"wmin": 20.0,"wmax": 200.0,"difficulty": 9,  "emoji": "🦈"},
    {"id": 161, "loc": 3, "name": "Акула-молот",              "rarity": "rare",       "price": 855,"wmin": 10.0,"wmax": 150.0,"difficulty": 9,  "emoji": "🔨"},
    {"id": 162, "loc": 3, "name": "Акула-тигр",               "rarity": "rare",       "price": 825,"wmin": 10.0,"wmax": 120.0,"difficulty": 9,  "emoji": "🐯"},
    {"id": 163, "loc": 3, "name": "Скат манта",               "rarity": "rare",       "price": 665,"wmin": 5.0, "wmax": 50.0, "difficulty": 8,  "emoji": "🦇"},
    {"id": 164, "loc": 3, "name": "Рыба-пила океаническая",   "rarity": "rare",       "price": 775,"wmin": 5.0, "wmax": 60.0, "difficulty": 8,  "emoji": "🪚"},
    {"id": 165, "loc": 3, "name": "Океанический окунь",       "rarity": "rare",       "price": 615,"wmin": 2.0, "wmax": 20.0, "difficulty": 7,  "emoji": "🐠"},
    {"id": 166, "loc": 3, "name": "Гигантский тунец",         "rarity": "super_rare", "price": 1600,"wmin": 20.0,"wmax": 300.0,"difficulty": 10, "emoji": "🐟"},
    {"id": 167, "loc": 3, "name": "Гигантский марлин",        "rarity": "super_rare", "price": 1705,"wmin": 20.0,"wmax": 250.0,"difficulty": 10, "emoji": "🐟"},
    {"id": 168, "loc": 3, "name": "Гигантский парусник",      "rarity": "super_rare", "price": 1655,"wmin": 15.0,"wmax": 200.0,"difficulty": 10, "emoji": "⛵"},
    {"id": 169, "loc": 3, "name": "Гигантская рыба-меч",      "rarity": "super_rare", "price": 1760,"wmin": 25.0,"wmax": 300.0,"difficulty": 11, "emoji": "⚔️"},
    {"id": 170, "loc": 3, "name": "Белая акула гигантская",   "rarity": "super_rare", "price": 2135,"wmin": 50.0,"wmax": 400.0,"difficulty": 11, "emoji": "🦈"},
    {"id": 171, "loc": 3, "name": "Акула-молот гигантская",   "rarity": "super_rare", "price": 1920,"wmin": 20.0,"wmax": 250.0,"difficulty": 11, "emoji": "🔨"},
    {"id": 172, "loc": 3, "name": "Акула-тигр гигантская",    "rarity": "super_rare", "price": 1865,"wmin": 20.0,"wmax": 200.0,"difficulty": 11, "emoji": "🐯"},
    {"id": 173, "loc": 3, "name": "Скат манта гигантский",    "rarity": "super_rare", "price": 1545,"wmin": 10.0,"wmax": 100.0,"difficulty": 10, "emoji": "🦇"},
    {"id": 174, "loc": 3, "name": "Китовая акула",            "rarity": "super_rare", "price": 2030,"wmin": 50.0,"wmax": 500.0,"difficulty": 11, "emoji": "🐋"},
    {"id": 175, "loc": 3, "name": "Рыба-пила гигантская",     "rarity": "super_rare", "price": 1815,"wmin": 10.0,"wmax": 100.0,"difficulty": 10, "emoji": "🪚"},
    {"id": 176, "loc": 3, "name": "Тунец мега",               "rarity": "epic",       "price": 3735,"wmin": 50.0,"wmax": 500.0,"difficulty": 13, "emoji": "🐟"},
    {"id": 177, "loc": 3, "name": "Марлин мега",              "rarity": "epic",       "price": 4000,"wmin": 50.0,"wmax": 400.0,"difficulty": 13, "emoji": "🐟"},
    {"id": 178, "loc": 3, "name": "Парусник мега",            "rarity": "epic",       "price": 3840,"wmin": 30.0,"wmax": 300.0,"difficulty": 13, "emoji": "⛵"},
    {"id": 179, "loc": 3, "name": "Рыба-меч мега",            "rarity": "epic",       "price": 4160,"wmin": 50.0,"wmax": 500.0,"difficulty": 13, "emoji": "⚔️"},
    {"id": 180, "loc": 3, "name": "Белая акула мега",         "rarity": "epic",       "price": 4800,"wmin": 100.0,"wmax": 600.0,"difficulty": 14, "emoji": "🦈"},
    {"id": 181, "loc": 3, "name": "Китовая акула гигантская", "rarity": "epic",       "price": 4535,"wmin": 100.0,"wmax": 800.0,"difficulty": 14, "emoji": "🐋"},
    {"id": 182, "loc": 3, "name": "Акула-молот мега",         "rarity": "epic",       "price": 4375,"wmin": 50.0,"wmax": 400.0,"difficulty": 14, "emoji": "🔨"},
    {"id": 183, "loc": 3, "name": "Скат манта мега",          "rarity": "epic",       "price": 3630,"wmin": 20.0,"wmax": 200.0,"difficulty": 13, "emoji": "🦇"},
    {"id": 184, "loc": 3, "name": "Рыба-пила мега",           "rarity": "epic",       "price": 4055,"wmin": 20.0,"wmax": 200.0,"difficulty": 13, "emoji": "🪚"},
    {"id": 185, "loc": 3, "name": "Океанический окунь мега",  "rarity": "epic",       "price": 3470,"wmin": 10.0,"wmax": 100.0,"difficulty": 12, "emoji": "🐠"},
    {"id": 186, "loc": 3, "name": "Тунец гигантский мега",    "rarity": "legendary",  "price": 8005,"wmin": 100.0,"wmax": 800.0,"difficulty": 15, "emoji": "🐟"},
    {"id": 187, "loc": 3, "name": "Марлин гигантский мега",   "rarity": "legendary",  "price": 8535,"wmin": 100.0,"wmax": 700.0,"difficulty": 15, "emoji": "🐟"},
    {"id": 188, "loc": 3, "name": "Белая акула легенда",      "rarity": "legendary",  "price": 9605,"wmin": 150.0,"wmax": 800.0,"difficulty": 16, "emoji": "🦈"},
    {"id": 189, "loc": 3, "name": "Китовая акула легенда",    "rarity": "legendary",  "price": 9070,"wmin": 200.0,"wmax": 1000.0,"difficulty": 16,"emoji": "🐋"},
    {"id": 190, "loc": 3, "name": "Рыба-меч легенда",         "rarity": "legendary",  "price": 8805,"wmin": 100.0,"wmax": 700.0,"difficulty": 16, "emoji": "⚔️"},
    {"id": 191, "loc": 3, "name": "Золотой тунец",            "rarity": "mythical",   "price": 13340,"wmin": 50.0,"wmax": 500.0,"difficulty": 17, "emoji": "👑"},
    {"id": 192, "loc": 3, "name": "Золотой марлин",           "rarity": "mythical",   "price": 13870,"wmin": 50.0,"wmax": 400.0,"difficulty": 17, "emoji": "👑"},
    {"id": 193, "loc": 3, "name": "Золотая белая акула",      "rarity": "mythical",   "price": 14940,"wmin": 100.0,"wmax": 600.0,"difficulty": 18, "emoji": "👑"},
    {"id": 194, "loc": 3, "name": "Золотая китовая акула",    "rarity": "mythical",   "price": 14405,"wmin": 200.0,"wmax": 1000.0,"difficulty": 18, "emoji": "👑"},
    {"id": 195, "loc": 3, "name": "Золотая рыба-меч",         "rarity": "mythical",   "price": 14140,"wmin": 50.0,"wmax": 500.0,"difficulty": 17, "emoji": "👑"},
    {"id": 196, "loc": 3, "name": "Золотой тунец мега",       "rarity": "golden",     "price": 21340,"wmin": 100.0,"wmax": 800.0,"difficulty": 19, "emoji": "👑"},
    {"id": 197, "loc": 3, "name": "Золотой марлин мега",      "rarity": "golden",     "price": 22410,"wmin": 100.0,"wmax": 700.0,"difficulty": 19, "emoji": "👑"},
    {"id": 198, "loc": 3, "name": "Золотая белая акула мега", "rarity": "golden",     "price": 24010,"wmin": 150.0,"wmax": 800.0,"difficulty": 20, "emoji": "👑"},
    {"id": 199, "loc": 3, "name": "Золотая китовая акула мега","rarity": "golden",     "price": 23475,"wmin": 200.0,"wmax": 1200.0,"difficulty": 20,"emoji": "👑"},
    {"id": 200, "loc": 3, "name": "Золотая рыба-меч мега",    "rarity": "golden",     "price": 22940,"wmin": 100.0,"wmax": 700.0,"difficulty": 20, "emoji": "👑"},
]
UPGRADE_FISH = [{'id': 201, 'loc': 0, 'name': 'Лунный карп', 'rarity': 'mythical', 'price': 30000, 'wmin': 10, 'wmax': 50, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 202, 'loc': 0, 'name': 'Сапфировый скат', 'rarity': 'mythical', 'price': 40000, 'wmin': 15, 'wmax': 80, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 203, 'loc': 0, 'name': 'Кристальная мурена', 'rarity': 'mythical', 'price': 55000, 'wmin': 20, 'wmax': 110, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 204, 'loc': 0, 'name': 'Призрачный сом', 'rarity': 'mythical', 'price': 75000, 'wmin': 25, 'wmax': 140, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 205, 'loc': 0, 'name': 'Небесный марлин', 'rarity': 'mythical', 'price': 100000, 'wmin': 30, 'wmax': 170, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 206, 'loc': 0, 'name': 'Аметистовый осётр', 'rarity': 'mythical', 'price': 135000, 'wmin': 35, 'wmax': 200, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 207, 'loc': 0, 'name': 'Коралловый дракон', 'rarity': 'mythical', 'price': 180000, 'wmin': 40, 'wmax': 230, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 208, 'loc': 0, 'name': 'Солнечный тунец', 'rarity': 'mythical', 'price': 240000, 'wmin': 45, 'wmax': 260, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 209, 'loc': 0, 'name': 'Бездна: левиафан', 'rarity': 'mythical', 'price': 320000, 'wmin': 50, 'wmax': 290, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 210, 'loc': 0, 'name': 'Северное сияние', 'rarity': 'mythical', 'price': 420000, 'wmin': 55, 'wmax': 320, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 211, 'loc': 0, 'name': 'Морской феникс', 'rarity': 'golden', 'price': 550000, 'wmin': 60, 'wmax': 350, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 212, 'loc': 0, 'name': 'Полярный титан', 'rarity': 'golden', 'price': 700000, 'wmin': 65, 'wmax': 380, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 213, 'loc': 0, 'name': 'Звёздный кит', 'rarity': 'golden', 'price': 900000, 'wmin': 70, 'wmax': 410, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 214, 'loc': 0, 'name': 'Император рифа', 'rarity': 'golden', 'price': 1100000, 'wmin': 75, 'wmax': 440, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 215, 'loc': 0, 'name': 'Хранитель глубин', 'rarity': 'golden', 'price': 1400000, 'wmin': 80, 'wmax': 470, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 216, 'loc': 0, 'name': 'Серебряный кракен', 'rarity': 'golden', 'price': 1800000, 'wmin': 85, 'wmax': 500, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 217, 'loc': 0, 'name': 'Королевский дракон', 'rarity': 'golden', 'price': 2300000, 'wmin': 90, 'wmax': 530, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 218, 'loc': 0, 'name': 'Космический левиафан', 'rarity': 'golden', 'price': 3000000, 'wmin': 95, 'wmax': 560, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 219, 'loc': 0, 'name': 'Первозданный титан', 'rarity': 'golden', 'price': 4000000, 'wmin': 100, 'wmax': 590, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 220, 'loc': 0, 'name': 'Владыка океана', 'rarity': 'golden', 'price': 5000000, 'wmin': 105, 'wmax': 620, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}]
UPGRADE_FISH += [{'id': 221, 'loc': 0, 'name': 'Небесный кит', 'rarity': 'golden', 'price': 7000000, 'wmin': 120, 'wmax': 700, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 222, 'loc': 0, 'name': 'Радужный марлин', 'rarity': 'golden', 'price': 10000000, 'wmin': 132, 'wmax': 755, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 223, 'loc': 0, 'name': 'Хрустальный левиафан', 'rarity': 'golden', 'price': 14000000, 'wmin': 144, 'wmax': 810, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 224, 'loc': 0, 'name': 'Властитель глубины', 'rarity': 'golden', 'price': 20000000, 'wmin': 156, 'wmax': 865, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 225, 'loc': 0, 'name': 'Буревой дракон', 'rarity': 'golden', 'price': 28000000, 'wmin': 168, 'wmax': 920, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 226, 'loc': 0, 'name': 'Золотая бездна', 'rarity': 'golden', 'price': 40000000, 'wmin': 180, 'wmax': 975, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 227, 'loc': 0, 'name': 'Астральный осётр', 'rarity': 'golden', 'price': 55000000, 'wmin': 192, 'wmax': 1030, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 228, 'loc': 0, 'name': 'Титан приливов', 'rarity': 'golden', 'price': 75000000, 'wmin': 204, 'wmax': 1085, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 229, 'loc': 0, 'name': 'Повелитель штормов', 'rarity': 'golden', 'price': 100000000, 'wmin': 216, 'wmax': 1140, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 230, 'loc': 0, 'name': 'Призрачный император', 'rarity': 'golden', 'price': 130000000, 'wmin': 228, 'wmax': 1195, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 231, 'loc': 0, 'name': 'Хранитель миров', 'rarity': 'golden', 'price': 170000000, 'wmin': 240, 'wmax': 1250, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 232, 'loc': 0, 'name': 'Звёздный дракон', 'rarity': 'golden', 'price': 220000000, 'wmin': 252, 'wmax': 1305, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 233, 'loc': 0, 'name': 'Вечный левиафан', 'rarity': 'golden', 'price': 280000000, 'wmin': 264, 'wmax': 1360, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 234, 'loc': 0, 'name': 'Король океанов', 'rarity': 'golden', 'price': 350000000, 'wmin': 276, 'wmax': 1415, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 235, 'loc': 0, 'name': 'Галактический кит', 'rarity': 'golden', 'price': 430000000, 'wmin': 288, 'wmax': 1470, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 236, 'loc': 0, 'name': 'Первозданный скат', 'rarity': 'golden', 'price': 520000000, 'wmin': 300, 'wmax': 1525, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 237, 'loc': 0, 'name': 'Дракон бесконечности', 'rarity': 'golden', 'price': 630000000, 'wmin': 312, 'wmax': 1580, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 238, 'loc': 0, 'name': 'Владыка космоса', 'rarity': 'golden', 'price': 750000000, 'wmin': 324, 'wmax': 1635, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 239, 'loc': 0, 'name': 'Сердце океана', 'rarity': 'golden', 'price': 880000000, 'wmin': 336, 'wmax': 1690, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}, {'id': 240, 'loc': 0, 'name': 'Рыба вселенной', 'rarity': 'golden', 'price': 1000000000, 'wmin': 348, 'wmax': 1745, 'difficulty': 20, 'emoji': '🐟', 'upgrade_only': True}]
FISH.extend(UPGRADE_FISH)
FISH.extend([{'id': 241, 'loc': 1, 'name': 'Кумжа', 'rarity': 'uncommon', 'price': 220, 'wmin': 0.2, 'wmax': 3.0, 'difficulty': 3, 'emoji': '🐟'}, {'id': 242, 'loc': 1, 'name': 'Хариус', 'rarity': 'rare', 'price': 500, 'wmin': 0.5, 'wmax': 5.4, 'difficulty': 4, 'emoji': '🐟'}, {'id': 243, 'loc': 1, 'name': 'Налим речной', 'rarity': 'rare', 'price': 450, 'wmin': 0.8, 'wmax': 7.8, 'difficulty': 5, 'emoji': '🐟'}, {'id': 244, 'loc': 1, 'name': 'Бычок-подкаменщик', 'rarity': 'uncommon', 'price': 100, 'wmin': 1.1, 'wmax': 10.2, 'difficulty': 6, 'emoji': '🐟'}, {'id': 245, 'loc': 1, 'name': 'Окунь речной', 'rarity': 'rare', 'price': 260, 'wmin': 1.4, 'wmax': 12.6, 'difficulty': 7, 'emoji': '🐟'}, {'id': 246, 'loc': 1, 'name': 'Судак', 'rarity': 'super_rare', 'price': 550, 'wmin': 1.7, 'wmax': 15.0, 'difficulty': 8, 'emoji': '🐟'}, {'id': 247, 'loc': 1, 'name': 'Линь', 'rarity': 'uncommon', 'price': 390, 'wmin': 2.0, 'wmax': 17.4, 'difficulty': 9, 'emoji': '🐟'}, {'id': 248, 'loc': 1, 'name': 'Усач речной', 'rarity': 'rare', 'price': 320, 'wmin': 2.3, 'wmax': 19.8, 'difficulty': 10, 'emoji': '🐟'}, {'id': 249, 'loc': 1, 'name': 'Щука речная', 'rarity': 'super_rare', 'price': 600, 'wmin': 2.6, 'wmax': 22.2, 'difficulty': 11, 'emoji': '🐟'}, {'id': 250, 'loc': 1, 'name': 'Сом европейский', 'rarity': 'epic', 'price': 1000, 'wmin': 2.9, 'wmax': 24.6, 'difficulty': 12, 'emoji': '🐟'}, {'id': 251, 'loc': 2, 'name': 'Атлантическая треска', 'rarity': 'uncommon', 'price': 1500, 'wmin': 0.2, 'wmax': 3.0, 'difficulty': 3, 'emoji': '🐟'}, {'id': 252, 'loc': 2, 'name': 'Атлантический палтус', 'rarity': 'rare', 'price': 3200, 'wmin': 0.5, 'wmax': 5.4, 'difficulty': 4, 'emoji': '🐟'}, {'id': 253, 'loc': 2, 'name': 'Скумбрия атлантическая', 'rarity': 'rare', 'price': 1200, 'wmin': 0.8, 'wmax': 7.8, 'difficulty': 5, 'emoji': '🐟'}, {'id': 254, 'loc': 2, 'name': 'Европейский сибас', 'rarity': 'uncommon', 'price': 2400, 'wmin': 1.1, 'wmax': 10.2, 'difficulty': 6, 'emoji': '🐟'}, {'id': 255, 'loc': 2, 'name': 'Морская камбала', 'rarity': 'rare', 'price': 1800, 'wmin': 1.4, 'wmax': 12.6, 'difficulty': 7, 'emoji': '🐟'}, {'id': 256, 'loc': 2, 'name': 'Полосатая барабуля', 'rarity': 'super_rare', 'price': 1600, 'wmin': 1.7, 'wmax': 15.0, 'difficulty': 8, 'emoji': '🐟'}, {'id': 257, 'loc': 2, 'name': 'Дорада', 'rarity': 'uncommon', 'price': 2100, 'wmin': 2.0, 'wmax': 17.4, 'difficulty': 9, 'emoji': '🐟'}, {'id': 258, 'loc': 2, 'name': 'Атлантическая сельдь', 'rarity': 'rare', 'price': 750, 'wmin': 2.3, 'wmax': 19.8, 'difficulty': 10, 'emoji': '🐟'}, {'id': 259, 'loc': 2, 'name': 'Морской язык', 'rarity': 'super_rare', 'price': 2700, 'wmin': 2.6, 'wmax': 22.2, 'difficulty': 11, 'emoji': '🐟'}, {'id': 260, 'loc': 2, 'name': 'Европейский поллак', 'rarity': 'epic', 'price': 2600, 'wmin': 2.9, 'wmax': 24.6, 'difficulty': 12, 'emoji': '🐟'}, {'id': 261, 'loc': 3, 'name': 'Желтопёрый тунец', 'rarity': 'uncommon', 'price': 10000, 'wmin': 0.2, 'wmax': 3.0, 'difficulty': 3, 'emoji': '🐟'}, {'id': 262, 'loc': 3, 'name': 'Махи-махи', 'rarity': 'rare', 'price': 13000, 'wmin': 0.5, 'wmax': 5.4, 'difficulty': 4, 'emoji': '🐟'}, {'id': 263, 'loc': 3, 'name': 'Океанская луна-рыба', 'rarity': 'rare', 'price': 18500, 'wmin': 0.8, 'wmax': 7.8, 'difficulty': 5, 'emoji': '🐟'}, {'id': 264, 'loc': 3, 'name': 'Рыба-меч океанская', 'rarity': 'uncommon', 'price': 23000, 'wmin': 1.1, 'wmax': 10.2, 'difficulty': 6, 'emoji': '🐟'}, {'id': 265, 'loc': 3, 'name': 'Полосатый тунец', 'rarity': 'rare', 'price': 9500, 'wmin': 1.4, 'wmax': 12.6, 'difficulty': 7, 'emoji': '🐟'}, {'id': 266, 'loc': 3, 'name': 'Голубой марлин', 'rarity': 'super_rare', 'price': 26000, 'wmin': 1.7, 'wmax': 15.0, 'difficulty': 8, 'emoji': '🐟'}, {'id': 267, 'loc': 3, 'name': 'Большой амберджек', 'rarity': 'uncommon', 'price': 14500, 'wmin': 2.0, 'wmax': 17.4, 'difficulty': 9, 'emoji': '🐟'}, {'id': 268, 'loc': 3, 'name': 'Красный луциан', 'rarity': 'rare', 'price': 11500, 'wmin': 2.3, 'wmax': 19.8, 'difficulty': 10, 'emoji': '🐟'}, {'id': 269, 'loc': 3, 'name': 'Гигантский каранкс', 'rarity': 'super_rare', 'price': 17000, 'wmin': 2.6, 'wmax': 22.2, 'difficulty': 11, 'emoji': '🐟'}, {'id': 270, 'loc': 3, 'name': 'Гигантский групер', 'rarity': 'epic', 'price': 24000, 'wmin': 2.9, 'wmax': 24.6, 'difficulty': 12, 'emoji': '🐟'}])
FISH_BY_ID = {f["id"]: f for f in FISH}
FISH_BY_LOC = {1: [], 2: [], 3: []}
for f in FISH:
    if not f.get("upgrade_only"):
        FISH_BY_LOC[f["loc"]].append(f)

# Шансы рыбы по локациям (вес редкости)
FISH_CHANCES = {
    1: {"common": 57.0, "uncommon": 28.0, "rare": 9.5, "super_rare": 3.2, "epic": 1.4, "legendary": 0.55, "mythical": 0.2, "golden": 0.05},
    2: {"common": 45.0, "uncommon": 27.5, "rare": 15.0, "super_rare": 6.8, "epic": 3.0, "legendary": 1.3, "mythical": 0.4, "golden": 0.1},
    3: {"common": 33.0, "uncommon": 26.0, "rare": 20.5, "super_rare": 11.0, "epic": 5.5, "legendary": 2.2, "mythical": 0.7, "golden": 0.15},
}

# Апгрейд: коэффициент -> шанс победы
# Апгрейдер: x2/x3 — безопасные (EV ≥ 1), с x5 начинается риск, но EV всё ещё > 1.
# Сектор x25 хоть и редкий, в среднем даёт больше, чем стоит рыба.
UPGRADE = {
    2:  {"chance": 0.4088, "label": "x2"},   # EV 0.818
    3:  {"chance": 0.2987, "label": "x3"},   # EV 0.896
    5:  {"chance": 0.1943, "label": "x5"},   # EV 0.972
    10: {"chance": 0.0713, "label": "x10"},  # EV 0.713
    25: {"chance": 0.0212, "label": "x25"},  # EV 0.530
    100:{"chance": 0.0057, "label": "x100"}, # джекпот, EV 0.570
}

START_BALANCE = 1000
SELL_COMMISSION = 0.20  # -20%


# ============================================================
#  ДОПОЛНИТЕЛЬНЫЕ МЕХАНИКИ (v1.2)
# ============================================================

# ---------- Время по Москве: миграция видов ----------
# Слоты суток. rare_mult — множитель к шансу редких, price_mult — к цене улова.
MSK_SLOTS = [
    {"id": "night", "from": 2, "to": 3, "name": "Глухая ночь",
     "desc": "Час самых редких и дорогих видов", "price_mult": 1.18,
     "shift": {"rare": 2.5, "super_rare": 2.0, "epic": 1.5, "legendary": 0.6,
               "mythical": 0.3, "golden": 0.08}},
    {"id": "dawn", "from": 3, "to": 9, "name": "Рассвет",
     "desc": "Кормовая миграция: стабильный клёв", "price_mult": 1.05,
     "shift": {"rare": 1.0, "super_rare": 0.8, "epic": 0.5}},
    {"id": "day", "from": 9, "to": 17, "name": "День",
     "desc": "Обычная рыбалка, много мелочи", "price_mult": 1.0,
     "shift": {}},
    {"id": "evening", "from": 17, "to": 22, "name": "Вечерний жор",
     "desc": "Активный клёв, чаще крупная рыба", "price_mult": 1.08,
     "shift": {"rare": 1.5, "super_rare": 1.2, "epic": 0.9}},
    {"id": "night2", "from": 22, "to": 2, "name": "Ночь",
     "desc": "Хищники охотятся у поверхности", "price_mult": 1.12,
     "shift": {"rare": 2.0, "super_rare": 1.6, "epic": 1.2, "legendary": 0.4,
               "mythical": 0.18, "golden": 0.05}},
]

# миграция: в эти часы шанс выпадения конкретной редкости дополнительно растёт
MIGRATION = {}   # устарело: миграция теперь в MSK_SLOTS[].shift

# ---------- Погода ----------
WEATHERS = [
    {"id": "clear", "name": "Ясно", "icon": "sun",
     "desc": "Спокойная вода. Всё как обычно",
     "bite_mult": 1.0, "rare_mult": 1.0, "price_mult": 1.0, "loss_chance": 0.0},
    {"id": "cloud", "name": "Облачно", "icon": "cloud",
     "desc": "Рыба менее пуглива",
     "bite_mult": 1.15, "rare_mult": 1.1, "price_mult": 1.05, "loss_chance": 0.0},
    {"id": "rain", "name": "Дождь", "icon": "rain",
     "desc": "Дождь: клюёт чаще и попадается реже",
     "bite_mult": 1.55, "rare_mult": 1.45, "price_mult": 1.12, "loss_chance": 0.0},
    {"id": "storm", "name": "Шторм", "icon": "storm",
     "desc": "Шторм: рыба бережёт силы — клюёт реже, но крупнее. Сачок может унести рыбу",
     "bite_mult": 0.62, "rare_mult": 1.25, "price_mult": 1.5, "loss_chance": 0.28},
    {"id": "fog", "name": "Туман", "icon": "fog",
     "desc": "Туман: рыба подходит к берегу",
     "bite_mult": 1.25, "rare_mult": 1.2, "price_mult": 1.0, "loss_chance": 0.0},
    {"id": "wind", "name": "Ветер", "icon": "wind",
     "desc": "Волна мешает, но хищник активен",
     "bite_mult": 0.9, "rare_mult": 1.3, "price_mult": 1.15, "loss_chance": 0.0},
]
WEATHER_CHANCES = {"clear": 30, "cloud": 22, "rain": 18, "storm": 12, "fog": 10, "wind": 8}

# ---------- Поклёвка ----------
BITE_MIN_SEC = 1.0        # ждать от 1 до 7 секунд
BITE_MAX_SEC = 7.0
HOOK_WINDOW_SEC = 4.0     # на подсечку 4 секунды

# ---------- Снятие чар ----------
# цена = максимум по редкости среди снятых; снимаются ВСЕ чары с удочки
CHARM_REMOVE_COST = {
    "common": 100, "uncommon": 200, "rare": 400, "super_rare": 800,
    "epic": 1200, "legendary": 2000, "mythical": 3500, "golden": 5000,
}

# ---------- Крафт: материалы ----------
MATERIALS = {
    "wood":      {"name": "Древесина",     "price": 80},
    "scale":     {"name": "Чешуя",         "price": 120},
    "scrap":     {"name": "Старый металлолом", "price": 500, "buy": 500, "sell": 200},
    "metal":     {"name": "Чистый металлолом", "price": 2000, "buy": 2000, "sell": 800},
    "plastic":   {"name": "Пластик",       "price": 160},
    "rubber":    {"name": "Резина",        "price": 220},
    "shell":     {"name": "Ракушка", "price": 100},
    "fiber":     {"name": "Волокно", "price": 100},
    "pearl":     {"name": "Жемчужина", "price": 800},
    "hook":      {"name": "Крючок", "price": 250},
    "crystal":   {"name": "Кристалл", "price": 1200},
}

# рецепты: что + сколько -> что + сколько, время в секундах
CRAFT_RECIPES = {
    "metal": {"in":{"scrap":2},"out":{"metal":1},"sec":10,"name":"Чистый металл"},
    "bait_1": {"in":{"wood":1,"fiber":1},"bait":1,"sec":10,"name":"Наживка 1"},
    "bait_2": {"in":{"scale":1,"hook":1},"bait":2,"sec":10,"name":"Наживка 2"},
    "bait_3": {"in":{"shell":1,"fiber":1},"bait":3,"sec":10,"name":"Наживка 3"},
    "bait_4": {"in":{"plastic":1,"hook":1,"wood":1},"bait":4,"sec":10,"name":"Наживка 4"},
    "bait_5": {"in":{"metal":1,"rubber":1,"pearl":1},"bait":5,"sec":10,"name":"Наживка 5"},
    "bait_6": {"in":{"crystal":1,"scale":2,"hook":1},"bait":6,"sec":10,"name":"Наживка 6"},
}

# где падают материалы (шанс за поимку)
MATERIAL_DROPS = {
    1: {"wood": 22, "scale": 16, "plastic": 10, "rubber": 6, "scrap": 4,"shell":12,"fiber":18,"pearl":3,"hook":10,"crystal":2},
    2: {"wood": 14, "scale": 20, "plastic": 14, "rubber": 12, "scrap": 8,"shell":20,"fiber":12,"pearl":7,"hook":12,"crystal":4},
    3: {"wood": 10, "scale": 22, "plastic": 16, "rubber": 16, "scrap": 12,"shell":20,"fiber":12,"pearl":12,"hook":15,"crystal":8},
}

# ---------- Аквариум ----------
AQUARIUM_LEVELS = [
    {"cap": 3,  "cost": 0},        {"cap": 5,  "cost": 5000},
    {"cap": 8,  "cost": 20000},    {"cap": 12, "cost": 60000},
    {"cap": 18, "cost": 150000},   {"cap": 25, "cost": 400000},
    {"cap": 35, "cost": 900000},   {"cap": 50, "cost": 2000000},
]
AQUARIUM_RATE = 0.020   # % от цены рыбы в минуту (база)

# ---------- Сачок ----------
NET_CAPACITY = 8        # сколько рыб держит сачок

# ---------- Трейды ----------
TRADE_EXPIRE_HOURS = 48
