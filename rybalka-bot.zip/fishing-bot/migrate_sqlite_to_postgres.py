#!/usr/bin/env python3
"""One-off migration into an EMPTY Postgres database; never clears existing data.
Usage: DATABASE_URL=... python migrate_sqlite_to_postgres.py /path/to/backup.db
Do not publish the database URL or the SQLite backup.
"""
import os, sys, sqlite3
import psycopg
from psycopg import sql
import database

TABLES=['users','rods','fish_inventory','baits','promo_codes','stats','rebirth','achievements','daily','promo_redemptions','materials','crafts','net_fish','aquarium','aquarium_state','trades','admin_settings','upgrade_bonus','charm_choices','admin_grants','promo_attempts','boat_upgrades','fish_records','fishing_encounters','fishing_events','fishing_contracts','workshop_state','tackle_inventory','tackle_equipped','rod_condition']
SEQUENCES=['rods','fish_inventory','crafts','net_fish','aquarium','trades']

def migrate(path):
    if not os.environ.get('DATABASE_URL'): raise SystemExit('DATABASE_URL is required.')
    if not os.path.isfile(path): raise SystemExit('SQLite backup file was not found.')
    source=sqlite3.connect('file:'+os.path.abspath(path)+'?mode=ro',uri=True)
    source.execute('PRAGMA query_only=ON')
    # Set up schema first. This does not remove existing data.
    database.init_db()
    with psycopg.connect(os.environ['DATABASE_URL']) as dest:
        with dest.cursor() as cur:
            cur.execute('SELECT pg_advisory_xact_lock(734982713)')
            for t in TABLES:
                cur.execute(sql.SQL('SELECT 1 FROM {} LIMIT 1').format(sql.Identifier(t)))
                if cur.fetchone(): raise RuntimeError('Destination is not empty; migration aborted: '+t)
            existing={r[0] for r in source.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            for table in TABLES:
                if table not in existing: continue
                source_cols=[r[1] for r in source.execute('PRAGMA table_info("'+table+'")')]
                cur.execute('SELECT column_name FROM information_schema.columns WHERE table_schema=current_schema() AND table_name=%s',(table,))
                target_cols={r[0] for r in cur.fetchall()}; cols=[c for c in source_cols if c in target_cols]
                if not cols: continue
                query='SELECT '+','.join('"'+c+'"' for c in cols)+' FROM "'+table+'"'
                insert=sql.SQL('INSERT INTO {} ({}) VALUES ({})').format(sql.Identifier(table),sql.SQL(',').join(map(sql.Identifier,cols)),sql.SQL(',').join(sql.Placeholder() for _ in cols))
                read=source.execute(query)
                while True:
                    rows=read.fetchmany(500)
                    if not rows: break
                    cur.executemany(insert,rows)
            for table in SEQUENCES:
                cur.execute(sql.SQL("SELECT setval(pg_get_serial_sequence(%s, 'id'), COALESCE(MAX(id), 1), MAX(id) IS NOT NULL) FROM {}").format(sql.Identifier(table)),(table,))
    source.close()
    print('Migration committed successfully. Keep your SQLite backup.')

if __name__=='__main__':
    if len(sys.argv)!=2: raise SystemExit('Provide the SQLite backup path.')
    migrate(sys.argv[1])
