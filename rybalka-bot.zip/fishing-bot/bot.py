# -*- coding: utf-8 -*-
"""
Бот «Рыбалка» Автор: @pspwlk Версия 1.2
Telegram Bot + Mini App (WebApp) на aiogram 3 + aiohttp
"""
import os
from contextlib import closing
import json
import time
import random
import math
import secrets
import hashlib
import hmac
from urllib.parse import parse_qsl


def _load_env():
    """Подхватываем .env рядом с bot.py, чтобы не зависеть от способа запуска.
    ВАЖНО: вызывается до импорта database — иначе DB_PATH из .env не применится."""
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    if not os.path.exists(path):
        return
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip())


_load_env()

ADMIN_PROMO_HASHES = ('6112be3efd06cb82c38ec8f6920a47565dcb0eade197023eb4eeb9859da6cec1', '6e15e63c7fd562d6c957c8f95c25620727d568cafee684349439522aefa93722', 'bf168f303c35cdc3c3bd47a62da1bad735b557c02ce36b965fc74464db1aa3d8', 'c77f64cf431190eedfb6657272f29b0cf930b1837228b0910e690ef9a5bdb3a6')  # SHA-256; code itself is not sent to the client

def is_admin_code(value):
    digest=hashlib.sha256(value.encode("utf-8")).hexdigest()
    return any(hmac.compare_digest(digest,expected) for expected in ADMIN_PROMO_HASHES)

from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from aiogram.types import (
    Message, InlineKeyboardMarkup, InlineKeyboardButton,
    WebAppInfo, CallbackQuery
)
from aiohttp import web

from config import (START_BALANCE,
    RODS, RODS_BY_ID, CHARMS, CHARMS_BY_ID, CHARMS_BY_RARITY,
    FISH, FISH_BY_ID, FISH_BY_LOC, FISH_CHANCES, CHARM_CHANCES, CHARM_SPIN_COST,
    BAITS, BAITS_BY_ID, LOCATIONS, RARITIES, UPGRADE, SELL_COMMISSION,
    MSK_SLOTS, MIGRATION, WEATHERS, WEATHER_CHANCES, BITE_MIN_SEC, BITE_MAX_SEC,
    HOOK_WINDOW_SEC, CHARM_REMOVE_COST, MATERIALS, CRAFT_RECIPES, MATERIAL_DROPS,
    AQUARIUM_LEVELS, AQUARIUM_RATE, NET_CAPACITY, TRADE_EXPIRE_HOURS
)
import database as db

BOT_TOKEN = os.getenv("BOT_TOKEN", "ВСТАВЬ_ТОКЕН_СЮДА")
WEBAPP_URL = os.getenv("WEBAPP_URL", "https://твой-домен/webapp/")  # для кнопки Mini App
PORT = int(os.getenv("PORT", "8080"))
# DEV_MODE=1 — локальная игра без Telegram: пускает по X-User-Id / ?user_id=
# На проде НЕ включать: любой сможет зайти чужим ID
DEV_MODE = os.getenv("DEV_MODE", "0") == "1"
# Если фронт лежит отдельно от бота (GitHub Pages и т.п.), укажи его origin:
# CORS_ORIGIN=https://твой-логин.github.io
CORS_ORIGIN = os.getenv("CORS_ORIGIN", "").strip()

if BOT_TOKEN == "ВСТАВЬ_ТОКЕН_СЮДА":
    raise SystemExit(
        "\n❌ Не найден BOT_TOKEN.\n"
        "   1) создай .env рядом с bot.py:  cp .env.example .env\n"
        "   2) впиши туда токен от @BotFather\n"
        "   3) перезапусти бота\n"
        "   Для игры без Telegram используй DEV_MODE=1\n"
    )

bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher()

# ---------- Утилиты ----------
def fmt(n):
    return f"{n:,}".replace(",", " ")

def weighted_choice(chances: dict):
    r = random.uniform(0, 100)
    acc = 0
    for k, v in chances.items():
        acc += v
        if r <= acc:
            return k
    return list(chances.keys())[-1]

def roll_charm(loc: int):
    rarity = weighted_choice(CHARM_CHANCES[loc])
    charm = random.choice(CHARMS_BY_RARITY[rarity])
    return charm

def roll_fish(loc: int, rarity_bonus: int = 0, far: float = 0.0):
    """Редкость растёт от бонуса снасти и дальности заброса (far 0..1).
    Бонус мягкий: редкие рыбы остаются редкими."""
    chances = dict(FISH_CHANCES[loc])
    shift = min(rarity_bonus * 0.12 + far * 6.0, 8.0)
    if shift > 0:
        chances["common"] = max(1.0, chances["common"] - shift)
        chances["uncommon"] = max(1.0, chances["uncommon"] - shift * 0.6)
        chances["rare"] += shift * 0.5
        chances["super_rare"] += shift * 0.3
        chances["epic"] += shift * 0.14
        chances["legendary"] += shift * 0.05
        chances["mythical"] += shift * 0.012
        chances["golden"] += shift * 0.004
    rarity = weighted_choice(chances)
    candidates = [f for f in FISH_BY_LOC[loc] if f["rarity"] == rarity]
    if not candidates:
        candidates = FISH_BY_LOC[loc]
    return random.choice(candidates)

def rod_bonuses(rod_db_row):
    """Суммарные бонусы удочки с учётом чар"""
    rod = RODS_BY_ID[rod_db_row["rod_id"]]
    luck = rod["luck"]
    price_b = rod["price_bonus"]
    rarity_b = rod["rarity_bonus"]
    for cid in rod_db_row.get("charms", []):
        ch = CHARMS_BY_ID.get(cid)
        if not ch:
            continue
        if ch["effect_type"] == "luck":
            luck += ch["effect_value"]
        elif ch["effect_type"] == "price":
            price_b += ch["effect_value"]
        elif ch["effect_type"] == "rarity":
            rarity_b += ch["effect_value"]
    return luck, price_b, rarity_b

def check_init_data(init_data: str):
    """Проверка подписи Telegram WebApp initData"""
    if not init_data:
        return None
    try:
        data = dict(parse_qsl(init_data, keep_blank_values=True))
        hash_received = data.pop("hash", None)
        if not hash_received:
            return None
        data_check = "\n".join(f"{k}={v}" for k, v in sorted(data.items()))
        secret = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
        calc = hmac.new(secret, data_check.encode(), hashlib.sha256).hexdigest()
        if calc != hash_received:
            return None
        user = json.loads(data.get("user", "{}"))
        return user
    except Exception:
        return None

def get_user_from_request(request):
    init_data = request.headers.get("X-Telegram-Init-Data") or request.query.get("initData", "")
    # В dev-режиме проверку подписи пропускаем — только для локальной отладки
    if DEV_MODE:
        uid = request.query.get("user_id") or request.headers.get("X-User-Id")
        if uid:
            return {"id": int(uid), "username": request.query.get("username", "demo")}
        return None
    user = check_init_data(init_data)
    return user

# ---------- Клавиатуры ----------
def main_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎣 Играть (Mini App)", web_app=WebAppInfo(url=WEBAPP_URL))],
        [InlineKeyboardButton(text="💰 Баланс", callback_data="balance"),
         InlineKeyboardButton(text="🎁 Промокод", callback_data="promo_help")],
        [InlineKeyboardButton(text="❓ Помощь", callback_data="help")],
    ])

# ---------- Хендлеры бота ----------
@dp.message(CommandStart())
async def cmd_start(message: Message):
    user = db.get_or_create_user(message.from_user.id, message.from_user.username)
    text = (
        f"🎣 <b>Рыбалка</b> | Автор: @pspwlk | v1.2\n\n"
        f"Привет, <b>{message.from_user.first_name}</b>!\n"
        f"💰 Твой баланс: <b>{fmt(user['balance'])}₽</b>\n"
        f"📍 Локация: {LOCATIONS[user['location']]['name']}\n\n"
        f"Лови рыбу, покупай удочки, крути чары, открывай локации!\n"
        f"🎯 Цель: пройти игру за 72+ часа — прокачайся до «Бога Морей»!\n\n"
        f"Нажми кнопку ниже, чтобы открыть игру 👇"
    )
    await message.answer(text, reply_markup=main_kb())

@dp.message(Command("balance"))
async def cmd_balance(message: Message):
    user = db.get_or_create_user(message.from_user.id, message.from_user.username)
    await message.answer(f"💰 Баланс: <b>{fmt(user['balance'])}₽</b>")

@dp.message(Command("help"))
async def cmd_help(message: Message):
    await message.answer(
        "❓ <b>Как играть</b>\n\n"
        "1. Открой Mini App и выбери удочку\n"
        "2. Нажми на воду, чтобы закинуть\n"
        "3. Попадай в зелёную зону, пока кружок движется — нужно 1–20 попаданий (зависит от рыбы и удочки)\n"
        "4. Продавай рыбу, покупай новые удочки и наживку\n"
        "5. Крути чары (макс. 3 на удочку), открывай локации, апгрейди рыбу: ставь своих против доро́гой цели\n\n"
        "🎁 Промокоды вводятся в разделе «Коды» в приложении.\n"
        "💡 Удочку можно продать с комиссией -20% (чары сгорят).",
        reply_markup=main_kb()
    )

@dp.callback_query(F.data == "balance")
async def cb_balance(cb: CallbackQuery):
    user = db.get_or_create_user(cb.from_user.id, cb.from_user.username)
    await cb.answer(f"💰 {fmt(user['balance'])}₽", show_alert=True)

@dp.callback_query(F.data == "promo_help")
async def cb_promo(cb: CallbackQuery):
    await cb.answer("Открой Mini App → раздел «Коды» и введи промокод", show_alert=True)

@dp.callback_query(F.data == "help")
async def cb_help(cb: CallbackQuery):
    await cb.message.answer(
        "❓ <b>Как играть</b>\n\n"
        "1. Открой Mini App и выбери удочку\n"
        "2. Нажми на воду, чтобы закинуть\n"
        "3. Попадай в зелёную зону — нужно 1–20 попаданий\n"
        "4. Продавай рыбу, покупай удочки и наживку\n"
        "5. Крути чары (макс. 3), открывай локации, апгрейди рыбу на колесе шансов\n\n"
        "🎁 Промокоды — в разделе «Коды» в приложении.",
        reply_markup=main_kb()
    )

@dp.message(Command("cancel"))
async def cmd_cancel(message: Message, state: FSMContext):
    await state.clear()
    await message.answer("Отменено.", reply_markup=main_kb())

# ---------- API для Mini App ----------
async def api_profile(request):
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    user = db.get_or_create_user(u["id"], u.get("username"))
    rods = db.get_rods(u["id"])
    fish = db.get_fish(u["id"])
    baits = db.get_baits(u["id"])
    return web.json_response({
        "user": user,
        "is_admin": db.is_admin(u["id"]),
        "admin_settings": db.get_admin_settings(u["id"]),
        "workshop": db.get_workshop(u["id"]),
        "contract": db.get_contract(u["id"]),
        "boat_level": db.get_boat(u["id"]),
        "fish_records": db.get_fish_records(u["id"]),
        "pending_charm": db.get_pending_charm(u["id"]),
        "rods": rods,
        "fish": fish,
        "baits": baits,
        "rods_data": RODS,
        "fish_data": FISH,
        "charms_data": CHARMS,
        "baits_data": BAITS,
        "locations": LOCATIONS,
        "rarities": RARITIES,
        "charm_costs": CHARM_SPIN_COST,
        "upgrade": UPGRADE,
        "stats": db.get_stats(u["id"]),
        "achievements": db.get_achievements(u["id"]),
        "daily": db.get_daily(u["id"]),
        "rebirth": db.get_rebirth(u["id"])["level"],   # фронт ждёт число, множитель = level+1
        "time": int(time.time()),
    })

async def api_buy_rod(request):
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    data = await request.json()
    rod_id = int(data.get("rod_id", 0))
    rod = RODS_BY_ID.get(rod_id)
    if not rod:
        return web.json_response({"error": "rod not found"}, status=400)
    user = db.get_or_create_user(u["id"], u.get("username"))
    unlocked = json.loads(user["unlocked_locations"] or "[1]")
    if rod["loc"] not in unlocked:
        return web.json_response({"error": "location locked"}, status=400)
    if user["balance"] < rod["price"]:
        return web.json_response({"error": "not enough balance"}, status=400)
    db.update_balance(u["id"], -rod["price"])
    db.add_rod(u["id"], rod_id)
    return web.json_response({"ok": True, "balance": db.get_user(u["id"])["balance"]})

async def api_sell_rod(request):
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    data = await request.json()
    rod_db_id = int(data.get("rod_db_id", 0))
    rods = db.get_rods(u["id"])
    target = next((r for r in rods if r["id"] == rod_db_id), None)
    if not target:
        return web.json_response({"error": "rod not found"}, status=404)
    pending=db.get_pending_charm(u["id"])
    if pending and pending["rod_id"]==rod_db_id: return web.json_response({"error":"Сначала выберите открытую чару"},status=400)
    rod = RODS_BY_ID[target["rod_id"]]
    refund = int(rod["price"] * (1 - SELL_COMMISSION))
    db.remove_rod(u["id"], rod_db_id)
    bal = db.update_balance(u["id"], refund)
    return web.json_response({"ok": True, "refund": refund, "balance": bal})

CHARM_PICK_COST={"common":200,"uncommon":500,"rare":1500,"super_rare":4000,"epic":10000,"legendary":25000,"mythical":60000,"golden":150000}

async def api_spin_charm(request):
    u=get_user_from_request(request)
    if not u:return web.json_response({"error":"unauthorized"},status=401)
    data=await request.json()
    try:rod_id=int(data.get("rod_db_id",0))
    except (ValueError,TypeError):return web.json_response({"error":"Неверная удочка"},status=400)
    with closing(db.get_conn()) as c,c:
        c.execute("BEGIN IMMEDIATE")
        if c.execute("SELECT 1 FROM charm_choices WHERE user_id=?",(u["id"],)).fetchone():return web.json_response({"error":"Сначала выберите чару или перетасуйте"},status=400)
        rod=c.execute("SELECT * FROM rods WHERE id=? AND user_id=?",(rod_id,u["id"])).fetchone()
        if not rod:return web.json_response({"error":"Удочка не найдена"},status=404)
        if len(json.loads(rod["charms"] or "[]"))>=3:return web.json_response({"error":"Все слоты заняты"},status=400)
        options=[roll_charm(RODS_BY_ID[rod["rod_id"]]["loc"])["id"] for _ in range(3)]
        c.execute("INSERT INTO charm_choices(user_id,rod_id,options,prepaid) VALUES (?,?,?,0)",(u["id"],rod_id,json.dumps(options)))
        return web.json_response({"ok":True,"rod_id":rod_id,"options":options,"prepaid":False})

async def api_reshuffle_charm(request):
    u=get_user_from_request(request)
    if not u:return web.json_response({"error":"unauthorized"},status=401)
    data=await request.json()
    with closing(db.get_conn()) as c,c:
        c.execute("BEGIN IMMEDIATE")
        pending=c.execute("SELECT * FROM charm_choices WHERE user_id=?",(u["id"],)).fetchone()
        if not pending:return web.json_response({"error":"Сначала откройте карточки"},status=400)
        if data.get("options")!=json.loads(pending["options"]):return web.json_response({"error":"Карточки изменились, обновите экран"},status=409)
        rod=c.execute("SELECT * FROM rods WHERE id=? AND user_id=?",(pending["rod_id"],u["id"])).fetchone()
        if not rod or len(json.loads(rod["charms"] or "[]"))>=3:return web.json_response({"error":"Удочка недоступна"},status=400)
        options=[roll_charm(RODS_BY_ID[rod["rod_id"]]["loc"])["id"] for _ in range(3)]
        c.execute("UPDATE charm_choices SET options=? WHERE user_id=?",(json.dumps(options),u["id"]))
        return web.json_response({"ok":True,"rod_id":rod["id"],"options":options,"prepaid":bool(pending["prepaid"])})

async def api_choose_charm(request):
    u=get_user_from_request(request)
    if not u:return web.json_response({"error":"unauthorized"},status=401)
    data=await request.json()
    try:index=int(data.get("index",-1))
    except (ValueError,TypeError):return web.json_response({"error":"Неверный выбор"},status=400)
    with closing(db.get_conn()) as c,c:
        c.execute("BEGIN IMMEDIATE")
        pending=c.execute("SELECT * FROM charm_choices WHERE user_id=?",(u["id"],)).fetchone()
        if not pending or index not in range(3):return web.json_response({"error":"Нет такого выбора"},status=400)
        opts=json.loads(pending["options"])
        if data.get("options")!=opts:return web.json_response({"error":"Карточки изменились, обновите экран"},status=409)
        rod=c.execute("SELECT * FROM rods WHERE id=? AND user_id=?",(pending["rod_id"],u["id"])).fetchone()
        if not rod:return web.json_response({"error":"Удочка не найдена"},status=404)
        charms=json.loads(rod["charms"] or "[]")
        if len(charms)>=3:return web.json_response({"error":"Все слоты заняты"},status=400)
        cid=opts[index];price=0 if pending["prepaid"] else CHARM_PICK_COST[CHARMS_BY_ID[cid]["rarity"]]
        bal=c.execute("SELECT balance FROM users WHERE user_id=?",(u["id"],)).fetchone()
        if not bal or bal["balance"]<price:return web.json_response({"error":f"Не хватает денег: нужно {price} ₽"},status=400)
        charms.append(cid)
        c.execute("UPDATE users SET balance=balance-? WHERE user_id=?",(price,u["id"]))
        c.execute("UPDATE rods SET charms=? WHERE id=? AND user_id=?",(json.dumps(charms),rod["id"],u["id"]))
        c.execute("DELETE FROM charm_choices WHERE user_id=?",(u["id"],))
        return web.json_response({"ok":True,"charm":CHARMS_BY_ID[cid],"cost":price})

async def api_buy_bait(request):
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    data = await request.json()
    bait_id = int(data.get("bait_id", 0))
    bait = BAITS_BY_ID.get(bait_id)
    if not bait:
        return web.json_response({"error": "bait not found"}, status=400)
    user = db.get_user(u["id"])
    if user["balance"] < bait["price"]:
        return web.json_response({"error": "not enough balance"}, status=400)
    db.update_balance(u["id"], -bait["price"])
    db.add_bait(u["id"], bait_id, 1)
    return web.json_response({"ok": True, "balance": db.get_user(u["id"])["balance"]})

# Виды с хищным образом жизни, определяются по названию в каталоге.
PREDATOR_WORDS=("щук","окун","судак","сом","акул","тунец","марлин","барракуд","мурен","лещад","пира", "форель", "лосос", "скумбри", "кальмар", "осётр", "групер", "каранкс", "рыба-меч", "сибас")
def is_predator(fish):
    return any(word in fish["name"].lower() for word in PREDATOR_WORDS)
def bait_group(bait_id):
    return "predator" if bait_id in (5,6,7,12,13,14,15,16,17,18,19,20) else "peaceful" if bait_id in (1,2,3,4,8,9,10,11) else "neutral"
def fish_strength(fish,weight,rod,boss=False):
    rarities=("common","uncommon","rare","super_rare","epic","legendary","mythical","golden")
    rarity=rarities.index(fish["rarity"]) if fish["rarity"] in rarities else 0
    fraction=max(0,min(1,(weight-fish["wmin"])/max(.01,fish["wmax"]-fish["wmin"])))
    relative=max(0,min(2.5,math.log10(max(1,fish["price"])/max(100,rod["price"])+1)))
    value=max(0,math.log10(max(1,fish["price"])/25))
    rating=max(0,min(2.8,rarity*.22+relative*.35+value*.18+fraction*.18+min(.3,math.log10(1+weight)*.09)-min(.3,math.log10(1+rod["luck"])*.12)+(0.45 if boss else 0)))
    predator=is_predator(fish) or boss
    drift=min(23,3+rating*8+fraction*3) if predator else 0
    return {"zone":round(max(6,min(34,33-rating*11)),1),"speed":round(max(.55,min(2.8,.62+rating*.74)),3),"hits":max(2,min(16,2+round(rating*4)+(2 if boss else 0))),"drift":round(drift,1),"predator":predator,"boss":boss}


async def api_boat_upgrade(request):
    u=get_user_from_request(request)
    if not u:return web.json_response({"error":"unauthorized"},status=401)
    costs=[5000,20000,75000,250000,750000]
    with closing(db.get_conn()) as c,c:
        c.execute("BEGIN IMMEDIATE")
        row=c.execute("SELECT level FROM boat_upgrades WHERE user_id=?",(u["id"],)).fetchone();level=row["level"] if row else 0
        if level>=len(costs):return web.json_response({"error":"Лодка улучшена до максимума"},status=400)
        bal=c.execute("SELECT balance FROM users WHERE user_id=?",(u["id"],)).fetchone()
        if not bal or bal["balance"]<costs[level]:return web.json_response({"error":"Не хватает денег"},status=400)
        c.execute("UPDATE users SET balance=balance-? WHERE user_id=?",(costs[level],u["id"]))
        c.execute("INSERT INTO boat_upgrades(user_id,level) VALUES (?,1) ON CONFLICT(user_id) DO UPDATE SET level=level+1",(u["id"],))
        return web.json_response({"ok":True,"level":level+1})

async def api_fishing_event(request):
    u=get_user_from_request(request)
    if not u:return web.json_response({"error":"unauthorized"},status=401)
    now=int(time.time());uid=u["id"]
    with closing(db.get_conn()) as c,c:
        c.execute("BEGIN IMMEDIATE")
        row=c.execute("SELECT payload,expires FROM fishing_events WHERE user_id=?",(uid,)).fetchone()
        if row and row["expires"]>now:return web.json_response({"event":json.loads(row["payload"]),"expires":row["expires"]})
        event={"id":secrets.token_hex(8),"kind":random.choices(["shoal","predator","chest"],[5,3,2])[0],"x":round(random.uniform(.54,.88),3),"y":round(random.uniform(.58,.87),3)}
        exp=now+25;c.execute("INSERT OR REPLACE INTO fishing_events(user_id,payload,expires) VALUES (?,?,?)",(uid,json.dumps(event),exp))
        return web.json_response({"event":event,"expires":exp})

async def api_fishing_start(request):
    u=get_user_from_request(request)
    if not u:return web.json_response({"error":"unauthorized"},status=401)
    data=await request.json();uid=u["id"]
    try: rod_id=int(data.get("rod_db_id",0));bait_id=int(data.get("bait_id",0));loc=int(data.get("loc",0));far=max(0,min(1,float(data.get("far",0)))); x=float(data.get("x",0));y=float(data.get("y",0))
    except (TypeError,ValueError):return web.json_response({"error":"Неверный заброс"},status=400)
    user=db.get_user(uid);target=next((r for r in db.get_rods(uid) if r["id"]==rod_id),None)
    if not target or not user or loc!=user["location"] or loc not in FISH_BY_LOC:return web.json_response({"error":"Выберите доступную удочку и локацию"},status=400)
    if bait_id and not any(b["bait_id"]==bait_id and b["count"]>0 for b in db.get_baits(uid)):return web.json_response({"error":"Наживка закончилась"},status=400)
    boat=db.get_boat(uid)
    if len(db.net_list(uid))>=NET_CAPACITY+boat*2:return web.json_response({"error":"Сачок полон — заберите или продайте улов"},status=400)
    now=int(time.time());event=None
    with closing(db.get_conn()) as c,c:
        c.execute("BEGIN IMMEDIATE")
        row=c.execute("SELECT payload,expires FROM fishing_events WHERE user_id=?",(uid,)).fetchone()
        if row and row["expires"]>=now:
            ev=json.loads(row["payload"])
            if data.get("event_id")==ev["id"] and ((x-ev["x"])**2+(y-ev["y"])**2)**.5<.10:event=ev["kind"];c.execute("DELETE FROM fishing_events WHERE user_id=?",(uid,))
    rod=RODS_BY_ID[target["rod_id"]];luck,_,rarity=rod_bonuses(target);settings=db.get_admin_settings(uid);rarity+=settings["luck"]+(12 if data.get("perfect") else 0)
    bait=BAITS_BY_ID.get(bait_id);rarity+=bait["rarity_bonus"] if bait else 0
    w=current_weather();rarity+=(w["rare_mult"]-1)*5+sum(current_slot()["shift"].values())*3.2+(8 if event=="shoal" else 0)
    forced=FISH_BY_ID.get(int(settings["forced_fish"]));fish=forced if forced and not forced.get("upgrade_only") and forced["loc"]==loc else roll_fish(loc,rarity,far)
    boss=(random.random()<(.12 if event=="predator" else .015)) and not forced
    if boss:
        pool=[f for f in FISH_BY_LOC[loc] if is_predator(f)]
        if pool:fish=random.choice(sorted(pool,key=lambda f:f["price"],reverse=True)[:max(1,len(pool)//4)])
    elif not forced:
        group=bait_group(bait_id);want_pred=group=="predator" or (group=="neutral" and w["id"] in ("rain","storm","wind")) or event=="predator"
        bias=.72 if group!="neutral" or event=="predator" else .58 if w["id"] in ("rain","storm","wind") else .5
        if random.random()<bias:
            pool=[f for f in FISH_BY_LOC[loc] if f["rarity"]==fish["rarity"] and is_predator(f)==want_pred]
            if pool:fish=random.choice(pool)
    weight=round(random.uniform(fish["wmin"],fish["wmax"]),2)
    for cid in target["charms"]:
        ch=CHARMS_BY_ID.get(cid)
        if ch and ch["effect_type"]=="weight":weight=round(weight*(1+ch["effect_value"]/100),2)
    strength=fish_strength(fish,weight,rod,boss);payload={"id":secrets.token_hex(16),"rod":rod_id,"bait":bait_id,"loc":loc,"far":far,"perfect":bool(data.get("perfect")),"fish_id":fish["id"],"weight":weight,"event":event,"boss":boss,"difficulty":strength}
    with closing(db.get_conn()) as c,c:c.execute("INSERT OR REPLACE INTO fishing_encounters(user_id,payload,expires) VALUES (?,?,?)",(uid,json.dumps(payload),now+300))
    return web.json_response({"ok":True,"encounter":payload})

async def api_catch(request):
    """Вызывается после успешной мини-игры. Сервер определяет рыбу."""
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    db.get_workshop(u["id"])
    data = await request.json()
    rod_db_id = int(data.get("rod_db_id", 0))
    bait_id = int(data.get("bait_id", 0) or 0)
    loc = int(data.get("loc", 1))
    # Каждая поклёвка выбирается до мини-игры и используется ровно один раз.
    with closing(db.get_conn()) as c,c:
        c.execute("BEGIN IMMEDIATE")
        row=c.execute("SELECT payload,expires FROM fishing_encounters WHERE user_id=?",(u["id"],)).fetchone()
        pending=json.loads(row["payload"]) if row else None
        if not pending or row["expires"]<int(time.time()) or pending["id"]!=data.get("encounter_id"):
            return web.json_response({"error":"Поклёвка закончилась. Забросьте снова"},status=400)
        c.execute("DELETE FROM fishing_encounters WHERE user_id=?",(u["id"],))
    rod_db_id=pending["rod"];bait_id=pending["bait"];loc=pending["loc"]
    rods = db.get_rods(u["id"])
    target = next((r for r in rods if r["id"] == rod_db_id), None)
    if not target:
        return web.json_response({"error": "rod not found"}, status=404)
    settings = db.get_admin_settings(u["id"])
    luck, price_b, rarity_b = rod_bonuses(target)
    luck += settings["luck"]
    rarity_b += settings["luck"]
    price_b += settings["price_bonus"]
    if bait_id:
        bait = BAITS_BY_ID.get(bait_id)
        if bait:
            luck += bait["luck_bonus"]
            price_b += bait["price_bonus"]
            rarity_b += bait["rarity_bonus"]
            if bait["uses"] > 0:
                db.use_bait(u["id"], bait_id)
    try:
        far = max(0.0, min(1.0, float(data.get("far", 0) or 0)))
    except (TypeError, ValueError):
        far = 0.0
    perfect = pending["perfect"]
    if perfect:
        rarity_b += 12
    # ---- время по МСК и погода ----
    slot = current_slot()
    wtr = current_weather()
    rarity_b += sum(slot["shift"].values()) * 3.2     # проценты -> условный бонус редкости
    rarity_b += (wtr["rare_mult"] - 1) * 5.0
    fish=FISH_BY_ID[pending["fish_id"]]
    weight=pending["weight"]
    # бонус серии: +3% за каждую предыдущую поимку подряд (макс +30%)
    st_prev = db.get_stats(u["id"])
    prev_streak = st_prev["streak"] or 0
    if st_prev["last_catch_at"] and int(time.time()) - st_prev["last_catch_at"] > 900:
        prev_streak = 0
    streak_bonus = min(30, prev_streak * 3)
    perfect_bonus = 18 if perfect else 0
    rb_level = db.get_rebirth(u["id"])["level"]
    rebirth_mult = rb_level + 1          # x1 в первом прохождении, x2 после 1-го rebirth
    env_mult = slot["price_mult"] * wtr["price_mult"]
    price = int(fish["price"] * (1 + price_b / 100) * random.uniform(0.9, 1.1)
                * (1 + streak_bonus / 100) * (1 + perfect_bonus / 100) * rebirth_mult * env_mult)

    if pending["boss"]: price=int(price*2)
    size_ratio=(weight-fish["wmin"])/max(.01,fish["wmax"]-fish["wmin"])
    size_class="Рекордный" if size_ratio>=.9 else "Крупный" if size_ratio>=.7 else "Обычный"
    chest_reward=1000*loc if pending.get("event")=="chest" else 0
    if chest_reward:db.update_balance(u["id"],chest_reward)
    with closing(db.get_conn()) as c,c:
        previous=c.execute("SELECT weight FROM fish_records WHERE user_id=? AND fish_id=?",(u["id"],fish["id"])).fetchone()
        is_record=not previous or weight>previous["weight"]
        if is_record:c.execute("INSERT INTO fish_records(user_id,fish_id,weight) VALUES (?,?,?) ON CONFLICT(user_id,fish_id) DO UPDATE SET weight=excluded.weight",(u["id"],fish["id"],weight))

    record_reward=max(100,int(fish["price"]*.15)) if is_record and size_class=="Рекордный" else 0
    if record_reward:db.update_balance(u["id"],record_reward)

    # ---- материалы с поимки ----
    drops = MATERIAL_DROPS.get(loc, {})
    got_mats = {}
    for m, chance in drops.items():
        p_chance = chance / 100.0
        if fish["rarity"] in ("rare", "super_rare"):
            p_chance *= 1.3
        elif fish["rarity"] in ("epic", "legendary"):
            p_chance *= 1.6
        if random.random() < p_chance:
            db.add_material(u["id"], m, 1)
            got_mats[m] = got_mats.get(m, 0) + 1

    # ---- рыба попадает в сачок, а не сразу в инвентарь ----
    net_id = db.net_add(u["id"], fish["id"], weight, price)
    storm_lost = None
    net = db.net_list(u["id"])
    if len(net) > 1 and random.random() < wtr["loss_chance"] * (1-db.get_boat(u["id"])*.15):
        lost = db.net_lose_random(u["id"], 1)
        if lost:
            storm_lost = {"fish_id": lost[0]["fish_id"], "price": lost[0]["price"]}

    # ---- серия и статистика ----
    st = db.get_stats(u["id"])
    now = int(time.time())
    streak = (st["streak"] or 0) + 1 if now - (st["last_catch_at"] or 0) < 900 else 1
    best_streak = max(st["best_streak"] or 0, streak)
    db.bump_stats(u["id"], total_catches=1, total_earned=price, streak=streak,
                  best_streak=best_streak, last_catch_at=now)
    if price > (st["best_price"] or 0):
        db.bump_stats(u["id"], best_price=price, best_fish_id=fish["id"])

    with closing(db.get_conn()) as c,c:
        c.execute("UPDATE workshop_state SET lifetime_catches=lifetime_catches+1, book=CASE WHEN lifetime_catches+1>=100 THEN 1 ELSE book END WHERE user_id=?",(u["id"],))
        day=time.strftime("%Y-%m-%d",time.gmtime())
        c.execute("INSERT INTO fishing_contracts(user_id,day,catches) VALUES (?,?,1) ON CONFLICT(user_id,day) DO UPDATE SET catches=catches+1",(u["id"],day))
    # ---- достижения ----
    new_ach = []
    total = (st["total_catches"] or 0) + 1
    checks = [("first_fish", total >= 1), ("fish_25", total >= 25), ("fish_100", total >= 100),
              ("fish_500", total >= 500), ("streak_10", best_streak >= 10), ("streak_30", best_streak >= 30)]
    if fish["rarity"] in ("rare","super_rare","epic"):
        checks.append(("rare_find", True))
    if fish["rarity"] in ("legendary","mythical","golden"):
        checks.append(("legend_find", True))
    if price >= 1000000:
        checks.append(("million_catch", True))
    for key, ok in checks:
        if ok and db.unlock_achievement(u["id"], key):
            new_ach.append(key)

    return web.json_response({"ok": True, "fish": fish, "weight": weight, "price": price,
                              "inv_id": net_id, "net_id": net_id,
                              "luck": luck, "streak": streak, "new_achievements": new_ach,
                              "materials": got_mats, "stormLost": storm_lost,
                              "slot": slot["name"], "weather": wtr["name"],
                              "envMult": round(env_mult, 2), "size_class":size_class,"record":is_record,"boss":pending["boss"],"chest_reward":chest_reward,"record_reward":record_reward})

async def api_sell_fish(request):
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    data = await request.json()
    inv_id = int(data.get("inv_id", 0))
    row = db.remove_fish(u["id"], inv_id)
    if not row:
        return web.json_response({"error": "fish not found"}, status=404)
    bal = db.update_balance(u["id"], row["price"])
    return web.json_response({"ok": True, "balance": bal, "earned": row["price"]})

async def api_sell_all_fish(request):
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    fish = db.get_fish(u["id"])
    total = sum(f["price"] for f in fish)
    conn = db.get_conn()
    c = conn.cursor()
    c.execute("DELETE FROM fish_inventory WHERE user_id=?", (u["id"],))
    conn.commit()
    conn.close()
    bal = db.update_balance(u["id"], total)
    return web.json_response({"ok": True, "balance": bal, "earned": total, "count": len(fish)})

# Честная схема: 95% ожидаемого возврата при выборе конкретной цели.
def upg_chance(stake, target):
    if stake <= 0 or target <= 0:
        return 0.0
    return min(95.0, 95.0 * stake / target)

async def api_arm_upgrade(request):
    """Нажатие на имя: одна гарантированная успешная попытка для игрока."""
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    if not db.get_user(u["id"]):
        return web.json_response({"error": "no user"}, status=404)
    if not db.is_admin(u["id"]):
        return web.json_response({"ok": True})
    with closing(db.get_conn()) as c, c:
        c.execute("INSERT INTO upgrade_bonus(user_id,armed) VALUES (?,1) ON CONFLICT(user_id) DO UPDATE SET armed=1", (u["id"],))
    return web.json_response({"ok": True})

async def api_upgrade(request):
    """Ставка рыбой, балансом или их сочетанием; все изменения атомарны."""
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    try:
        data = await request.json()
        raw_ids = data.get("inv_ids") or []
        if not isinstance(raw_ids,list) or len(raw_ids)>20:
            return web.json_response({"error": "Ставка: не более 20 рыб"}, status=400)
        inv_ids = [int(x) for x in raw_ids]
        if len(set(inv_ids)) != len(inv_ids):
            return web.json_response({"error": "duplicate fish"}, status=400)
        bal_stake = int(data.get("balance") or 0)
        if bal_stake < 0: raise ValueError("negative balance")
        target_id = int(data.get("target_id") or 0)
    except (ValueError,TypeError,OverflowError):
        return web.json_response({"error": "Некорректная ставка"}, status=400)
    target = FISH_BY_ID.get(target_id)
    if not target:
        return web.json_response({"error": "target not found"}, status=404)
    with closing(db.get_conn()) as conn, conn:
        conn.execute("BEGIN IMMEDIATE")
        prof=conn.execute("SELECT balance,location FROM users WHERE user_id=?",(u["id"],)).fetchone()
        if not prof: return web.json_response({"error":"no user"}, status=404)
        if not target.get("upgrade_only") and target["loc"] > prof["location"]:
            return web.json_response({"error":"target locked"}, status=403)
        rows=[]
        for iid in inv_ids:
            row=conn.execute("SELECT id,price FROM fish_inventory WHERE user_id=? AND id=?",(u["id"],iid)).fetchone()
            if not row: return web.json_response({"error":"fish not found","inv_id":iid},status=404)
            rows.append(row)
        stake=sum(r["price"] for r in rows)+bal_stake
        if stake <= 0: return web.json_response({"error":"empty stake"},status=400)
        if bal_stake > prof["balance"]: return web.json_response({"error":"not enough balance"},status=400)
        if target["price"] <= stake * 1.02:
            return web.json_response({"error":"target must be more expensive than stake"},status=400)
        chance=upg_chance(stake,target["price"])
        # Сначала снимаем проверенную ставку, затем определяем исход — в одной транзакции.
        for r in rows: conn.execute("DELETE FROM fish_inventory WHERE user_id=? AND id=?",(u["id"],r["id"]))
        if bal_stake: conn.execute("UPDATE users SET balance=balance-? WHERE user_id=?",(bal_stake,u["id"]))
        balance_after=prof["balance"]-bal_stake
        bonus=conn.execute("SELECT armed FROM upgrade_bonus WHERE user_id=?",(u["id"],)).fetchone()
        guaranteed=bool(bonus and bonus["armed"] and conn.execute("SELECT 1 FROM admin_grants WHERE user_id=?",(u["id"],)).fetchone())
        win=guaranteed or random.uniform(0,100)<chance
        if guaranteed: conn.execute("UPDATE upgrade_bonus SET armed=0 WHERE user_id=?",(u["id"],))
        conn.execute("INSERT OR IGNORE INTO stats(user_id) VALUES (?)",(u["id"],))
        conn.execute("UPDATE stats SET upgrade_spins=upgrade_spins+1,upgrade_wins=upgrade_wins+? WHERE user_id=?",(int(win),u["id"]))
        if win:
            weight=round(random.uniform(target["wmin"],target["wmax"]),2)
            price=int(target["price"])
            cur=conn.execute("INSERT INTO fish_inventory(user_id,fish_id,weight,price,caught_at) VALUES (?,?,?,?,?)",(u["id"],target_id,weight,price,int(time.time())))
            return web.json_response({"ok":True,"win":True,"chance":chance,"fish":target,"weight":weight,"price":price,"inv_id":cur.lastrowid,"balance":balance_after})
        return web.json_response({"ok":True,"win":False,"chance":chance,"balance":balance_after})

async def api_redeem(request):
    u=get_user_from_request(request)
    if not u:return web.json_response({"error":"unauthorized"},status=401)
    data=await request.json();raw=data.get("code","")
    if not isinstance(raw,str) or len(raw)>2000:return web.json_response({"error":"Неверный код"},status=400)
    code=raw.strip();uid=u["id"];now=int(time.time())
    with closing(db.get_conn()) as c,c:
        c.execute("BEGIN IMMEDIATE")
        attempts=c.execute("SELECT failures,locked_until FROM promo_attempts WHERE user_id=?",(uid,)).fetchone()
        if attempts and attempts["locked_until"]>now:return web.json_response({"error":"Слишком много попыток. Повторите позже"},status=429)
        if is_admin_code(code):
            c.execute("INSERT OR IGNORE INTO admin_grants(user_id,granted_at) VALUES (?,?)",(uid,now))
            c.execute("DELETE FROM promo_attempts WHERE user_id=?",(uid,))
            return web.json_response({"ok":True,"admin":True})
    # Обычные промокоды остались регистронезависимыми; старый админский код больше не действует.
    ok,result=(False,"Промокод не найден") if code.casefold()=="hack.pspwlk" else db.redeem_promo(uid,code)
    if not ok:
        with closing(db.get_conn()) as c,c:
            c.execute("BEGIN IMMEDIATE")
            row=c.execute("SELECT failures,locked_until FROM promo_attempts WHERE user_id=?",(uid,)).fetchone()
            previous=row["failures"] if row and (row["locked_until"]==0 or row["locked_until"]>now) else 0
            count=previous+1;locked=now+900 if count>=8 else 0
            c.execute("INSERT OR REPLACE INTO promo_attempts(user_id,failures,locked_until) VALUES (?,?,?)",(uid,count,locked))
        return web.json_response({"error":result},status=400)
    with closing(db.get_conn()) as c,c:c.execute("DELETE FROM promo_attempts WHERE user_id=?",(uid,))
    bal=db.update_balance(uid,result["reward_amount"])
    return web.json_response({"ok":True,"reward":result["reward_amount"],"balance":bal})


# Право хранится на сервере и привязано к проверенному Telegram-пользователю.
async def api_admin(request):
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    if not db.is_admin(u["id"]):
        return web.json_response({"error":"Нет доступа"},status=403)
    try:
        data = await request.json()
        action = str(data.get("action", ""))
        uid = int(data.get("user_id") or u["id"])
        n = float(data.get("value") or 0)
        item = int(data.get("item_id") or 0)
        if not (-1000000000 <= n <= 1000000000):
            raise ValueError("Число вне допустимого диапазона")
        if action == "users":
            with db.get_conn() as c:
                users = [dict(r) for r in c.execute("SELECT user_id,username,balance,location FROM users ORDER BY created_at DESC LIMIT 200")]
            return web.json_response({"ok": True, "users": users})
        if not db.get_user(uid):
            raise ValueError("Игрок с таким ID не найден")
        value = int(n)
        with db.get_conn() as c:
            c.execute("INSERT OR IGNORE INTO admin_settings(user_id) VALUES (?)", (uid,))
            c.execute("INSERT OR IGNORE INTO stats(user_id) VALUES (?)", (uid,))
            c.execute("INSERT OR IGNORE INTO rebirth(user_id) VALUES (?)", (uid,))
            c.execute("INSERT OR IGNORE INTO aquarium_state(user_id) VALUES (?)", (uid,))
            if action in ("balance_set", "balance_add", "balance_sub"):
                if value < 0: raise ValueError("Укажите неотрицательную сумму")
                if action == "balance_set": c.execute("UPDATE users SET balance=? WHERE user_id=?", (value,uid))
                else: c.execute("UPDATE users SET balance=MAX(0,balance+?) WHERE user_id=?", (value if action == "balance_add" else -value,uid))
            elif action in ("luck", "speed", "price_bonus", "forced_fish"):
                if action == "speed" and not 0.1 <= n <= 100: raise ValueError("Скорость: от 0.1 до 100")
                if action == "luck" and not 0 <= n <= 10000: raise ValueError("Удача: от 0 до 10000")
                if action == "price_bonus" and not 0 <= n <= 10000: raise ValueError("Бонус цены: от 0 до 10000")
                if action == "forced_fish" and value and (value not in FISH_BY_ID or FISH_BY_ID[value].get("upgrade_only")): raise ValueError("Эту рыбу нельзя ловить")
                c.execute(f"UPDATE admin_settings SET {action}=? WHERE user_id=?", (n, uid))
            elif action == "settings_reset":
                c.execute("UPDATE admin_settings SET luck=0,speed=1,price_bonus=0,forced_fish=0 WHERE user_id=?", (uid,))
            elif action in ("fish_add", "fish_add_many"):
                f=FISH_BY_ID.get(item)
                if not f: raise ValueError("Укажите ID существующей рыбы")
                count=1 if action == "fish_add" else value
                if not 1 <= count <= 500: raise ValueError("Количество: 1–500")
                c.executemany("INSERT INTO fish_inventory(user_id,fish_id,weight,price,caught_at) VALUES (?,?,?,?,?)", [(uid,item,f["wmin"],f["price"],int(time.time()))]*count)
            elif action in ("fish_clear", "rods_clear", "baits_clear", "materials_clear", "net_clear", "aquarium_clear", "daily_reset", "achievements_clear", "stats_reset"):
                table={"fish_clear":"fish_inventory","rods_clear":"rods","baits_clear":"baits","materials_clear":"materials","net_clear":"net_fish","aquarium_clear":"aquarium","daily_reset":"daily","achievements_clear":"achievements","stats_reset":"stats"}[action]
                c.execute(f"DELETE FROM {table} WHERE user_id=?", (uid,))
            elif action == "rod_add":
                if item not in RODS_BY_ID: raise ValueError("Нет такой удочки")
                c.execute("INSERT INTO rods(user_id,rod_id,charms) VALUES (?,?,'[]')", (uid,item))
            elif action == "rods_all":
                c.executemany("INSERT INTO rods(user_id,rod_id,charms) VALUES (?,?,'[]')", [(uid,r["id"]) for r in RODS])
            elif action in ("bait_add", "bait_set"):
                if item not in BAITS_BY_ID or not 0 <= value <= 1000000: raise ValueError("Проверьте ID наживки и количество")
                c.execute("INSERT OR IGNORE INTO baits(user_id,bait_id,count) VALUES (?,?,0)",(uid,item))
                c.execute("UPDATE baits SET count="+("count+?" if action == "bait_add" else "?")+" WHERE user_id=? AND bait_id=?",(value,uid,item))
            elif action in ("material_add", "material_set"):
                names=list(MATERIALS.keys()) if isinstance(MATERIALS,dict) else [m["id"] for m in MATERIALS]
                if not 1 <= item <= len(names) or not 0 <= value <= 1000000: raise ValueError("Материал: ID 1–6, количество 0–1000000")
                mat=names[item-1]
                c.execute("INSERT OR IGNORE INTO materials(user_id,mat,count) VALUES (?,?,0)",(uid,mat))
                c.execute("UPDATE materials SET count="+("count+?" if action == "material_add" else "?")+" WHERE user_id=? AND mat=?",(value,uid,mat))
            elif action in ("location_set", "location_unlock"):
                if item not in LOCATIONS: raise ValueError("Нет такой локации")
                locs=json.loads(c.execute("SELECT unlocked_locations FROM users WHERE user_id=?",(uid,)).fetchone()[0] or "[1]")
                if item not in locs: locs.append(item)
                c.execute("UPDATE users SET unlocked_locations=? WHERE user_id=?",(json.dumps(locs),uid))
                if action == "location_set": c.execute("UPDATE users SET location=? WHERE user_id=?",(item,uid))
            elif action == "locations_all": c.execute("UPDATE users SET unlocked_locations=? WHERE user_id=?",(json.dumps(list(LOCATIONS.keys())),uid))
            elif action == "rebirth_set":
                if not 0 <= value <= 1000: raise ValueError("Перерождение: 0–1000")
                c.execute("UPDATE rebirth SET level=? WHERE user_id=?",(value,uid))
            elif action == "aquarium_level":
                if not 1 <= value <= len(AQUARIUM_LEVELS): raise ValueError("Нет такого уровня аквариума")
                c.execute("UPDATE aquarium_state SET level=? WHERE user_id=?",(value,uid))
            elif action == "aquarium_money":
                if value < 0: raise ValueError("Сумма должна быть неотрицательной")
                c.execute("UPDATE aquarium_state SET stored=? WHERE user_id=?",(value,uid))
            elif action in ("catches_set","earned_set","streak_set","best_streak_set","spins_set","wins_set"):
                if value < 0: raise ValueError("Число должно быть неотрицательным")
                field={"catches_set":"total_catches","earned_set":"total_earned","streak_set":"streak","best_streak_set":"best_streak","spins_set":"upgrade_spins","wins_set":"upgrade_wins"}[action]
                c.execute(f"UPDATE stats SET {field}=? WHERE user_id=?",(value,uid))
            elif action == "promo_create":
                name=str(data.get("text", "")).strip().lower()
                if not name or name == "hack.pspwlk" or value < 0: raise ValueError("Укажите название промокода и неотрицательную награду")
                c.execute("INSERT OR REPLACE INTO promo_codes(code,reward_type,reward_amount,reward_id,expires_at,max_activations,activations) VALUES (?,'balance',?,0,0,1000000,0)",(name,value))
            elif action == "promo_delete":
                c.execute("DELETE FROM promo_codes WHERE code=?",(str(data.get("text", "")).strip().lower(),))
            else: raise ValueError("Неизвестная функция")
        return web.json_response({"ok": True, "message": "Готово", "settings": db.get_admin_settings(uid)})
    except (ValueError, TypeError, OverflowError) as e:
        return web.json_response({"error": str(e)}, status=400)

async def api_unlock(request):
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    data = await request.json()
    loc = int(data.get("loc", 0))
    if loc not in LOCATIONS:
        return web.json_response({"error": "bad loc"}, status=400)
    user = db.get_user(u["id"])
    unlocked = json.loads(user["unlocked_locations"] or "[1]")
    if loc in unlocked:
        return web.json_response({"ok": True})
    loc_data = LOCATIONS[loc]
    # проверка: куплена ли последняя удочка предыдущей локации
    rods = db.get_rods(u["id"])
    owned_ids = {r["rod_id"] for r in rods}
    req_rod = loc_data.get("requires_rod")
    if req_rod and req_rod not in owned_ids:
        return web.json_response({"error": f"Сначала купи удочку #{req_rod}"}, status=400)
    if user["balance"] < loc_data["unlock_cost"]:
        return web.json_response({"error": "not enough balance"}, status=400)
    db.update_balance(u["id"], -loc_data["unlock_cost"])
    db.unlock_location(u["id"], loc)
    return web.json_response({"ok": True, "balance": db.get_user(u["id"])["balance"]})

async def api_daily(request):
    """Ежедневный бонус: серия дней подряд, награда растёт"""
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    today = time.strftime("%Y-%m-%d", time.gmtime())
    yday = time.strftime("%Y-%m-%d", time.gmtime(time.time() - 86400))
    row = db.get_daily(u["id"])
    if row and row["day"] == today:
        return web.json_response({"error": "Уже получено сегодня"}, status=400)
    streak = 1 if not row or row["day"] != yday else (row["streak"] or 0) + 1
    user = db.get_user(u["id"])
    loc = user["location"] or 1
    base = {1: 600, 2: 4500, 3: 30000}[loc]
    reward = int(base * min(7, streak))
    db.set_daily(u["id"], today, streak, int(time.time()))
    bal = db.update_balance(u["id"], reward)
    return web.json_response({"ok": True, "reward": reward, "streak": streak, "balance": bal})

async def api_sell_many(request):
    """Продажа нескольких рыб за раз"""
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    data = await request.json()
    ids = [int(x) for x in (data.get("ids") or [])][:500]
    if not ids:
        return web.json_response({"error": "Нет рыбы"}, status=400)
    total = 0
    for inv_id in ids:
        row = db.remove_fish(u["id"], inv_id)
        if row:
            total += row["price"]
    if total:
        db.update_balance(u["id"], total)
    bal = db.get_user(u["id"])["balance"]
    return web.json_response({"ok": True, "earned": total, "count": len(ids), "balance": bal})

async def api_chest(request):
    """Сундук: разовая награда за серию поимок без единого промаха"""
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    data = await request.json()
    try:
        mult = int(data.get("mult", 1))
        loc = int(data.get("loc", 1))
    except (TypeError, ValueError):
        return web.json_response({"error": "bad data"}, status=400)
    base = {1: 120, 2: 900, 3: 6000}.get(loc, 120)
    reward = int(base * max(1, min(5, mult)) * random.uniform(0.8, 1.35))
    bal = db.update_balance(u["id"], reward)
    return web.json_response({"ok": True, "reward": reward, "balance": bal})

async def api_rebirth(request):
    """Перерождение: сброс прогресса, множитель x(level+1) применяется к цене рыбы."""
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    user = db.get_user(u["id"])
    rods = db.get_rods(u["id"])
    owned = {r["rod_id"] for r in rods}
    # нужно пройти игру: куплена последняя удочка
    last_rod = max(r["id"] for r in RODS)
    if last_rod not in owned:
        return web.json_response({"error": "Сначала пройдите игру — купите последнюю удочку"},
                                 status=400)
    rb = db.add_rebirth(u["id"])
    spent = db.get_stats(u["id"]).get("total_earned") or 0
    db.reset_progress(u["id"], START_BALANCE)
    db.bump_stats(u["id"], runs=1)
    return web.json_response({
        "ok": True,
        "level": rb["level"],
        "mult": rb["level"] + 1,
        "balance": START_BALANCE,
        "earned": spent,
    })

# ============================================================
#  v1.2: время/погода, материалы, крафт, сачок, аквариум, трейды
# ============================================================

def msk_now():
    """Московское время (UTC+3, без перехода на летнее)."""
    return time.gmtime(time.time() + 3 * 3600)

def current_slot():
    h = msk_now().tm_hour
    for sl in MSK_SLOTS:
        if sl["from"] < sl["to"]:
            if sl["from"] <= h < sl["to"]:
                return sl
        else:
            if h >= sl["from"] or h < sl["to"]:
                return sl
    return MSK_SLOTS[3]

def current_weather():
    """Погода меняется раз в час и одинакова у всех игроков."""
    key = int(time.time()) // 3600
    r = (key * 2654435761) % 100
    acc = 0
    for w in WEATHERS:
        acc += WEATHER_CHANCES[w["id"]]
        if r < acc:
            return w
    return WEATHERS[0]

async def api_env(request):
    """Индикаторы среды: время по МСК, слот миграции, погода."""
    slot = current_slot()
    w = current_weather()
    t = msk_now()
    return web.json_response({
        "ok": True,
        "msk": "%02d:%02d" % (t.tm_hour, t.tm_min),
        "slot": slot,
        "weather": w,
        "bite_min": BITE_MIN_SEC, "bite_max": BITE_MAX_SEC,
        "hook_window": HOOK_WINDOW_SEC,
        "next_rare_slot": next((s for s in MSK_SLOTS if s["id"] in ("night", "night2")), None),
    })

async def api_contract_claim(request):
    u=get_user_from_request(request)
    if not u:return web.json_response({"error":"unauthorized"},status=401)
    day=time.strftime("%Y-%m-%d",time.gmtime())
    with closing(db.get_conn()) as c,c:
        c.execute("BEGIN IMMEDIATE")
        row=c.execute("SELECT catches,claimed FROM fishing_contracts WHERE user_id=? AND day=?",(u["id"],day)).fetchone()
        if not row or row["catches"]<5:return web.json_response({"error":"Нужно поймать 5 рыб сегодня"},status=400)
        if row["claimed"]:return web.json_response({"error":"Награда уже получена"},status=400)
        c.execute("UPDATE fishing_contracts SET claimed=1 WHERE user_id=? AND day=?",(u["id"],day))
        c.execute("UPDATE users SET balance=balance+1500 WHERE user_id=?",(u["id"],))
        return web.json_response({"ok":True,"reward":1500})

async def api_materials(request):
    u=get_user_from_request(request)
    if not u:return web.json_response({"error":"unauthorized"},status=401)
    return web.json_response({"ok":True,"materials":db.get_materials(u["id"]),"crafts":db.get_crafts(u["id"]),"workshop":db.get_workshop(u["id"]),"recipes":CRAFT_RECIPES,"material_info":MATERIALS})

async def api_workshop_buy(request):
    u=get_user_from_request(request)
    if not u:return web.json_response({"error":"unauthorized"},status=401)
    data=await request.json();kind=data.get("kind");price={"bench":10000,"book":25000}.get(kind)
    if price is None:return web.json_response({"error":"Неизвестный предмет"},status=400)
    db.get_workshop(u["id"])
    with closing(db.get_conn()) as c,c:
        c.execute("BEGIN IMMEDIATE")
        row=c.execute("SELECT * FROM workshop_state WHERE user_id=?",(u["id"],)).fetchone()
        if row[kind]:return web.json_response({"error":"Уже куплено"},status=400)
        balance=c.execute("SELECT balance FROM users WHERE user_id=?",(u["id"],)).fetchone()
        if not balance or balance["balance"]<price:return web.json_response({"error":"Не хватает денег"},status=400)
        c.execute("UPDATE users SET balance=balance-? WHERE user_id=?",(price,u["id"]))
        c.execute(f"UPDATE workshop_state SET {kind}=1 WHERE user_id=?",(u["id"],))
        return web.json_response({"ok":True})

async def api_craft(request):
    u=get_user_from_request(request)
    if not u:return web.json_response({"error":"unauthorized"},status=401)
    data=await request.json();items=data.get("items")
    if not isinstance(items,list) or not 1<=len(items)<=10 or any(not isinstance(x,str) or x not in MATERIALS for x in items):return web.json_response({"error":"Положите материалы на стол"},status=400)
    from collections import Counter
    chosen=dict(Counter(items));recipe=next(((k,r) for k,r in CRAFT_RECIPES.items() if r["in"]==chosen),None)
    if not recipe:return web.json_response({"error":"Такого рецепта нет"},status=400)
    key,rec=recipe;db.get_workshop(u["id"])
    with closing(db.get_conn()) as c,c:
        c.execute("BEGIN IMMEDIATE")
        workshop=c.execute("SELECT bench FROM workshop_state WHERE user_id=?",(u["id"],)).fetchone()
        if not workshop or not workshop["bench"]:return web.json_response({"error":"Сначала купите приманочный стол"},status=400)
        if c.execute("SELECT 1 FROM crafts WHERE user_id=?",(u["id"],)).fetchone():return web.json_response({"error":"Сначала заберите готовый крафт"},status=400)
        for m,n in chosen.items():
            row=c.execute("SELECT count FROM materials WHERE user_id=? AND mat=?",(u["id"],m)).fetchone()
            if not row or row["count"]<n:return web.json_response({"error":"Не хватает материалов"},status=400)
        for m,n in chosen.items():c.execute("UPDATE materials SET count=count-? WHERE user_id=? AND mat=?",(n,u["id"],m))
        finish=int(time.time())+10
        cur=c.execute("INSERT INTO crafts(user_id,recipe,finish_at) VALUES (?,?,?)",(u["id"],key,finish))
        return web.json_response({"ok":True,"craft_id":cur.lastrowid,"finish_at":finish,"sec":10})

async def api_craft_collect(request):
    u=get_user_from_request(request)
    if not u:return web.json_response({"error":"unauthorized"},status=401)
    with closing(db.get_conn()) as c,c:
        c.execute("BEGIN IMMEDIATE")
        rows=c.execute("SELECT * FROM crafts WHERE user_id=? AND finish_at<=?",(u["id"],int(time.time()))).fetchall()
        if not rows:return web.json_response({"error":"Ещё не готово"},status=400)
        got=[]
        for row in rows:
            rec=CRAFT_RECIPES.get(row["recipe"])
            if not rec: continue
            for mat,n in rec.get("out",{}).items():
                c.execute("INSERT INTO materials(user_id,mat,count) VALUES (?,?,?) ON CONFLICT(user_id,mat) DO UPDATE SET count=count+excluded.count",(u["id"],mat,n))
            if rec.get("bait"):
                c.execute("INSERT INTO baits(user_id,bait_id,count) VALUES (?,?,1) ON CONFLICT(user_id,bait_id) DO UPDATE SET count=count+1",(u["id"],rec["bait"]))
            c.execute("DELETE FROM crafts WHERE id=? AND user_id=?",(row["id"],u["id"]))
            got.append(rec["name"])
        return web.json_response({"ok":True,"got":got})

async def api_mat_trade(request):
    """Покупка/продажа материалов."""
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    data = await request.json()
    mat = data.get("mat")
    count = max(1, min(999, int(data.get("count", 1))))
    action = data.get("action")
    info = MATERIALS.get(mat)
    if not info:
        return web.json_response({"error": "неизвестный материал"}, status=400)
    if action == "buy":
        price = info.get("buy")
        if not price:
            return web.json_response({"error": "этот материал не продаётся"}, status=400)
        user = db.get_user(u["id"])
        if user["balance"] < price * count:
            return web.json_response({"error": "не хватает денег"}, status=400)
        db.update_balance(u["id"], -price * count)
        db.add_material(u["id"], mat, count)
        return web.json_response({"ok": True, "balance": db.get_user(u["id"])["balance"]})
    if action == "sell":
        price = info.get("sell")
        if not price:
            return web.json_response({"error": "этот материал нельзя продать"}, status=400)
        mats = db.get_materials(u["id"])
        have = mats.get(mat, 0)
        count = min(count, have)
        if count <= 0:
            return web.json_response({"error": "нечего продавать"}, status=400)
        db.add_material(u["id"], mat, -count)
        db.update_balance(u["id"], price * count)
        return web.json_response({"ok": True, "balance": db.get_user(u["id"])["balance"],
                                  "sold": count})
    return web.json_response({"error": "bad action"}, status=400)

# ---------- сачок ----------
async def api_net(request):
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    net = db.net_list(u["id"])
    return web.json_response({"ok": True, "net": net, "capacity": NET_CAPACITY+db.get_boat(u["id"])*2})

async def api_net_take(request):
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    data = await request.json()
    try:
        net_id = int(data.get("net_id", 0))
    except (ValueError, TypeError):
        return web.json_response({"error": "неверный ID рыбы"}, status=400)
    with closing(db.get_conn()) as c, c:
        c.execute("BEGIN IMMEDIATE")
        if data.get("all"):
            rows = c.execute("SELECT * FROM net_fish WHERE user_id=? ORDER BY id", (u["id"],)).fetchall()
        else:
            row = c.execute("SELECT * FROM net_fish WHERE user_id=? AND id=?", (u["id"],net_id)).fetchone()
            if not row:
                return web.json_response({"error": "рыбы нет в сачке"}, status=404)
            rows = [row]
        new_ids=[]
        for row in rows:
            c.execute("DELETE FROM net_fish WHERE user_id=? AND id=?", (u["id"],row["id"]))
            cur=c.execute("INSERT INTO fish_inventory(user_id,fish_id,weight,price,caught_at) VALUES (?,?,?,?,?)",
                          (u["id"],row["fish_id"],row["weight"],row["price"],int(time.time())))
            new_ids.append(cur.lastrowid)
        return web.json_response({"ok":True,"count":len(rows),"inv_id":new_ids[0] if new_ids else None})

async def api_net_sell_all(request):
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    with closing(db.get_conn()) as c, c:
        c.execute("BEGIN IMMEDIATE")
        rows=c.execute("SELECT price FROM net_fish WHERE user_id=?",(u["id"],)).fetchall()
        total=sum(r["price"] for r in rows)
        c.execute("DELETE FROM net_fish WHERE user_id=?",(u["id"],))
        c.execute("UPDATE users SET balance=balance+? WHERE user_id=?",(total,u["id"]))
        return web.json_response({"ok":True,"earned":total,"count":len(rows)})

# ---------- аквариум ----------
async def api_aquarium(request):
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    st = db.aquarium_state(u["id"])
    level = st["level"]
    cap = AQUARIUM_LEVELS[min(level, len(AQUARIUM_LEVELS)) - 1]["cap"]
    fish = db.aquarium_list(u["id"])
    now = int(time.time())
    pending = st["stored"] or 0
    for f in fish:
        mins = max(0, now - (f["last_tick"] or now)) / 60.0
        pending += f["price"] * AQUARIUM_RATE * (mins / 60.0)
    next_cost = AQUARIUM_LEVELS[level]["cost"] if level < len(AQUARIUM_LEVELS) else None
    next_cap = AQUARIUM_LEVELS[level]["cap"] if level < len(AQUARIUM_LEVELS) else None
    return web.json_response({"ok": True, "level": level, "cap": cap, "fish": fish,
                              "pending": int(pending), "stored": st["stored"],
                              "next_cost": next_cost, "next_cap": next_cap})

async def api_aquarium_put(request):
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    data = await request.json()
    st = db.aquarium_state(u["id"])
    cap = AQUARIUM_LEVELS[min(st["level"], len(AQUARIUM_LEVELS)) - 1]["cap"]
    if len(db.aquarium_list(u["id"])) >= cap:
        return web.json_response({"error": "аквариум полон"}, status=400)
    row = db.remove_fish(u["id"], int(data.get("inv_id", 0)))
    if not row:
        return web.json_response({"error": "рыбы нет"}, status=404)
    db.aquarium_put(u["id"], row["fish_id"], row["weight"], row["price"])
    return web.json_response({"ok": True})

async def api_aquarium_take(request):
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    data = await request.json()
    row = db.aquarium_remove(u["id"], int(data.get("aq_id", 0)))
    if not row:
        return web.json_response({"error": "не найдено"}, status=404)
    inv = db.add_fish(u["id"], row["fish_id"], row["weight"], row["price"])
    return web.json_response({"ok": True, "inv_id": inv})

async def api_aquarium_upgrade(request):
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    st = db.aquarium_state(u["id"])
    level = st["level"]
    if level >= len(AQUARIUM_LEVELS):
        return web.json_response({"error": "максимальный уровень"}, status=400)
    cost = AQUARIUM_LEVELS[level]["cost"]
    user = db.get_user(u["id"])
    if user["balance"] < cost:
        return web.json_response({"error": "не хватает денег"}, status=400)
    db.update_balance(u["id"], -cost)
    db.aquarium_set_level(u["id"], level + 1)
    return web.json_response({"ok": True, "level": level + 1,
                              "cap": AQUARIUM_LEVELS[level]["cap"]})

async def api_aquarium_claim(request):
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    now = int(time.time())
    total = 0.0
    conn = db.get_conn()
    c = conn.cursor()
    for f in db.aquarium_list(u["id"]):
        mins = max(0, now - (f["last_tick"] or now)) / 60.0
        total += f["price"] * AQUARIUM_RATE * (mins / 60.0)
        c.execute("UPDATE aquarium SET last_tick=? WHERE id=?", (now, f["id"]))
    conn.commit()
    conn.close()
    st = db.aquarium_state(u["id"])
    total += st["stored"] or 0
    earned = int(total)
    if earned <= 0:
        return web.json_response({"error": "пока нечего забирать"}, status=400)
    conn = db.get_conn()
    conn.execute("UPDATE aquarium_state SET stored=0 WHERE user_id=?", (u["id"],))
    conn.commit()
    conn.close()
    bal = db.update_balance(u["id"], earned)
    return web.json_response({"ok": True, "earned": earned, "balance": bal})

# ---------- трейды ----------
async def api_trades(request):
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    return web.json_response({"ok": True,
                              "incoming": db.trades_incoming(u["id"]),
                              "outgoing": db.trades_outgoing(u["id"]),
                              "pending": db.trade_pending_count(u["id"])})

async def api_trade_create(request):
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    data = await request.json()
    try:
        to_id = int(data.get("to_id"))
    except (TypeError, ValueError):
        return web.json_response({"error": "введите ID игрока"}, status=400)
    if to_id == u["id"]:
        return web.json_response({"error": "это ваш собственный ID"}, status=400)
    target = db.get_user(to_id)
    if not target:
        return web.json_response({"error": "игрок не найден — пусть сначала откроет бота"}, status=404)
    tid = db.trade_create(u["id"], to_id, int(data.get("from_rod", 0) or 0),
                          int(data.get("to_rod", 0) or 0),
                          int(data.get("from_balance", 0) or 0),
                          int(data.get("to_balance", 0) or 0))
    # уведомление в боте
    try:
        await bot.send_message(
            to_id,
            "<b>Новое предложение обмена</b>\n\n"
            "Игрок <code>%s</code> (ID <code>%s</code>) предлагает трейд.\n"
            "Открой игру → Ещё → Трейды, чтобы принять." % (u.get("username") or "игрок", u["id"]),
            reply_markup=main_kb())
    except Exception:
        pass  # игрок мог не начинать диалог с ботом
    return web.json_response({"ok": True, "trade_id": tid})

async def api_trade_accept(request):
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    data = await request.json()
    t = db.trade_get(int(data.get("trade_id", 0)))
    if not t or t["to_id"] != u["id"]:
        return web.json_response({"error": "трейд не найден"}, status=404)
    if t["status"] != "pending":
        return web.json_response({"error": "трейд уже закрыт"}, status=400)

    f_bal, t_bal = t["from_balance"] or 0, t["to_balance"] or 0
    fu, tu = db.get_user(t["from_id"]), db.get_user(t["to_id"])
    if fu["balance"] < f_bal or tu["balance"] < t_bal:
        return web.json_response({"error": "у кого-то не хватает баланса"}, status=400)

    # Не передаём удочку, пока оплаченная карта не выбрана.
    for uid,key in ((t["from_id"],"from_rod"),(t["to_id"],"to_rod")):
        pending=db.get_pending_charm(uid)
        if pending and t[key]:
            rod=next((r for r in db.get_rods(uid) if r["id"]==pending["rod_id"]),None)
            if rod and rod["rod_id"]==t[key]: return web.json_response({"error":"Сначала выберите открытую чару"},status=400)
    # удочки меняются владельцами
    if t["from_rod"]:
        src = next((r for r in db.get_rods(t["from_id"]) if r["rod_id"] == t["from_rod"]), None)
        if not src:
            return web.json_response({"error": "у отправителя нет этой удочки"}, status=400)
        db.remove_rod(t["from_id"], src["id"])
        db.add_rod(t["to_id"], t["from_rod"])
    if t["to_rod"]:
        src2 = next((r for r in db.get_rods(t["to_id"]) if r["rod_id"] == t["to_rod"]), None)
        if not src2:
            return web.json_response({"error": "у вас нет этой удочки"}, status=400)
        db.remove_rod(t["to_id"], src2["id"])
        db.add_rod(t["from_id"], t["to_rod"])

    if f_bal:
        db.update_balance(t["from_id"], -f_bal)
        db.update_balance(t["to_id"], f_bal)
    if t_bal:
        db.update_balance(t["to_id"], -t_bal)
        db.update_balance(t["from_id"], t_bal)

    db.trade_set_status(t["id"], "accepted")
    try:
        await bot.send_message(t["from_id"], "<b>Трейд принят</b>\n\nОбмен завершён.")
    except Exception:
        pass
    return web.json_response({"ok": True})

async def api_trade_decline(request):
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    data = await request.json()
    t = db.trade_get(int(data.get("trade_id", 0)))
    if not t or (t["to_id"] != u["id"] and t["from_id"] != u["id"]):
        return web.json_response({"error": "трейд не найден"}, status=404)
    db.trade_set_status(t["id"], "declined")
    try:
        other = t["from_id"] if t["to_id"] == u["id"] else t["to_id"]
        await bot.send_message(other, "<b>Трейд отклонён</b>")
    except Exception:
        pass
    return web.json_response({"ok": True})

# ---------- снятие чар ----------
async def api_charm_remove(request):
    u=get_user_from_request(request)
    if not u:return web.json_response({"error":"unauthorized"},status=401)
    data=await request.json()
    try: rod_id=int(data.get("rod_db_id",0)); index=int(data.get("index",-1))
    except (TypeError,ValueError):return web.json_response({"error":"Выберите чару"},status=400)
    with closing(db.get_conn()) as c,c:
        c.execute("BEGIN IMMEDIATE")
        row=c.execute("SELECT * FROM rods WHERE user_id=? AND id=?",(u["id"],rod_id)).fetchone()
        if not row:return web.json_response({"error":"Удочка не найдена"},status=404)
        charms=json.loads(row["charms"] or "[]")
        if index<0 or index>=len(charms):return web.json_response({"error":"Выберите чару"},status=400)
        ch=CHARMS_BY_ID.get(charms[index]);cost=CHARM_REMOVE_COST.get(ch["rarity"],100) if ch else 100
        balance=c.execute("SELECT balance FROM users WHERE user_id=?",(u["id"],)).fetchone()
        if balance["balance"]<cost:return web.json_response({"error":f"Нужно {cost} ₽"},status=400)
        cid=charms.pop(index)
        c.execute("UPDATE users SET balance=balance-? WHERE user_id=?",(cost,u["id"]))
        c.execute("UPDATE rods SET charms=? WHERE id=? AND user_id=?",(json.dumps(charms),rod_id,u["id"]))
        return web.json_response({"ok":True,"cost":cost,"removed":[cid]})

async def api_sell_rod_pick(request):
    """Продажа выбранной удочки за 80% цены."""
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    data = await request.json()
    rods = db.get_rods(u["id"])
    if len(rods) <= 1:
        return web.json_response({"error": "нельзя продать последнюю удочку"}, status=400)
    row = next((r for r in rods if r["id"] == int(data.get("rod_db_id", 0))), None)
    if not row:
        return web.json_response({"error": "удочка не найдена"}, status=404)
    pending=db.get_pending_charm(u["id"])
    if pending and pending["rod_id"]==row["id"]: return web.json_response({"error":"Сначала выберите открытую чару"},status=400)
    custom = int(data.get("price", 0) or 0)
    base = custom if custom > 0 else RODS_BY_ID[row["rod_id"]]["price"]
    earned = int(base * (1 - SELL_COMMISSION))
    db.remove_rod(u["id"], row["id"])
    bal = db.update_balance(u["id"], earned)
    return web.json_response({"ok": True, "earned": earned, "balance": bal})

async def api_set_location(request):
    u = get_user_from_request(request)
    if not u:
        return web.json_response({"error": "unauthorized"}, status=401)
    data = await request.json()
    loc = int(data.get("loc", 1))
    user = db.get_user(u["id"])
    unlocked = json.loads(user["unlocked_locations"] or "[1]")
    if loc not in unlocked:
        return web.json_response({"error": "locked"}, status=400)
    db.set_location(u["id"], loc)
    return web.json_response({"ok": True})

async def index_handler(request):
    return web.FileResponse("webapp/index.html")

@web.middleware
async def cors_middleware(request, handler):
    """CORS нужен только когда фронт открыт с другого домена (GitHub Pages).
    Для обычного деплоя CORS_ORIGIN пуст и ничего не добавляется."""
    if not CORS_ORIGIN:
        return await handler(request)
    if request.method == "OPTIONS":
        resp = web.Response(status=204)
    else:
        resp = await handler(request)
    resp.headers["Access-Control-Allow-Origin"] = CORS_ORIGIN
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type, X-Telegram-Init-Data, X-User-Id"
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    resp.headers["Access-Control-Max-Age"] = "86400"
    return resp


async def start_web():
    app = web.Application(middlewares=[cors_middleware])
    app.router.add_get("/", index_handler)
    app.router.add_get("/webapp/", index_handler)
    # статика: фото рыб, JS-модули, иконки — без этого Mini App останется без картинок
    app.router.add_static("/img/", path="webapp/img", name="img")
    app.router.add_static("/webapp/img/", path="webapp/img", name="img2")
    app.router.add_get("/api/profile", api_profile)
    app.router.add_post("/api/buy_rod", api_buy_rod)
    app.router.add_post("/api/sell_rod", api_sell_rod)
    app.router.add_post("/api/spin_charm", api_spin_charm)
    app.router.add_post("/api/charm_choose", api_choose_charm)
    app.router.add_post("/api/charm_reshuffle", api_reshuffle_charm)
    app.router.add_post("/api/buy_bait", api_buy_bait)
    app.router.add_post("/api/fishing_start", api_fishing_start)
    app.router.add_post("/api/fishing_event", api_fishing_event)
    app.router.add_post("/api/boat_upgrade", api_boat_upgrade)
    app.router.add_post("/api/catch", api_catch)
    app.router.add_post("/api/sell_fish", api_sell_fish)
    app.router.add_post("/api/sell_all_fish", api_sell_all_fish)
    app.router.add_post("/api/upgrade", api_upgrade)
    app.router.add_post("/api/upgrade/arm", api_arm_upgrade)
    app.router.add_post("/api/redeem", api_redeem)
    app.router.add_post("/api/admin", api_admin)
    app.router.add_post("/api/unlock", api_unlock)
    app.router.add_post("/api/set_location", api_set_location)
    app.router.add_post("/api/rebirth", api_rebirth)
    app.router.add_get("/api/env", api_env)
    app.router.add_post("/api/contract_claim", api_contract_claim)
    app.router.add_get("/api/materials", api_materials)
    app.router.add_post("/api/workshop_buy", api_workshop_buy)
    app.router.add_post("/api/craft", api_craft)
    app.router.add_post("/api/craft_collect", api_craft_collect)
    app.router.add_post("/api/mat_trade", api_mat_trade)
    app.router.add_get("/api/net", api_net)
    app.router.add_post("/api/net_take", api_net_take)
    app.router.add_post("/api/net_sell_all", api_net_sell_all)
    app.router.add_get("/api/aquarium", api_aquarium)
    app.router.add_post("/api/aquarium_put", api_aquarium_put)
    app.router.add_post("/api/aquarium_take", api_aquarium_take)
    app.router.add_post("/api/aquarium_upgrade", api_aquarium_upgrade)
    app.router.add_post("/api/aquarium_claim", api_aquarium_claim)
    app.router.add_get("/api/trades", api_trades)
    app.router.add_post("/api/trade_create", api_trade_create)
    app.router.add_post("/api/trade_accept", api_trade_accept)
    app.router.add_post("/api/trade_decline", api_trade_decline)
    app.router.add_post("/api/charm_remove", api_charm_remove)
    app.router.add_post("/api/sell_rod_pick", api_sell_rod_pick)
    app.router.add_post("/api/daily", api_daily)
    app.router.add_post("/api/sell_many", api_sell_many)
    app.router.add_post("/api/chest", api_chest)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", PORT)
    await site.start()
    print(f"🌐 WebApp на http://0.0.0.0:{PORT}")

async def main():
    db.init_db()
    await start_web()
    print("🤖 Бот запущен! Автор: @pspwlk v1.2")
    await dp.start_polling(bot)

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
