"""Tackle catalog and case rewards. Values are game currency, weights in kg."""
import random, time
from contextlib import closing
import database as db
from config import FISH

ITEMS={
 'hook':[
  {'id':'hook_basic','name':'Простой крючок','limit':1,'price':50},
  {'id':'hook_steel','name':'Стальной крючок','limit':5,'price':400},
  {'id':'hook_strong','name':'Усиленный крючок','limit':25,'price':3000},
  {'id':'hook_titan','name':'Титановый крючок','limit':150,'price':22000},
  {'id':'hook_abyss','name':'Крючок глубин','limit':1000,'price':150000}],
 'line':[
  {'id':'line_basic','name':'Тонкая леска','limit':1,'price':80},
  {'id':'line_braid','name':'Плетёная леска','limit':5,'price':500},
  {'id':'line_strong','name':'Усиленная леска','limit':25,'price':4000},
  {'id':'line_titan','name':'Титановая леска','limit':150,'price':27000},
  {'id':'line_abyss','name':'Леска глубин','limit':1000,'price':180000}],
 'module':[
  {'id':'module_reel','name':'Улучшенная катушка','effect':'reel','bonus':8,'price':700,'img':'module_reel.png'},
  {'id':'module_grip','name':'Прочная рукоятка','effect':'wear','bonus':20,'price':4500,'img':'module_grip.png'},
  {'id':'module_guide','name':'Усиленные кольца','effect':'line','bonus':20,'price':25000,'img':'module_guide.png'},
 ],
}
BY_ID={item['id']:{**item,'kind':kind} for kind,items in ITEMS.items() for item in items}
CASES={
 'hook_low':('hook',500,[75,23,2,0,0]),'hook_mid':('hook',5000,[8,47,35,10,0]),'hook_high':('hook',45000,[0,8,22,45,25]),
 'line_low':('line',600,[75,23,2,0,0]),'line_mid':('line',6000,[8,47,35,10,0]),'line_high':('line',55000,[0,8,22,45,25]),
 'module_low':('module',1200,[85,14,1]),'module_mid':('module',12000,[20,65,15]),'module_high':('module',90000,[3,32,65]),
 'fish_low':('fish',500,[80,18,2]),'fish_mid':('fish',8000,[50,40,10]),'fish_high':('fish',100000,[20,45,35]),
}

def init(c):
 c.execute('''CREATE TABLE IF NOT EXISTS tackle_inventory(user_id INTEGER, item_id TEXT, count INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(user_id,item_id))''')
 c.execute('''CREATE TABLE IF NOT EXISTS tackle_equipped(user_id INTEGER PRIMARY KEY, hook TEXT, line TEXT, module TEXT)''')
 c.execute('''CREATE TABLE IF NOT EXISTS rod_condition(rod_id INTEGER PRIMARY KEY, condition REAL NOT NULL DEFAULT 100, broken INTEGER NOT NULL DEFAULT 0)''')

def _balance(c,uid,amount):
 row=c.execute('SELECT balance FROM users WHERE user_id=?',(uid,)).fetchone()
 if not row or row['balance']<amount: raise ValueError('Недостаточно денег')
 c.execute('UPDATE users SET balance=balance-? WHERE user_id=?',(amount,uid))

def open_case(uid,case_id):
 if case_id not in CASES: raise ValueError('Нет такого кейса')
 kind,cost,weights=CASES[case_id]
 with closing(db.get_conn()) as c,c:
  c.execute('BEGIN IMMEDIATE'); _balance(c,uid,cost)
  if kind=='fish':
   loc=c.execute('SELECT location FROM users WHERE user_id=?',(uid,)).fetchone()['location']
   fishes=sorted((x for x in FISH if not x.get('upgrade_only') and x['loc']<=loc),key=lambda f:f['price'])
   if not fishes: raise ValueError('Нет доступной рыбы')
   groups=[fishes[:max(1,len(fishes)//3)],fishes[max(1,len(fishes)//3):max(2,2*len(fishes)//3)],fishes[max(2,2*len(fishes)//3):]]
   tier=random.choices(range(3),weights)[0]; fish=random.choice(groups[tier] or fishes)
   weight=round(random.uniform(fish['wmin'],fish['wmax']),2)
   cur=c.execute('INSERT INTO fish_inventory(user_id,fish_id,weight,price,caught_at) VALUES (?,?,?,?,?)',(uid,fish['id'],weight,fish['price'],int(time.time())))
   return {'kind':'fish','name':fish['name'],'fish_id':fish['id'],'weight':weight,'id':cur.lastrowid,'cost':cost}
  item=random.choices(ITEMS[kind],weights)[0]
  c.execute('INSERT INTO tackle_inventory(user_id,item_id,count) VALUES (?,?,1) ON CONFLICT(user_id,item_id) DO UPDATE SET count=tackle_inventory.count+1',(uid,item['id']))
  return {'kind':kind,'item':item,'cost':cost}

def list_inventory(uid):
 with closing(db.get_conn()) as c:
  rows=c.execute('SELECT item_id,count FROM tackle_inventory WHERE user_id=? AND count>0',(uid,)).fetchall()
  return [{**BY_ID[r['item_id']],'count':r['count']} for r in rows if r['item_id'] in BY_ID]

def ensure(uid):
 with closing(db.get_conn()) as c,c:
  c.execute('BEGIN IMMEDIATE')
  row=c.execute('SELECT user_id FROM tackle_equipped WHERE user_id=?',(uid,)).fetchone()
  if not row:
   c.execute('INSERT INTO tackle_equipped(user_id,hook,line,module) VALUES (?,?,?,?)',(uid,'hook_basic','line_basic',None))
   for ident in ('hook_basic','line_basic'):
    c.execute('INSERT INTO tackle_inventory(user_id,item_id,count) VALUES (?,?,1) ON CONFLICT(user_id,item_id) DO UPDATE SET count=tackle_inventory.count+1',(uid,ident))

def state(uid):
 ensure(uid)
 with closing(db.get_conn()) as c:
  equipment=c.execute('SELECT * FROM tackle_equipped WHERE user_id=?',(uid,)).fetchone()
  conditions=c.execute('SELECT rods.id,COALESCE(rod_condition.condition,100) AS condition,COALESCE(rod_condition.broken,0) AS broken FROM rods LEFT JOIN rod_condition ON rods.id=rod_condition.rod_id WHERE rods.user_id=?',(uid,)).fetchall()
  return {'equipped':dict(equipment),'inventory':list_inventory(uid),'conditions':[dict(r) for r in conditions], 'cases':[{'id':k,'kind':v[0],'cost':v[1],'weights':v[2]} for k,v in CASES.items()]}

def equip(uid,item_id):
 item=BY_ID.get(item_id)
 if not item: raise ValueError('Предмет не найден')
 with closing(db.get_conn()) as c,c:
  c.execute('BEGIN IMMEDIATE')
  row=c.execute('SELECT count FROM tackle_inventory WHERE user_id=? AND item_id=?',(uid,item_id)).fetchone()
  if not row or row['count']<1: raise ValueError('Предмета нет в корзине')
  c.execute('UPDATE tackle_equipped SET '+item['kind']+'=? WHERE user_id=?',(item_id,uid))

def buy_basic(uid,kind):
 ident={'hook':'hook_basic','line':'line_basic'}.get(kind)
 if not ident: raise ValueError('Нет такого предмета')
 item=BY_ID[ident]
 with closing(db.get_conn()) as c,c:
  c.execute('BEGIN IMMEDIATE');_balance(c,uid,item['price'])
  c.execute('INSERT INTO tackle_inventory(user_id,item_id,count) VALUES (?,?,1) ON CONFLICT(user_id,item_id) DO UPDATE SET count=tackle_inventory.count+1',(uid,ident))
 return item

def sell(uid,ident):
 item=BY_ID.get(ident)
 if not item:raise ValueError('Предмет не найден')
 amount=max(1,int(item['price']*.5))
 with closing(db.get_conn()) as c,c:
  c.execute('BEGIN IMMEDIATE')
  row=c.execute('SELECT count FROM tackle_inventory WHERE user_id=? AND item_id=?',(uid,ident)).fetchone()
  if not row or row['count']<1: raise ValueError('Нет такого предмета')
  equipped=c.execute('SELECT '+item['kind']+' FROM tackle_equipped WHERE user_id=?',(uid,)).fetchone()
  if equipped and equipped[0]==ident and row['count']==1: raise ValueError('Сначала установите другую снасть')
  c.execute('UPDATE tackle_inventory SET count=count-1 WHERE user_id=? AND item_id=?',(uid,ident))
  c.execute('UPDATE users SET balance=balance+? WHERE user_id=?',(amount,uid))
 return amount

def repair(uid,rod_db_id):
 from config import RODS_BY_ID
 with closing(db.get_conn()) as c,c:
  c.execute('BEGIN IMMEDIATE')
  rod=c.execute('SELECT rod_id FROM rods WHERE id=? AND user_id=?',(rod_db_id,uid)).fetchone()
  if not rod:raise ValueError('Удочка не найдена')
  r=c.execute('SELECT condition,broken FROM rod_condition WHERE rod_id=?',(rod_db_id,)).fetchone()
  if not r or (not r['broken'] and r['condition']>=100):raise ValueError('Удочка не нуждается в ремонте')
  cost=int(RODS_BY_ID[rod['rod_id']]['price']*.4);_balance(c,uid,cost)
  c.execute('INSERT INTO rod_condition(rod_id,condition,broken) VALUES (?,100,0) ON CONFLICT(rod_id) DO UPDATE SET condition=100,broken=0',(rod_db_id,))
  return cost

def ready(uid,rod_id):
 ensure(uid)
 with closing(db.get_conn()) as c:
  rod=c.execute('SELECT broken FROM rod_condition WHERE rod_id=?',(rod_id,)).fetchone()
  if rod and rod['broken']:raise ValueError('Удочка сломана — почините её')
  equipment=c.execute('SELECT hook,line FROM tackle_equipped WHERE user_id=?',(uid,)).fetchone()
  for name in ('hook','line'):
   item=equipment[name] if equipment else None
   count=c.execute('SELECT count FROM tackle_inventory WHERE user_id=? AND item_id=?',(uid,item)).fetchone() if item else None
   if not item or not count or count['count']<1:raise ValueError('Установите крючок и леску в разделе Снасти')

def resolve(uid,rod_id,weight):
 # Called only for the single valid pending fishing encounter.
 with closing(db.get_conn()) as c,c:
  c.execute('BEGIN IMMEDIATE')
  rod=c.execute('SELECT id FROM rods WHERE user_id=? AND id=?',(uid,rod_id)).fetchone()
  if not rod: raise ValueError('Удочка не найдена')
  eq=c.execute('SELECT hook,line,module FROM tackle_equipped WHERE user_id=?',(uid,)).fetchone()
  if not eq or not eq['hook'] or not eq['line']:raise ValueError('Установите крючок и леску')
  for kind in ('hook','line'):
   inv=c.execute('SELECT count FROM tackle_inventory WHERE user_id=? AND item_id=?',(uid,eq[kind])).fetchone()
   if not inv or inv['count']<1:raise ValueError('Снасть закончилась')
  cond=c.execute('SELECT condition,broken FROM rod_condition WHERE rod_id=?',(rod_id,)).fetchone()
  condition=float(cond['condition']) if cond else 100.0
  if cond and cond['broken']: raise ValueError('Удочка сломана')
  hook=BY_ID.get(eq['hook']);line=BY_ID.get(eq['line']);mod=BY_ID.get(eq['module'])
  if not hook or not line:raise ValueError('Снасть недоступна')
  line_cap=line['limit']*(1.2 if mod and mod['effect']=='line' else 1)
  overload=max(weight/hook['limit'],weight/line_cap)
  wear=(.35+min(2.5,weight/max(1,hook['limit'])*.2))*(.8 if mod and mod['effect']=='wear' else 1)
  condition=max(0,condition-wear)
  # Excellent condition makes failure exceptionally unlikely; lower condition increases risk.
  break_chance=min(.5,(1-condition/100)**2*.20*min(2,max(.15,overload)))
  broken=random.random()<break_chance
  c.execute('INSERT INTO rod_condition(rod_id,condition,broken) VALUES (?,?,?) ON CONFLICT(rod_id) DO UPDATE SET condition=excluded.condition,broken=excluded.broken',(rod_id,condition,int(broken)))
  lost_line=overload>1 and random.random()<min(.95,.10+(overload-1)*.35)
  if lost_line:
   for kind in ('hook','line'):
    c.execute('UPDATE tackle_inventory SET count=count-1 WHERE user_id=? AND item_id=?',(uid,eq[kind]))
    left=c.execute('SELECT count FROM tackle_inventory WHERE user_id=? AND item_id=?',(uid,eq[kind])).fetchone()
    if left['count']<=0:c.execute('UPDATE tackle_equipped SET '+kind+'=NULL WHERE user_id=?',(uid,))
  return {'condition':round(condition,1),'broken':broken,'lost_line':lost_line,'escaped':broken or lost_line}
